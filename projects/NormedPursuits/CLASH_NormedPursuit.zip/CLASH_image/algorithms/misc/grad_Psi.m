function dx = grad_Psi(Psi, I)

I = Psi(I);
dx = zeros(size(I, 1), size(I, 2), 2);

dx(:, :, 1) = [I(2:end, :)-I(1:end-1, :) ; zeros(1, size(I, 2))];
dx(:, :, 2) = [I(:, 2:end)-I(:, 1:end-1) , zeros(size(I, 1), 1)];

end