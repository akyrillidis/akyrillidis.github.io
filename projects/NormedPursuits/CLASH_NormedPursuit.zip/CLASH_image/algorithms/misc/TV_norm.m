function y = TV_norm(I)

dx = [I(2:end, :)-I(1:end-1, :) ; zeros(1, size(I, 2))];
dy = [I(:, 2:end)-I(:, 1:end-1) , zeros(size(I, 1), 1)];
temp = sqrt(abs(dx).^2 + abs(dy).^2);
y = sum(temp(:));

end