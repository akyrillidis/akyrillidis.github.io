function I = Psit_div(Psit, dx)

I = [dx(1, :, 1) ; dx(2:end-1, :, 1)-dx(1:end-2, :, 1) ; -dx(end-1, :, 1)];
I = I + [dx(:, 1, 2) , dx(:, 2:end-1, 2)-dx(:, 1:end-2, 2) , -dx(:, end-1, 2)];

I = Psit(I);

end