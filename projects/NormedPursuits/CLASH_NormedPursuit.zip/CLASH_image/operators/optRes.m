function x = optRes(y, Phit, I)

z= Phit(y);
x = z(I);

end

