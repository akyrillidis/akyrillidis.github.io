function x = optMeas(y, C, M, size)

x = zeros(size); x(M==1) = y;
x = ifftn(x)*sqrt(numel(x));
x = x.*C;

end