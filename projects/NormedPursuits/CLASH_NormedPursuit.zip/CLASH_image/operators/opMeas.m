function y = opMeas(x, C, M)

y = fftn(x.*C)/sqrt(numel(x));
y = y(M==1);

end