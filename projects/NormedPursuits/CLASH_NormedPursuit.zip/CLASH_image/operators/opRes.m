function y = opRes(x, Psi, ind, dim)

z = zeros(dim);
z(ind) = x;
y = Psi(z);

end

