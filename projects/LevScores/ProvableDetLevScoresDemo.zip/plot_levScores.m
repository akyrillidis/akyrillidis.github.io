function plot_levScores(lev_sort, flag_dataset)

if (flag_dataset == 0)
    set(0, 'DefaultAxesFontSize', 20);
    figure(1);
    plot(lev_sort, 'rx', 'MarkerSize',8); hold on;
    a1 = 0.27; env_above = lev_sort(1).*(1:length(lev_sort)).^(-a1);
    a2 = 0.37; env_below = lev_sort(1).*(1:length(lev_sort)).^(-a2);
    plot(env_above, 'bo', 'MarkerSize',8); hold on; 
    plot(env_below, 'kd', 'MarkerSize',8); hold on;
    xlabel('Sorted leverage scores index', 'Interpreter', 'latex', 'FontSize', 20);
    ylabel('Magnitude', 'Interpreter', 'latex', 'FontSize', 20);
    h = legend('$\texttt{Abalone}$', '$\alpha_k = 0.25$', '$\alpha_k = 0.35$');
    set(h, 'Interpreter', 'latex', 'FontSize', 20);
    axis tight;
    grid on;
    print -dpdf -r300 abalone.pdf
    print -depsc -r300 abalone.eps
elseif (flag_dataset == 1)
    set(0, 'DefaultAxesFontSize', 20);
    figure(1);
    plot(lev_sort, 'rx', 'MarkerSize',8); hold on;
    a1 = 0.17; env_above = lev_sort(1).*(1:length(lev_sort)).^(-a1);
    a2 = 0.27; env_below = lev_sort(1).*(1:length(lev_sort)).^(-a2);
    plot(env_above, 'bo', 'MarkerSize',8); hold on; 
    plot(env_below, 'kd', 'MarkerSize',8); hold on;
    xlabel('Sorted leverage scores index', 'Interpreter', 'latex', 'FontSize', 20);
    ylabel('Magnitude', 'Interpreter', 'latex', 'FontSize', 20);
    h = legend('$\texttt{Gisette}$', '$\alpha_k = 0.15$', '$\alpha_k = 0.25$');
    set(h, 'Interpreter', 'latex', 'FontSize', 20);
    axis tight;
    grid on;
    print -dpdf -r300 gisette.pdf
    print -depsc -r300 gisette.eps
elseif (flag_dataset == 2)
    set(0, 'DefaultAxesFontSize', 20);
    figure(1);
    plot(lev_sort, 'rx', 'MarkerSize',8); hold on;
    a1 = 0.1; env_above = lev_sort(1).*(1:length(lev_sort)).^(-a1);
    a2 = 0.2; env_below = lev_sort(1).*(1:length(lev_sort)).^(-a2);
    plot(env_above, 'bo', 'MarkerSize',8); hold on; 
    plot(env_below, 'kd', 'MarkerSize',8); hold on;
    xlabel('Sorted leverage scores index', 'Interpreter', 'latex', 'FontSize', 20);
    ylabel('Magnitude', 'Interpreter', 'latex', 'FontSize', 20);
    h = legend('$\texttt{Protein}$', '$\alpha_k = 0.1$', '$\alpha_k = 0.2$');
    set(h, 'Interpreter', 'latex', 'FontSize', 20);
    axis tight;
    grid on;
    print -dpdf -r300 protein.pdf
    print -depsc -r300 protein.eps
elseif (flag_dataset == 3)
    set(0, 'DefaultAxesFontSize', 20);
    figure(1);
    plot(lev_sort, 'rx', 'MarkerSize',8); hold on;
    a1 = 0.2; env_above = lev_sort(1).*(1:length(lev_sort)).^(-a1);
    a2 = 0.45; env_below = lev_sort(1).*(1:length(lev_sort)).^(-a2);
    plot(env_above, 'bo', 'MarkerSize',8); hold on; 
    plot(env_below, 'kd', 'MarkerSize',8); hold on;
    xlabel('Sorted leverage scores index', 'Interpreter', 'latex', 'FontSize', 20);
    ylabel('Magnitude', 'Interpreter', 'latex', 'FontSize', 20);
    h = legend('$\texttt{SNPS}$', '$\alpha_k = 0.2$', '$\alpha_k = 0.45$');
    set(h, 'Interpreter', 'latex', 'FontSize', 20);
    axis tight;
    grid on;
    print -dpdf -r300 SNPS.pdf
    print -depsc -r300 SNPS.eps
elseif (flag_dataset == 4)
    set(0, 'DefaultAxesFontSize', 20);
    figure(1);
    plot(lev_sort, 'rx', 'MarkerSize',8); hold on;
    a1 = 1; env_above = lev_sort(1).*(1:length(lev_sort)).^(-a1);
    a2 = 1.2; env_below = lev_sort(1).*(1:length(lev_sort)).^(-a2);
    plot(env_above, 'bo', 'MarkerSize',8); hold on; 
    plot(env_below, 'kd', 'MarkerSize',8); hold on;
    xlabel('Sorted leverage scores index', 'Interpreter', 'latex', 'FontSize', 20);
    ylabel('Magnitude', 'Interpreter', 'latex', 'FontSize', 20);
    h = legend('$\texttt{Spam}$', '$\alpha_k = 1$', '$\alpha_k = 1.2$');
    set(h, 'Interpreter', 'latex', 'FontSize', 20);
    axis tight;
    grid on;
    print -dpdf -r300 Spam.pdf
    print -depsc -r300 Spam.eps    
end;