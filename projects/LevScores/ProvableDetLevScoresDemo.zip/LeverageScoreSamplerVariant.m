function S = LeverageScoreSamplerVariant(Vk, c)

[n, ~] = size(Vk);

% Compute lev. scores
lev = zeros(n, 1);
for i = 1:n
    lev(i) = norm(Vk(i, :), 2)^2;
end;

% Sort lev. scores
[~, lev_ind] = sort(lev, 'descend');

S = lev_ind(1:c);