function S = LeverageScoreSampler(A, k, theta)

[~, n] = size(A);

% Compute top k right singular vectors
[~, ~, V] = svd(A);
Vk = V(:, 1:k);

% Compute lev. scores
lev = zeros(n, 1);
for i = 1:n
    lev(i) = norm(Vk(i, :), 2)^2;
end;

% Sort lev. scores
[lev_sort, lev_ind] = sort(lev, 'descend');

% Compute sums of leverage scores (given descending order of lev. scores vectors).
lev_cumsum = cumsum(lev_sort);

% Find position where sum(lev) > theta
c = find(lev_cumsum > theta, 1, 'first');

% Construct S by using c most important columns of A
S = [];
for i = 1:c
    e_i = zeros(n, 1);
    e_i(lev_ind(i)) = 1;
    S = [S e_i];
end;
