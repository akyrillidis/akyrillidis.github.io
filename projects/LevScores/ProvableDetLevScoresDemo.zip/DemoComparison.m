clear;
close all;

flag_dataset = 0;

% Load data    
if (flag_dataset == 0)
    load abalone_dataset.mat;
    A = abaloneInputs;        
    K = 3;
elseif (flag_dataset == 1)
    load gisette_train.data;
    A = gisette_train';
    K = [20 50 100];
elseif (flag_dataset == 2)
    load protein_data.mat;
    A = full(X)';       
    K = [50 100 150 200];
elseif (flag_dataset == 3)
    load snpsdata.mat;
    A = A';
    K = [5 10 20];
elseif (flag_dataset == 4)  
    load spam.data;
    A = spam';
    K = [5 10 20];
elseif (flag_dataset == 5)
    load winequality_data.mat;
    A = X';
    K = [5];
elseif (flag_dataset == 6)
    load email-Enron.mat;
    A = full(Problem.A);        
    A = A(1:3*10^3, 1:3*10^3);
    K = [10 20 50 100];
elseif (flag_dataset == 7)
    load kin8nm.data
    A = kin8nm';        
    K = 5;
end;

[m, n] = size(A);

spectral_error = zeros(numel(K), 5, 4);
Frob_error = zeros(numel(K), 5, 4);

[U, Sigma, V] = svd(A, 0);

for j = 1:numel(K)
    k = K(j);
    if (flag_dataset == 0)
        col = 4:8;        
    elseif (flag_dataset == 1)
        col = round(linspace(k+1, 300, 5));
    elseif (flag_dataset == 2)
        col = round(linspace(k+1, 320, 5));
    elseif (flag_dataset == 3 || flag_dataset == 4)
        col = round(linspace(k+1, 30, 5));
    elseif (flag_dataset == 5)
        col = [6 10];
    elseif (flag_dataset == 6)
        col = round(linspace(k+1, 300, 5));
    end;

    % Compute Ak, rank-k approximation of A
    Ak = U(:, 1:k)*Sigma(1:k, 1:k)*V(:, 1:k)';
    Vk = V(:, 1:k);

    if (j == 1)        
        % Compute lev. scores
        lev = zeros(n, 1);
        for i = 1:n
            lev(i) = norm(Vk(i, :), 2)^2;
        end;

        [lev_sort, lev_ind] = sort(lev, 'descend');

        plot_levScores(lev_sort, flag_dataset);
    end;

    best_spectral = norm(A - Ak);
    best_frob = norm(A - Ak, 'fro');

    for l = 1:numel(col)            
        c = col(l);

        [k c]

        % Run our algorithm - Spectral + Frob.
        S_levScore = LeverageScoreSamplerVariant(Vk, c);
        C_levScore = A(:, S_levScore);

        A_levScore = C_levScore * pinv(C_levScore) * A;
        spectral_error(l, j, 1) = norm(A - A_levScore)/best_spectral;
        Frob_error(l, j, 1) = norm(A - A_levScore, 'fro')/best_frob;

        % Run Near optimal algorithm - Spectral + Frob.
        S_near = DualSetSpectralFrobeniusSparsification(A, Vk, k, c);
        length(S_near)
        C_near = A(:,S_near);

        A_near = C_near * pinv(C_near) * A;
        spectral_error(l, j, 2) = norm(A - A_near)/best_spectral;
        Frob_error(l, j, 2) = norm(A - A_near, 'fro')/best_frob;

        % Run QR - Spectral
        [Q, R, E] = qr(A, 0);

        S_qr = E(1:c);            
        C_qr = A(:, S_qr);

        A_qr = C_qr * pinv(C_qr) * A;
        spectral_error(l, j, 3) = norm(A - A_qr)/best_spectral;
        Frob_error(l, j, 3) = norm(A - A_qr, 'fro')/best_frob;

        % Run randomized Lev. Scores - Frob.
        S_rand = RandLevScores(Vk, c);            
        C_rand = A(:, S_rand);

        A_rand = C_rand * pinv(C_rand) * A;
        spectral_error(l, j, 4) = norm(A - A_rand)/best_spectral;
        Frob_error(l, j, 4) = norm(A - A_rand, 'fro')/best_frob;

        [best_spectral best_frob; ...
        norm(A - A_levScore) norm(A - A_levScore, 'fro'); ...
        norm(A - A_near) norm(A - A_near, 'fro'); ...
        norm(A - A_qr) norm(A - A_qr, 'fro')
        norm(A - A_rand) norm(A - A_rand, 'fro')]
    end;
end;

if (flag_dataset == 0)
    save ResultsAbalons.mat spectral_error Frob_error
elseif (flag_dataset == 1)
    save ResultsGisette.mat spectral_error Frob_error
elseif (flag_dataset == 2)
    save ResultsProtein.mat spectral_error Frob_error 
elseif (flag_dataset == 3)
    save ResultsSNPS.mat spectral_error Frob_error 
elseif (flag_dataset == 4)
    save ResultsSpam.mat spectral_error Frob_error 
elseif (flag_dataset == 5)
    save ResultsWine.mat spectral_error Frob_error 
elseif (flag_dataset == 6)
    save ResultsEnron.mat spectral_error Frob_error 
end;


