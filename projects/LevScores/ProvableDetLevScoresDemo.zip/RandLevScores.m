function S = RandLevScores(Vk, c)

[n, ~] = size(Vk);

% Compute lev. scores
lev = zeros(n, 1);
for i = 1:n
    lev(i) = norm(Vk(i, :), 2)^2;
end;

prob_lev = lev./sum(lev);

ind = discretesample(prob_lev, c);

S = ind(1:c);
