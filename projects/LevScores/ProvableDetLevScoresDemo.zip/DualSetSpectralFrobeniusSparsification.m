function [S] = DualSetSpectralFrobeniusSparsification(A, Vk, k, c)
%     [~, n]  = size(A);
%     [~, ~, vk] = svds(A,k); 
    vk = Vk;
    V          = vk'; 
    U          = A - (A*vk)*vk'; 
    deltaL     = 1; 
    deltaU     = norm(U,'fro')^2 / (1 - sqrt(k/c));
    s          = zeros(1, size(A,2)); 
    At         = zeros(k);   
    for tau = 0:c-1
        Lt = Ltau(tau, c, k);
        for j = 1:size(A,2)
            upper = Uf(U(:,j), deltaU);
            lower = Lf(V(:,j), deltaL, At, Lt);
            if upper <= lower
                w    = 2/(upper + lower); 
                s(j) = s(j) + w; 
                At   = At + w*V(:,j)*V(:,j)';
                break
            end
        end
    end
    S = find(s > 0);
end

function L = Ltau(tau, c, k)
    L = tau - sqrt(c*k); 
end

function PhiL = PhiLower(L, A)
    PhiL = 0; 
	lambdaA = eig(A); 
	for i=1:size(A,2)
	    PhiL = PhiL+ 1/(lambdaA(i)-L); 
	end; 
end

function Lf = Lf(v, deltaL, A, L)
	x   = (A-(L+deltaL)*eye(size(A,1)))\v;
	Lf  = (x'*x)/(PhiLower(L+deltaL, A)-PhiLower(L, A))-v'*x; 
end

function Uf = Uf(u, deltaU)
	Uf = (u'*u) / deltaU; 
end