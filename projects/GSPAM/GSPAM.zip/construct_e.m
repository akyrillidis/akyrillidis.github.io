function [E] = construct_e(h, t)

d = length(h);
E = zeros(d, t);
E(:, end) = h - 1;
E(:, 1) = abs(h - t);