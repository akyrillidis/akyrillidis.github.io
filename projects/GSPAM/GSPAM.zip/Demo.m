% ========================================================================
%             Demo for GSPAM  - Protoype for proof of concept
%                   (Takes approx. ? minutes to run)
%
% This file includes the actual implementation of the GSPAM procedure,
% as explained in 
%
% [1] "Learning sparse additive models with interactions in high dimensions",
% by Hemant Tyagi, Anastasios Kyrillidis, Bernd Gartner and, Andreas Krause.
% =========================================================================
% 09/03/2015, by Anastasios Kyrillidis. anastasios@utexas.edu, UTA.
% =========================================================================
% Description: similar to the setting in the experimental section of the
% paper. 
% Demo 1
% 
% Phase transition
%
% Setups: fix k - fix rho_m - fix d - variable Csam

clear
close all
clc

% Setup
d = 50;         % Dimension
Csam = 5;       % Constant C in front of number of queries made
k1 = 2;         % Sparsity univariate
k2 = 2;         % Sparsity bivariate
rho_m = 2;      % Each variable belongs to at most 2 "groups"
sigma = 0;      % No noise

% Without loss of generality, we assume that indices (1:2) are the
% univariate variables and {(3,4), (3,5)} are the bivariate variables that
% overlap. S1 containts the list of univariates, S2 contains the set of
% bivariates.
S1 = (1:2)';    
S2 = (3:5)';

test_case = 1;           % If 1
[S1_hat, S2_hat, query_counter] = overSPAM_wrapper(d, Csam, k1, k2, rho_m, sigma, [], [], test_case);
if (isequal(S1_hat(:), S1) && isequal(unique(S2_hat), S2))
    fprintf('Done with success! \n');
    fprintf('Number of queries: %d\n', query_counter);
    fprintf('Group S1: \n');
    disp(S1_hat);
    fprintf('Group S2: \n');
    disp(S2_hat);
end;