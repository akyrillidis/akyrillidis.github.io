function query_val = query_GSPAM(x, S1, S2, constants)

if (constants.case == 1)
    unifunc1 = constants.c11 * sin(pi * x(S1(1)));
    unifunc2 = constants.c12 * exp(-2 * x(S1(2)));
    bifunc1 = constants.c21 * sin(pi * x(S2(1,1)) * x(S2(1,2)));
    bifunc2 = constants.c31 * exp(-2 * x(S2(2,1)) * x(S2(2,2)));
elseif (constants.case == 2)
    unifunc1 = constants.c11 * ( cos(pi * x(S1(1))) )^3 + constants.a21 * x(S1(1))^2;
    unifunc2 = constants.c12 * (x(S1(2)))^4 - x(S1(2))^2 + constants.a22 * x(S1(2));
    bifunc1 = constants.c21 * ( cos(pi * x(S2(1,1)) * x(S2(1,2))) )^3 + constants.a31 * (x(S2(1,1)) * x(S2(1,2)))^2;
    bifunc2 = constants.c31 * (x(S2(2,1)) * x(S2(2,2)))^4 - (x(S2(2,2)) * x(S2(2,2)))^2 + constants.a32 * (x(S2(2,1)) * x(S2(2,2)));
end;

query_val = unifunc1 + unifunc2 + bifunc1 + bifunc2;

if (constants.sigma ~= 0)
    query_val = query_val + constants.sigma * randn;
end;
