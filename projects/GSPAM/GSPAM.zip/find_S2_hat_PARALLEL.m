function [S2_hat, query_counter] = find_S2_hat_PARALLEL(H, c, Vs, constants, t, S1, S2, i, params)
 
query_counter = 0;

S2_hat = [];
% ... construct set chi(h) ...    
h = H(:, i);                
E = construct_e(h, t);
chi_h = construct_chih(E, c);
chi_h_card = size(chi_h, 2);

d = size(Vs.V, 1);
Vt = Vs.V';
Vt_prime = Vs.V_prime';
    
% For each j = 1...(2*mx + 1)^2, ...
for j = 1:chi_h_card
    x = chi_h(:, j);
    % ... construct y, solve l1-norm.
    y = zeros(constants.mv, 1);    

    % Compute y for all mv points
    for l = 1:constants.mv
        if (constants.sigma == 0)
            % Compute f(x + mu*v)
            f_plus = query_GSPAM(x + constants.mu * Vs.V(:, l), S1, S2, constants);
            
            % Compute f(x - mu*v)
            f_minus = query_GSPAM(x - constants.mu * Vs.V(:, l), S1, S2, constants);

            % Compute y
            y(l) = (f_plus - f_minus)/(2*constants.mu);
            query_counter = query_counter + 2;
        else
            f_plus = 0;
            % Compute f(x + mu*v)
            f_plus = f_plus + query_GSPAM(x + constants.mu * Vs.V(:, l), S1, S2, constants);            
            
            f_minus = 0;            
            % Compute f(x - mu*v)
            f_minus = f_minus + query_GSPAM(x - constants.mu * Vs.V(:, l), S1, S2, constants);
            
            % Compute y
            y(l) = (f_plus - f_minus)/(2*constants.mu);
            query_counter = query_counter + 2*constants.N1;
        end;
    end;

    % Solve l0-norm minimization using ALPS
    [gradi, ~] = one_ALPS(y, Vt, constants.k, params);

    % Construct y_{i, p} and solve again l1-norm (l0-norm) minimization
    gradip = zeros(d, constants.mv_prime);
    % For mv_prime times...
    for p = 1:constants.mv_prime
        y = zeros(constants.mv, 1);

        % Compute y for all mv points
        for l = 1:constants.mv
            if (constants.sigma == 0)
                % Compute f(x + mu*v)
                f_plus = query_GSPAM(x + constants.mu * Vs.V(:, l) + constants.mu1 * Vs.V_prime(:, p), S1, S2, constants);

                % Compute f(x - mu*v)
                f_minus = query_GSPAM(x - constants.mu *Vs.V(:, l) + constants.mu1 * Vs.V_prime(:, p), S1, S2, constants);

                % Compute y
                y(l) = (f_plus - f_minus)/(2*constants.mu);
                query_counter = query_counter + 2;
            else
                f_plus = 0;
                % Compute f(x + mu*v)
                f_plus = f_plus + query_GSPAM(x + constants.mu * Vs.V(:, l) + constants.mu1 * Vs.V_prime(:, p), S1, S2, constants);

                f_minus = 0;
                % Compute f(x - mu*v)
                f_minus = f_minus + query_GSPAM(x - constants.mu *Vs.V(:, l) + constants.mu1 * Vs.V_prime(:, p), S1, S2, constants);

                % Compute y
                y(l) = (f_plus - f_minus)/(2*constants.mu);
                query_counter = query_counter + 2*constants.N1;
            end;
        end;

        % Solve l0-norm minimization using ALPS
        [temp_gradi, ~] = one_ALPS(y, Vt, constants.k, params);
        gradip(:, p) = temp_gradi;
    end;

    % Final stage to find S2_hat
    for q = 1:d
        y = zeros(constants.mv_prime, 1);
        
        % Compute y for all mv_prime points
        for l = 1:constants.mv_prime
            % Compute f(x + mu*v)
            f_plus = gradip(q, l);

            % Compute f(x - mu*v)
            f_minus = gradi(q);

            % Compute y
            y(l) = (f_plus - f_minus)/(constants.mu1);
        end;

        if (isempty(nonzeros(y)))
            continue
        else
            % Solve l0-norm minimization using ALPS
            [partial_gradi, ~] = one_ALPS(y, Vt_prime, 2 * constants.k2, params);

            % Update S2_hat
            for q_prime = q+1:d                    
                if (abs(partial_gradi(q_prime)) > constants.tau_prime)
                    S2_hat = [S2_hat; q q_prime];
                end;
            end;
        end;                        
    end;        
end;    

S2_hat = unique(S2_hat, 'rows');