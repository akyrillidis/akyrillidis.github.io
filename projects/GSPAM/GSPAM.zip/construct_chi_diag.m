function chi_diag = construct_chi_diag(mx, d)

c = -1:(1/mx):1;
chi_diag = zeros(d, numel(c));

% For all combinations of c values...
for i = 1:numel(c)
    x = c(i)*ones(d, 1);
    chi_diag(:, i) = x;
end;

