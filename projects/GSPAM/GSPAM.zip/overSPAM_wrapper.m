function [S1_hat, S2_hat, query_counter] = overSPAM_wrapper(d, Csam, k1, k2, rho_m, sigma, N1, N2, test_case)
 
query_counter = 0;

addpath(genpath('ALPS/'));

% ALPS parameters
params.ALPSiters = 600;         % Maximum number of iterations
params.tol= 1e-6;               % Tolerance for stopping criteria
params.mode = 1;                % Binary representation of (SolveNewtonb, GradientDescentx, SolveNewtox)
                                % mode = 5: Subspace Pursuit version
                                % mode = 2: Gradient descent based with additional de-bias step
params.memory = 1;              % Memory of IHT method - set to 1 for 1-ALPS(#) methods, set to 0 for 0-ALPS(#)
params.useCG = 1;               % Usage of Conjugate gradients method - used only if we do pseudoinversion steps
params.cg_tol = 10^-8;          % CG accuracy
params.cg_maxiter = 500;        % Maximum number of iterations for CG

t = 2;                          % Determines hash functions

% Set k's
S1 = 1:k1;
S2 = zeros(numel(k1+1:k1+k2), 2);
S2(:, 1) = k1+1;
for i = 1:k2
    S2(i, 2) = k1+1+i;
end;

k = 5;                      % Total sparsity

% Set parameters
% lambda1 = 0.3;                      % Lebesgue measure constant
% lambda2 = 0.3;                      % Lebesgue measure constant

lambda1 = 0.3;                      % Lebesgue measure constant
lambda2 = 0.6;                      % Lebesgue measure constant

mv = ceil(Csam*k*log(d/k));                     % Cardinality of set V 
mv_prime = ceil(Csam*rho_m*log(d/rho_m));       % Cardinality of set V'                  

mx = ceil(1/lambda2);            % Cardinality parameter for set X
mx_prime = ceil(1/lambda1);      % Cardinality parameter for set diag chi

% Constants
% D1 = 8; 
% D2 = 4;

D1 = 2; 
D2 = 2.1;
C1 = 1;
C2 = 2;
C3 = 1.1;

% B3 = 35;
B3 = 15; 
a = ((4*rho_m + 1)*B3)/(2*sqrt(mv_prime));
b = (C1*sqrt(mv_prime)*(4*k*rho_m + k)*B3)/(3*mv);

% Set algorithmic parameters
% mu = 0.5*sqrt( min(D1, D2^2 / (2*C2*(4*rho_m + 1)*B3*sqrt(mv_prime))) * ((3*mv)/(C1*B3*(4*k + (4*rho_m - 3)*alpha))) );
if (sigma == 0)
    mu = 0.5 * sqrt(D2^2 / (16*a*b*C2^2));
    mu1 = ( (D2/(4*a*C2)) )/2;
    tau_prime = C2 * ( (mu1*a) + (b * (mu^2/mu1)) );
else
    epsilon1 = D2^3 / (192*sqrt(3)*C1*C2^3*sqrt(a^3*b*mv_prime*mv));
    epsilon = 0.2*epsilon1;
    theta1 = acos(-epsilon/epsilon1);

    mu = (( sqrt(D2^2/(12*a*b*C2^2)) * cos(theta1/3 - 2*pi/3)) + ( sqrt(D2^2/(12*a*b*C2^2)) * cos(theta1/3) )) / 2;
    mu1 = ( (D2/(4*a*C2)) )/2;
    tau_prime = C2 * ( (mu1*a) + (b * (mu^2/mu1)) + (2*C1*epsilon*sqrt(mv_prime*mv))/(mu*mu1));
    
%     mu = 0.5* (D2^2 / (16*a*b*C2^2));
%     mu1 = ( (D2/(4*a*C2)) )/2;
%     tau_prime = C2 * ( (mu1*a) + (b * (mu^2/mu1)) );
end;

S1_hat = [];
S2_hat = [];

% Function parameters a1, etc.
constants.c11 = 3 + (4-3).*rand;
constants.c12 = 3 + (4-3).*rand;
constants.c21 = 1 + (2-1).*rand;
constants.c31 = 2 + (3-2).*rand;
constants.c32 = 2 + (3-2).*rand;
constants.c33 = 0.5 + (1-0.5).*rand;
constants.a1 = 2 + (3-2).*rand;
constants.a21 = 1 + (2-1).*rand;
constants.a22 = 1 + (2-1).*rand;
constants.a31 = 1 + (2-1).*rand;
constants.a32 = 1 + (2-1).*rand;                   

%% Phase 1: estimate active variables in bivariate functions
% Construct hash functions
H = construct_hash(t, d, 0.5);
card_H = size(H, 2);
% if (sigma ~= 0)
%     N1 = ceil((sigma^2 / epsilon^2) * log ( (sqrt(2)*sigma / epsilon * 0.5) * mv * (mv_prime + 1) * (2*mx + 1)^2 * card_H));
%     N1 = 1;
% end;

% Construct set V
V = ones(mv, d);
V(rand(mv, d) > 0.5) = -1;
V = (1/sqrt(mv)) * V;           % Each row is a d-dim vector. It is a mv x d matrix
V = V';                         % V is d x mv    

% Construct set V'
V_prime = ones(mv_prime, d);
V_prime(rand(mv_prime, d) > 0.5) = -1;
V_prime = (1/sqrt(mv_prime)) * V_prime;     % Each row is a d-dim vector. It is a mv_prime x d matrix
V_prime = V_prime';                         % V is d x mv_prime 

c = -1:(1/mx):1;                % Discretization spacing in chi_h sets

% Set up input parameters for parallel computation
constants.mv = mv;
constants.mu = mu;
constants.k = k;
constants.mv_prime = mv_prime;
constants.mu1 = mu1;
constants.k2 = k2;
constants.tau_prime = tau_prime;
if (sigma ~= 0)
    constants.sigma = sigma/sqrt(N1);
    constants.N1 = N1;
else
    constants.sigma = 0;
end;
constants.case = test_case;

Vs.V = V;
Vs.V_prime = V_prime;

fprintf('First phase: computing S2_hat...\n');
fprintf('Time: %s\n', datestr(now));
try
    result = struct([]);
    fprintf('Number of iterations: %d\n', card_H);
    parfor i = 1:card_H,               % For each h \in H ...                
        [result(i).S2_hat, result(i).query_counter] = find_S2_hat_PARALLEL(H, c, Vs, constants, t, S1, S2, i, params);
        fprintf('Done with instance: %d\n', i);
%         result(i).S2_hat
    end;
    fprintf('\nDone!\n');    
    for i = 1:card_H
        S2_hat = [S2_hat; result(i).S2_hat];
        query_counter = query_counter + result(i).query_counter;
    end;
    
catch ME
    warning('something went wrong')
    rethrow(ME)
end       

S2_hat = unique(S2_hat, 'rows');

%% Phase 2: estimate active variables in univariate functions
% Construct chi_diag
chi_diag = construct_chi_diag(mx_prime, d);
card_chi_diag = size(chi_diag, 2);

% Set up some constants
S2_var_hat = unique(S2_hat(:));
if (numel(S2_var_hat) > 3)
    S1_hat = [];
    return
end;

P = setdiff(1:d, S2_var_hat);                                           % Construct P set
mv_dprime = ceil(Csam*(k - numel(S2_var_hat))*log(numel(P)/(k - numel(S2_var_hat))));                % Cardinality of set V''
    
if (sigma == 0)
    mu_prime = 0.5*sqrt(3*mv_dprime*D1/(C3*(k - numel(S2_var_hat))*B3));    % mu_prime constant
    tau_dprime = (C3*mu_prime^2*B3*(k - numel(S2_var_hat)))/(6*mv_dprime);  % tau_dprime constant
else
    a1 = ((k - numel(S2_var_hat))*B3)/(6*mv_dprime);
    b1 = sqrt(mv_dprime);
    epsilon2 = D1^(3/2)/(3*sqrt(6*a1*b1^2*C3^2));
    epsilon_prime = 0.2*epsilon2;
    
    theta2 = acos(-epsilon_prime/epsilon2);
    mu_prime = ( (2*sqrt(D1/(6*a1*C3))*cos(theta2/3 - 2*pi/3)) + (2*sqrt(D1/(6*a1*C3))*cos(theta2/3)) )/2;
    tau_dprime = 0.01 * C3*((mu_prime^2*B3*(k - numel(S2_var_hat)))/(6*mv_dprime) + (b1*epsilon_prime/mu));
end;

% Construct set V''
V_dprime = ones(mv_dprime, d);
V_dprime(rand(mv_dprime, d) > 0.5) = -1;
V_dprime = (1/sqrt(mv_dprime)) * V_dprime;     % Each row is a d-dim vector. It is a mv_prime x d matrix
V_dprime = V_dprime';                          % V is d x mv_dprime 

% Construct Vt_dprime_P
Vt_dprime_P = V_dprime(P, :)';

% Set up input parameters for parallel computation
constants.mv_dprime = mv_dprime;
constants.mu_prime = mu_prime;
constants.k1 = k1;
constants.tau_dprime = tau_dprime;
if (sigma ~= 0)
    constants.sigma = sigma/sqrt(N2);
    constants.N2 = N2;
else
    constants.sigma = 0;    
end;

Vs.V_dprime = V_dprime;
Vs.Vt_dprime_P = Vt_dprime_P;

fprintf('Second phase: computing S1_hat...\n');
fprintf('Time: %s\n', datestr(now));

try
    result = struct([]);
    fprintf('Number of iterations: %d\n', card_chi_diag);
    parfor i = 1:card_chi_diag,               % For each h \in H ...                
        x = chi_diag(:, i);    
        [result(i).S1_hat, result(i).query_counter] = find_S1_hat_PARALLEL(x, Vs, constants, P, S2_var_hat, S1, S2, params);
        fprintf('Done with instance: %d\n', i);
    end;
    fprintf('\nDone!\n');
    for i = 1:card_chi_diag,
        A = result(i).S1_hat;
        S1_hat = [S1_hat; A(:)];
        query_counter = query_counter + result(i).query_counter;
    end;
    
catch ME
    warning('something went wrong')
    rethrow(ME)
end       

S1_hat = unique(S1_hat);
fprintf('Time: %s\n', datestr(now));