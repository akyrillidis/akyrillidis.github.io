function [x_hat, numiter] = zero_ALPS(y, Phi, K, params)
% =========================================================================
%                0-ALPS(5) algorithm - Beta Version
% =========================================================================
% Algebraic Pursuit (ALPS) algorithm with memoryless acceleration. 
% 
% Detailed discussion on the algorithm can be found in 
% [1] "Recipes for Hard Thresholding Methods", written by Anastasios
% Kyrillidis and Volkan Cevher, CAMSAP, 2011.
% =========================================================================
% INPUT ARGUMENTS:
% y                         M x 1 undersampled measurement vector.
% Phi                       M x N regression matrix.
% K                         Sparsity of underlying vector x* or desired
%                           sparsity of solution.
% params                    Structure of parameters. These are:
%
%    tol,...                Early stopping tolerance. Default value: tol =
%                           1-e5
%    ALPSiters,...          Maximum number of algorithm iterations. Default
%                           value: 300. 
%    mode, ...              According to [1], possible values are
%                           [0,1,2,4,5,6]. This value comes from the binary 
%                           representation of the parameters:
%                           (solveNewtob, gradientDescentx, solveNewtonx), 
%                           which are explained next. Default value = 0.
%    useCG,...              Indicates the usage of Conjugate Gradients method
%    cg_maxiter,...         Maximum iterations for Conjugate-Gradients method.
%    cg_tol                 Tolerance variable for Conjugate-Gradients method.                                
% =========================================================================
% OUTPUT ARGUMENTS:
% x_hat                     N x 1 recovered K-sparse vector.
% numiter                   Number of iterations executed.
% =========================================================================
% 01/04/2011, by Anastasios Kyrillidis. anastasios.kyrillidis@epfl.ch, EPFL.
% =========================================================================
% cgsolve.m is written by Justin Romberg, Caltech, Oct. 2005.
%                         Email: jrom@acm.caltech.edu
% =========================================================================
% This work was supported in part by the European Commission under Grant 
% MIRG-268398 and DARPA KeCoM program #11-DARPA-1055. VC also would like 
% to acknowledge Rice University for his Faculty Fellowship.
% =========================================================================

[~, N] = size(Phi);

%% Initialize transpose of measurement matrix

Phi_t = Phi';
cg_verbose = 0;
cg_A = Phi_t*Phi;
cg_b = Phi_t*y;

%% Initialize to zero vector
x_cur = zeros(N,1);
X_i = [];

%% Help variables
complementary_Xi = ones(N,1);

i = 1;
%% 0-ALPS(#)
while (i <= params.ALPSiters)
    x_prev = x_cur;

    % Compute the residual
    if (i == 1)
        res = y;
    else         
        Phi_x_cur = Phi(:,X_i)*x_cur(X_i);
        res = y - Phi_x_cur;
    end;
    
    % Compute the derivative
    der = Phi_t*res;         
    
    % Determine S_i set via eq. (11)
    complementary_Xi(X_i) = 0;
    [~, ind_der] = sort(abs(der).*complementary_Xi, 'descend');
    complementary_Xi(X_i) = 1;
    S_i = [X_i; ind_der(1:K)];
           
    if (params.useCG == 1)
        [b, ~, ~] = cgsolve(cg_A(S_i, S_i), cg_b(S_i), params.cg_tol, params.cg_maxiter, cg_verbose);
    else
        b = cg_A(S_i,S_i)\cg_b(S_i);
    end;        

    % Hard-threshold b and compute X_{i+1}
    [~, ind_b] = sort(abs(b), 'descend');
    x_cur = zeros(N,1);
    x_cur(S_i(ind_b(1:K))) = b(ind_b(1:K));
    X_i = S_i(ind_b(1:K));

    % Similar to HTP
    if (params.useCG == 1)
        [v, ~, ~] = cgsolve(cg_A(X_i, X_i), cg_b(X_i), params.cg_tol, params.cg_maxiter, cg_verbose);
    else
        v = cg_A(X_i,X_i)\cg_b(X_i);
    end;
    x_cur(X_i) = v;
     
    % Test stopping criterion
    if (i > 1) && (norm(x_cur - x_prev) < params.tol*norm(x_cur))
        break;
    end;
    i = i + 1;  
      
end;

x_hat = x_cur;
numiter = i;