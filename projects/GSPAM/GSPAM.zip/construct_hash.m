function [H] = construct_hash(t, d, q)

% By theory, cardinality of H is O(te^t log(d))
card_H = ceil(1.1 * 2 * exp(2) * log(d));
H = t*ones(d, card_H);
temp = rand(d, card_H);
H(temp <= q) = t-1;         % To extend to bigger than t = 2 values, we have to change this.