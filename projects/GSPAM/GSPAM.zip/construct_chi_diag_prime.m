function chi_diag_prime = construct_chi_diag_prime(mx, d, lambda1, lambda2)

c = -1:(1/mx):1;
chi_diag = [];

% For all combinations of c values...
for i = 1:numel(c)
    u = c(i)*ones(d, 1);
    for j = 1:ceil(lambda2/lambda1) - 1
        x = u + ones(d, 1)*j/(ceil(lambda2/lambda1)*mx);
        chi_diag = [chi_diag x];
    end;    
end;

