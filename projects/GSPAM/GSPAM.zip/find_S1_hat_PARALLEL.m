function [S1_hat, query_counter] = find_S1_hat_PARALLEL(x, Vs, constants, P, S2_var_hat, S1, S2, params)

query_counter = 0;
 
S1_hat = [];

y = zeros(constants.mv_dprime, 1);

% Compute y for all mv points
for l = 1:constants.mv_dprime
    x1 = x + constants.mu_prime * Vs.V_dprime(:, l); x1(S2_var_hat) = 0;
    x2 = x - constants.mu_prime * Vs.V_dprime(:, l); x2(S2_var_hat) = 0;
    
    if (constants.sigma == 0)
        % Compute f(x + mu*v)
        f_plus = query_GSPAM(x1, S1, S2, constants);

        % Compute f(x - mu*v)
        f_minus = query_GSPAM(x2, S1, S2, constants);

        % Compute y
        y(l) = (f_plus - f_minus)/(2*constants.mu_prime);
        query_counter = query_counter + 2;
    else
        f_plus = 0;
        % Compute f(x + mu*v)
        f_plus = f_plus + query_GSPAM(x1, S1, S2, constants);

        f_minus = 0;
        % Compute f(x - mu*v)
        f_minus = f_minus + query_GSPAM(x2, S1, S2, constants);

        % Compute y
        y(l) = (f_plus - f_minus)/(2*constants.mu_prime);
        query_counter = query_counter + 2*constants.N1;
    end;
end;   

% Solve l0-norm minimization using ALPS
[gradP, ~] = one_ALPS(y, Vs.Vt_dprime_P, constants.k1, params);

for q = 1:numel(P)
    if (abs(gradP(q)) > constants.tau_dprime)
        S1_hat = union(S1_hat, P(q));
    end;
end;    
