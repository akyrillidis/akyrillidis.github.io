function chi_h = construct_chih(E, c)

[d, t] = size(E);

[p,q] = meshgrid(c, c);             % Create mesh based on c ...
combs = [p(:) q(:)];                % ... and compute all combinations
number_combs = length(combs);       

chi_h = zeros(d, number_combs);

% For all combinations of c values...
for i = 1:number_combs
    x = zeros(d, 1);
    comb = combs(i, :);
    for j = 1:t
        x = x + comb(j)*E(:, j);        % Construct x in chi_h
    end;
    chi_h(:, i) = x;
end;

