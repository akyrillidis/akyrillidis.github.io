clear all
close all
clc

cd('./PROPACK');
install_mex;
cd('..');