function [ C ] = ballCartesianSample(dim, pow)
    
    C = randn(dim, pow);
    C = C * diag(sum(C.^2, 1).^-0.5);
end

