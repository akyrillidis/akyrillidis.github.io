function [X, Y] = bccbilinear(B, k, r, maxsamples)

% Ensure that B is a valid bi-adjacency matrix. (For now, allow 0's).
assert(~any(B(:) ~= 0 & B(:) ~= 1 & B(:) ~= -1))

[n , m] = size(B);

% Set up parameters for the bilinear-maximization solver.
params.xsolver = @(W) binary_disjoint(W);
params.ysolver = @(W) binary_disjoint(W');
params.numcomponents = k;
params.approxrank = r;
params.maxsamples = maxsamples;

% Solve the bilinear maximization.
[X, Y] = maxbilinearlowrank(B, params);

assert(isequal([n, k], size(X)))
assert(isequal([m, k], size(Y)))