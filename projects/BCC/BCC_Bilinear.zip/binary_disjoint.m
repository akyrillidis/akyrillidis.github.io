function X = binary_disjoint(L)

[n, d] = size(L);
[~, I] = max(L, [], 2);

X = sparse(1:n, I, 1, n, d, n);