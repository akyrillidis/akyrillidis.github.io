clear
clc
close all 

dataFile = 'data/ml-100k-ratings.data';

% Load ratings.
ratings = dlmread(dataFile, ':', 0, 0);

% Clean ratings from undesirable columns
ratings = ratings(:, any(ratings));

% Remove timestamp
ratings = ratings(:, 1:3);          % Keep original ratings
bi_ratings = ratings;               % Store binarized ratings

% Number of ratings
numRatings = length(ratings(:, 1));

% Generate observed data by comparing to average rating in dataset
averageRating = mean(bi_ratings(:, 3));
bi_ratings(:, 3) = sign(bi_ratings(:, 3) - averageRating);

% Construct bi-adjacency matrix of weighted {-1, 0, 1} bipartite graph.
B = spconvert(bi_ratings);
[nUsers, nMovies] = size(B);

% Graph info
nPos = full(sum(B(:)>0));
nNeg = full(sum(B(:)<0));
nEdg = nPos + nNeg;
fprintf('Total No. of weighted edges: %d (%.2f%% complete.)\n',...
        nEdg, nEdg * 100 / numel(B))
fprintf('No. positive edges: %d (%.2f%% of edges)\n',...
        nPos, nPos / nEdg * 100);
fprintf('No. negative edges: %d (%.2f%% of edges)\n',...
        nNeg, nNeg / nEdg * 100);
fprintf('No. zero-weight edges: %d\n', nUsers * nMovies - nEdg);

% Run BCC algorithm.

r = 5;                              % Approximation rank parameter
kValArray = [2:2:10 15:5:25];       % Various values for maximum number of clusters

agreeVsNCluster = zeros(1, numel(kValArray));

fig = figure();

for iK = 1:numel(kValArray)
    
    k = kValArray(iK);
    maxsamples = 1000 * k;  % Number of samples our algorithm will use (iterations in main loop)

    fprintf('Running for k=%d clusters (r=%d)...', k, r)
    
    tic;
    % Compute the clustering matrices for U and V - main algorithm
    [X, Y] = bccbilinear(B, k, r, maxsamples);
    runTimeVsNCluster(iK) = toc;
    
    % Count the number of agreements on the bi-adjacency B.
    agreeVsNCluster(iK) = bcccountagreements(B, X, Y);
    
    fprintf('BCC: Achieved %d agreements in %d seconds (k=%d clusters).\n',...
        agreeVsNCluster(iK), runTimeVsNCluster(iK), k);
    
    figure(fig);
    plot(kValArray(1:iK), agreeVsNCluster(1:iK),...
        'Color', [245, 184, 0]/255,...
        'LineStyle', '--',...
        'LineWidth', 2,...
        'Marker', 'o',...
        'MarkerEdgeColor', [61, 61, 61]/255,...
        'MarkerFaceColor', [245, 184, 0]/255,...
        'MarkerSize', 10)
    shg;
    
    set(gca, 'XGrid', 'on');
    set(gca, 'YGrid', 'on');
    set(gca, 'YMinorGrid', 'on');
    
    pause(1)
end

xlabel('No. of clusters $(k)$', 'Interpreter', 'Latex')
ylabel('No. of agreements', 'Interpreter', 'Latex')
title('No of Agreements vs No of clusters.', 'Interpreter', 'Latex')
