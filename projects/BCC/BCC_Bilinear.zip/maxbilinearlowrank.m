function [X, Y, val] = maxbilinearlowrank(B, params)

% Set up parameters of the algorithm
DEFAULT_MAXSECONDS = 3600;
DEFAULT_MAXITERNOUPD = Inf;
DEFAULT_ITERNOTIMECHECKWINDOW = 1000;

[n, m] = size(B);

xSolver = params.xsolver;
ySolver = params.ysolver;

apprRank = params.approxrank;
assert(apprRank <= min([n, m]));

maxIterNo = params.maxsamples;

if isfield(params, 'numcomponents')
    numcomponents = params.numcomponents;
else
    msgID = 'MAXBILINEARLOWRANK:UnspecifiedParameter:numcomponents';
    msg = 'Parameter numcomponents not specified.';
    baseException = MException(msgID,msg);
    throw(baseException)
end

% Parse option: maxiternoupd
% (maximum number of iterations without any update of the objective value.)
if isfield(params, 'maxiternoupd')
    maxiternoupd = params.maxiternoupd;
else
    maxiternoupd = DEFAULT_MAXITERNOUPD;
end

% Parse option: maxexecseconds
% (Seconds after which execution is terminated.)
if isfield(params, 'maxexecseconds')
    maxexecseconds = params.maxexecseconds;
else
    maxexecseconds = DEFAULT_MAXSECONDS;
end

% Compute a lowrank approximation (rank=apprRank).
% You can change this step with randomized variants for faster execution.
[U_, S_, V_] = svds(double(B), apprRank);

% Initialization
optVal = -Inf;  % optimal objective value.
iterCtr = 0;  % number of iterations/samples considered.
lastUpd = 0;  % number of iterations since last objective value update.
lastTCh = 0;  % number of iternations since last time check.

tStart = tic;

while(true)

    if lastUpd > maxiternoupd
        fprintf('Reached maximim number of iterations without update.\n');
        fprintf('Terminating...\n');
        break; 
    end
    
    if iterCtr > maxIterNo
        fprintf('Reached maximum number (%d) of iterations.\n', maxIterNo);
        fprintf('Terminating...\n');
        break;
    end
    
    iterCtr = iterCtr + 1;
    lastTCh = lastTCh + 1;
    
    if lastTCh > DEFAULT_ITERNOTIMECHECKWINDOW
        % Check if total execution time exceeds user specified threshold.
        % (Check is not performed in every iteration because it affects
        % performance).
        timerunning = toc(tStart);
        if timerunning > maxexecseconds
           fprintf(['Reached maximum time limit',...
                    '(running %d seconds, limit was %d seconds).\n'],...
                    timerunning, maxexecseconds);
           fprintf('Terminating...\n');
           break; 
        end
        lastTCh = 0;  %reset
        fprintf('.');
        
        % fprintf('[%d] cur best: %f. %s remaining.\n',...
        %         proc_id, optVal,...
        %         datestr((maxtimelim-timerunning)/86400, 'HH:MM:SS'));
    end
    
    % Compute candidate X,Y pair.
    L = U_ * S_ * ballCartesianSample(apprRank, numcomponents);
    X = xSolver(L);
    R = ((X' * U_) * S_) * V_';
    Y = ySolver(R);
    
    % Update optimal value with the objective value achieved by the last
    % candidate pair (if it is larger than current optimal value).
    val = trace(R * Y);
    if val > optVal
        optVal = val;
        optX = X;
        optY = Y;
        lastUpd = 0;
    else
        % No update.
        lastUpd = lastUpd + 1;
    end
    
end

X = optX;
Y = optY;
val = optVal;

return

end

