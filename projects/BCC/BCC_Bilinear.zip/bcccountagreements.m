function agree = bcccountagreements(B, X, Y)
% BCCCOUNTAGREEMENTS counts the number of agreements in a solution of an
%   instance of the bipartite correlation clustering problem.
%   AGREE = BCCCOUNTAGREEMENTS(B,X,Y) returns the number of agreements
%   achieved by a clustering of the vertices of a bipartite graph 
%   G = (U,V,E) with bi-adjacency |U| x |V| matrix B described by X (for
%   the clustering of vertices in U) and Y (for the clustering of vertices
%   in V). X can one of the following forms:
%   - Binary |U| x k cluster membershipt matrix, whose rows correspond to
%     vertices of U and its columns to clusters. Each vertex must be
%     assigned to one cluster (i.e., each row of X must have exactly one
%     element equal to 1).
%   - Vector of length |U| with elements in the range 1:|U|+|V| describing
%     corresponding to the cluster labels of vertices in U. If Xi = r, then
%     vertex i (in U) belongs to cluster r.
%   Y is defined similarly for the vertices in V.

B = double(B); %  Required by certain operations.

[n, m] = size(B);

if isvector(X) && isvector(Y)
   % Clustering given in the form of labels.
   agree = countagreementsfromclusteringlabels(B, X, Y);
   return
end

[xn, xk] = size(X);
[ym, yk] = size(Y);
assert(n==xn && m==ym)
assert(xk==yk)

% Clustering given by clustering matrices
assert(isValidClusteringMatrix(X))
assert(isValidClusteringMatrix(Y))
assert(~any(B(:) ~= 0 & B(:) ~= 1 & B(:) ~= -1))

agree = countagreementsfromclusteringmatrices(B, X, Y);

end

function agree = countagreementsfromclusteringmatrices(B, X, Y)
agree = trace(X' * B * Y) + sum(B(:) == -1);
end

function agree = countagreementsfromclusteringlabels(B, X, Y)

[n, m] = size(B);

labelArray = unique([X(:); Y(:)]);
noClusters = numel(labelArray);
% Reset to default labels:
Xreset = zeros(size(X));
Yreset = zeros(size(Y));
for l = 1:numel(labelArray)
    label = labelArray(l);
    Xreset(X == label) = l;
    Yreset(Y == label) = l;
end

Cx = sparse(1:n, Xreset, 1,...
            n, noClusters, n);
Cy = sparse(1:m, Yreset, 1,...
            m, noClusters, m);

agree = countagreementsfromclusteringmatrices(B, Cx, Cy);

end

function t = isValidClusteringMatrix(X)

t = true;

% Check if X is a binary matrix.
if any(X(:) ~= 0 & X(:) ~= 1)
    t = false;
    return;
end

% Check that every element is assigned to exactly one cluster.
if any(sum(X, 2) ~= 1)
    t = false;
    return;
end

end