function S = rankD_compute_candidates(V,N,D,M)

% S = rankD_compute_candidates(V,N,D) returns a matrix whose columns are the
% corresponding M-phase vector candidates s for the maximization of
% (s^H)*V*(V^H)*s.

s = exp(1i*2*pi*(0:M-1)'/M);                % M-PSK alphabet
V_tilde = V_tilde_construction(V,N,D,M);    % v_tilde construction
% V_tilde
S = [];
combinations_checked = [];

if 2*D > 2
    combinations = nchoosek(1:M*N/2, 2*D-1);
    [combs_rows, junk] = size(combinations);
%     pause;
    idx = 1;
    
    for i = 1:combs_rows  
%         i
        I = combinations(i,:); %
%         I = [1 7 3 9 18]
        VI = V_tilde(I,:); %
        [I, index_same_rotated_H, not_valid, VI, p, single_I,app_I] = find_same_rotated_H(I,N,VI); %
        
        [H_families] = get_same_rotated_families(I, V_tilde, N, M, p); %
%         pause;
        if (not_valid)
%             keyboard
            continue;
        else
            c_tilde = find_intersection(VI); %
            [phi, sign_c] = determine_phi_sign_c(c_tilde); %
%             pause;

            if (phi(2*D-1) > -pi/M && phi(2*D-1) <= pi/M)
                if (p > 0)                   
                    [is_member, combinations_checked] = append_combinations(combinations_checked, sort(app_I)); %
                else is_member = 0;
                end;                             
                if (is_member)
                     continue;
                else
                    S = [S zeros(N,(M/2-1)^p)];
                    c_tilde = c_tilde*sign_c;
                    c = c_tilde(2:2:2*D) + 1i*c_tilde(1:2:2*D-1);

                    count_idx = 1;
                    for k=1:N
%                         V(k,:)
                        v_c = V(k,:)*c;        
%                         real(conj(s).*v_c)
%                         pause;
                        [res,s_idx] = max(real(conj(s).*v_c));
                        S(k,idx:(idx + (M/2-1)^p - 1)) = s(s_idx);
%                         I
%                         k
%                         if (i == 13696)
%                             keyboard
%                         end;
                        if (sum(ismember(I,k)) == 1)                
                            ambiguity_idx(1:2,count_idx) = find(roundn(max(real(conj(s).*v_c)),-8) == roundn(real(conj(s).*v_c),-8));
                            count_idx = count_idx + 1;
                        end;
                    end;
%                     S(:,idx:(idx + (M/2-1)^p - 1))
%                     ambiguity_idx
%                     pause;

                    % Dissabiguate 'other' surfaces
                    count_idx = 1;
                    for d = (2*p+1):2*D-1
%                         VI([1:d-1 d+1:2*D-1],1:2*D-1)
%                         pause;
                        c_tilde = find_intersection(VI([1:d-1 d+1:2*D-1],1:2*D-1));
                        [phi, sign_c] = determine_phi_sign_c(c_tilde);
                        c_tilde = c_tilde*sign_c;
                        c_tilde = [c_tilde; 0];
                        c = c_tilde(2:2:2*D) + 1i*c_tilde(1:2:2*D-1); %

%                         I
%                         single_I
%                         [junk, loc] = find(sort(I) == I(d))
                        [junk, loc] = find(sort(single_I) == I(d)); %
                        v_c = V(I(d),:)*c;
                        metric = real(conj(s).*v_c); %
%                         ambiguity_idx(:,loc)
%                         [res,ind] = max(metric(ambiguity_idx(:,count_idx)))
%                         S(I(d),idx:(idx + (M/2-1)^p - 1)) = s(ambiguity_idx(ind,count_idx))
                        [res,ind] = max(metric(ambiguity_idx(:,loc))); %
                        S(I(d),idx:(idx + (M/2-1)^p - 1)) = s(ambiguity_idx(ind,loc)); %
                        count_idx = count_idx + 1;                    
%                         pause;
                    end;
%                     S(:,idx:(idx + (M/2-1)^p - 1))
%                     pause;
                    ambiguity_idx = [];

                    for h = 1:p
%                        H_families((h-1)*(M/2)+1:h*(M/2),:)
                       [sorted_family, H_family, H_other] = sort_ambiguity_family(H_families((h-1)*(M/2)+1:h*(M/2),:), VI([(1:(2*h-1)-1) (2*h+1):2*D-1],:),D,M); %
%                        pause;
                       for k=1:M/2-1
                           ambiguity_idx = [];
                           count_idx = 1;
                           for n=1:2
%                                [H_other(:,1:2*D-1); H_family(sorted_family(k+(n-1)), 1:2*D-1)]
%                                pause;
                               c_tilde = find_intersection([H_other(:,1:2*D-1); H_family(sorted_family(k+(n-1)), 1:2*D-1)]); %
%                                pause;
                               [phi, sign_c] = determine_phi_sign_c(c_tilde); %
                               c_tilde = c_tilde*sign_c;
                               c_tilde = [c_tilde; 0];
                               c = c_tilde(2:2:2*D) + 1i*c_tilde(1:2:2*D-1);

%                                I(2*h-1)
                               v_c = V(I(2*h-1),:)*c;
%                                metric = real(conj(s).*v_c)
                               ambiguity_idx(1:2,count_idx) = find(roundn(max(real(conj(s).*v_c)),-4) == roundn(real(conj(s).*v_c),-4)); %
                               count_idx = count_idx + 1;
%                                pause;
                           end;
                           helper_S(h,k) = s(intersect(ambiguity_idx(:,1), ambiguity_idx(:,2))); %
%                            pause;
                       end;                   
                    end;
                    ambiguity_idx = [];

                    if (p > 0)
                        indices = ones(p,1);                                
                        for k=1:(M/2 - 1)^p
                            [indices, dissambiguated_s] = compute_combs_dissambiguated_s(helper_S, indices,M); %
%                             pause;
                            for h=1:p
                                S(I(2*h-1),idx+(k-1)) = dissambiguated_s(h);
                            end;
                        end;
                    end;
%                     S                                        
%                     keyboard
                                                            
%                     helper_S_I = [helper_S_I [I' S(:,idx:(idx + (M/2-1)^p - 1))]];
%                     tsi = transpose(S(:,idx:(idx + (M/2-1)^p - 1)));
%                     [a,b] = size(tsi);
%                     help_S = transpose(S(:,1:idx-1));
%                     if (isempty(help_S))
%                         continue
%                     else
%                         for i=1:a
%                             [res, loc] = ismember(tsi(i,:), help_S, 'rows');
%                             if (res > 0)
%                                 loc
%                                 keyboard
%                             end;
%                         end;
%                     end;
%                     
                    idx = idx + (M/2-1)^p;
                    helper_S = [];
%                   pause;
                    
                end;
            end;
        end;
%         S
%         pause;
    end;    
%     size(S)
%     keyboard;
    S = [S rankD_compute_candidates(V(:,1:D-1),N,D-1,M)];
elseif 2*D == 2
    phi_crosses = atan(-V_tilde(:,2)./V_tilde(:,1));
    [phi_sort, junk] = sort(phi_crosses);
    phi_mid = (phi_sort(1:end-1)+phi_sort(2:end))/2;
    
    counter = 1;
    for i=1:length(phi_mid)
        if (phi_mid(i) > -pi/M && phi_mid(i) <= pi/M)        
            c = cos(phi_mid(i)) + 1i*sin(phi_mid(i));
            for k=1:N                       
                v_c = V(k,:)*c;        
                [res,ind] = max(real(conj(s).*v_c));
                S(k,counter) = s(ind);                         
            end;
            counter = counter + 1;        
        end;
    end;
%     size(S)
%     pause;
end;
    