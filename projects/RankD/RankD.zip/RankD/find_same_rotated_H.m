function [mod_I, index_same_rotated_H, not_valid, VI, p, single_I, app_I] = find_same_rotated_H(I,N,VI)

index_same_rotated_H = [];
index_single_H = [];
help_structure_VI = [];
help_structure_I = [];
app_I = [];

mod_I = mod(I, N);
[loc] = find(mod_I == 0);
mod_I(loc) = N;
not_valid = 0;

% help_structure = [mod_I' VI];
% help_structure = sortrows(help_structure,1);
% mod_I = help_structure(:,1);
% VI = help_structure(:,2:end);

for i=1:length(mod_I)
    if (~ismember(mod_I(i), index_same_rotated_H))
        if (length(find(mod_I == mod_I(i))) > 2)
            not_valid = 1;
        elseif (length(find(mod_I == mod_I(i))) == 2)
            index_same_rotated_H = [index_same_rotated_H mod_I(i)];
        elseif (length(find(mod_I == mod_I(i))) == 1)
            index_single_H = [index_single_H mod_I(i)];
        end;
    end;
end;

for i=1:length(index_same_rotated_H)
    ind = mod_I == index_same_rotated_H(i);
    help_structure_VI = [help_structure_VI; VI(ind,:)];
    help_structure_I = [help_structure_I mod_I(ind)];
    app_I = [app_I mod_I(ind)];
end;

for i=1:length(index_single_H)
    ind = mod_I == index_single_H(i);
    help_structure_VI = [help_structure_VI; VI(ind,:)];
    help_structure_I = [help_structure_I mod_I(ind)];
    app_I = [app_I I(ind)];
end;

VI = help_structure_VI;
mod_I = help_structure_I;
p = length(index_same_rotated_H);
single_I = index_single_H;