function [sorted_family, H_family, H_other] = sort_ambiguity_family(H_family, H_other, D, M)

[rows, cols] = size(H_family);
phi = zeros(2*D-2, rows);

for i=1:rows
    helper_VI = [H_other(:,1:2*D-1); H_family(i,1:2*D-1)];
    c_tilde = null(helper_VI);
    [helper_phi, sign_c] = determine_phi_sign_c(c_tilde);
    phi(:,i) = sign_c*helper_phi;
end;

sorted_family = [phi(2*D-2,:)' (1:M/2)'];
sorted_family = sortrows(sorted_family,1);
sorted_family = sorted_family(:,end);   