function [H_families] = get_same_rotated_families(I, V_tilde, N, M, p)

H_families = [];

for i=1:p
    H_families = [H_families; V_tilde(I(2*i-1):N:M*N/2,:)];
end;