function V_tilde = V_tilde_construction(V,N,D,M)

V_tilde = zeros(M*N/2, 2*D);

b = exp(-1i*pi*(2*(0:M/2-1)+1)/M);      % Boundary construction
b = transpose(b);

V_hat = kron(b,V);

index = 1;
for i = 1:2:2*D-1
    V_tilde(:,i) = real(V_hat(:,index));
    index = index + 1;
end;

index = 1;
for i = 2:2:2*D
    V_tilde(:,i) = imag(V_hat(:,index));
    index = index + 1;
end;