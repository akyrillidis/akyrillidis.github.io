function [indices, dissambiguated_s] = compute_combs_dissambiguated_s(helper_S, indices, M)

[rows, cols] = size(indices);
for i=1:rows
    dissambiguated_s(i) = helper_S(i,indices(i));
end;

for i=0:rows-1
    if (mod(indices(end-i,1),(M/2-1)) ~= 0)
        indices(end-i,1) = indices(end-i,1) + 1;
        break;
    else
        indices(end-i,1) = 1;
    end;
end;