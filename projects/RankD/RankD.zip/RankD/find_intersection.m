function c_tilde = find_intersection(VI)

[row col] = size(VI);
assert(min(row,col) == rank(VI), 'Not full rank...');
c_tilde = null(VI);
