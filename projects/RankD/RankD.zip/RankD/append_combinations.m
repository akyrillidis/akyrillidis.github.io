function [is_member, combinations_checked] = append_combinations(combinations_checked,I)

[is_member, loc] = ismember(I, combinations_checked, 'rows');
if (is_member == 0)
    combinations_checked = [combinations_checked; I];
end;