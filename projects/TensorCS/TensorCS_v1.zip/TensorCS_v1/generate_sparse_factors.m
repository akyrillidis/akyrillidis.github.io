function A = generate_sparse_factors(M, F, k)

A = zeros(M, F);

for f = 1:F
    x = randn(M,1);
    [~, ind] = sort(abs(x), 'descend');
    A(ind(1:k), f) = randn(k, 1);
    A(:, f) = A(:, f)/norm(A(:, f));
end;