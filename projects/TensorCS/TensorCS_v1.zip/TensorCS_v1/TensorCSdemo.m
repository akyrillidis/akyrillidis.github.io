% =========================================================================
%                   Compressed Tensors - Demo
% =========================================================================
% Background:
%
% Assume we acquire a three-way, F-rank tensor X with dimensions I x J x K 
% with PARAFAC decomposition:
% 
%       X = sum_{f = 1}^{F} [(a_f) o (b_f) o (c_f)]   (o = outer product)
%
% where a_f is the f_th column of A, b_f is the f_th column of B and c_f is
% the f_th column of C such that:
%
%               tall_X = (B (KR) A)C' for A (I x F), B (J x F), C (K x F),
%
% where tall_X = [vec(X_1), ..., vec(X_K)], vec(X_i) is the i-th (I x J)
% slab of X and (KR) operator denotes the Khatri-Rao prdocut operator.
%
% Problem statement:
%
% Assume that we "compress" A, B and C such that:
%
%           A_tilde = U'*A where A_tilde is L x F
%           B_tilde = V'*B where B_tilde is M x F
%           C_tilde = W'*C where C_tilde is N x F
%
% Using the vectorized compressed tensor:
%  
%           y = (A_tilde (KR) B_tilde (KR) C_tilde)*ones(LMN,1)
%
% we desire to reconstruct the true A,B,C given the apriori information
% that each tensor factor a_f, b_f and c_f is sparse, i.e.,
%
%    min_{A, B, C} || y - ( (U'A) (KR) (V'B) (KR) (W'C) )*ones(LMN,1) ||_2
%
%        subject to ||a_f||_0 <= n_a,   f = {1, ..., F}
%                   ||b_f||_0 <= n_b,   f = {1, ..., F}
%                   ||c_f||_0 <= n_c,   f = {1, ..., F}
% 
% Detailed discussion on the algorithm can be found in 
% [1] "Multi-way Compressed Sensing for Sparse Low-rank Tensors", written
% by Nicholas D. Sidiropoulos, and Anastasios Kyrillidis, submitted, 2012.
% =========================================================================
% 25/08/2012, by Anastasios Kyrillidis, anastasios.kyrillidis@epfl.ch, EPFL.
%                Nicholaos Sidiropoulos, nikos@umn.edu, UMN.
% =========================================================================

clear all
close all
clc

addpath algo/;
addpath algo/spgl1-1.7/;
addpath algo/ALPS/;

%% General parameters
I = 500;         % A is I x F
J = 500;         % B is J x F
K = 500;         % C is K x F
F = 20;          % Tensor rank

L = 200;         % A_tilde is L x F
M = 200;         % B_tilde is M x F
N = 200;         % C_tilde is N x F

ka = ceil(L*(0.2));         % Sparsity per column in A
kb = ceil(M*(0.2));         % Sparsity per column in B
kc = ceil(N*(0.2));         % Sparsity per column in C

%% Algorithmic parameters
params.ALPSiters = 500;
params.tol = 1e-8;

%% Generate Uncompressed Tensor data

% Sparse factors have unit norm
A = generate_sparse_factors(I, F, ka); 
B = generate_sparse_factors(J, F, kb);
C = generate_sparse_factors(K, F, kc);

X = zeros(I, J, K);

for k = 1:K
    X(:,:,k) = A*diag(C(k,:))*B.';
end;

%% Generate Compressed Tensor data

U = 1/sqrt(L)*randn(L, I);      % U is random compression matrix for the I-mode
V = 1/sqrt(M)*randn(M, J);      % V is random compression matrix for the J-mode
W = 1/sqrt(N)*randn(N, K);      % W is random compression matrix for the K-mode

G1 = reshape(X, I, J*K);
G2 = reshape(U*G1,L*J,K).';
G3 = reshape(W*G2,L*N,J).';
G4 = reshape(V*G3,M*N,L).';
Y = reshape(G4,L,M,N);          % this is the compressed tensor

%% Decompose compressed tensor Y into factors
[A_tilde, B_tilde, C_tilde, modelfiterror] = comfac(Y,F);

if modelfiterror > 100*eps
    disp('Alert: potential local minimum in CP fitting');
end

%% Allocate memory for A_hat, B_hat, C_hat

% SPGL1 Lasso
spgl_A_hat = zeros(I, F);
spgl_B_hat = zeros(J, F);
spgl_C_hat = zeros(K, F);

% 0-ALPS(5)
zero_ALPS_A_hat = zeros(I, F);
zero_ALPS_B_hat = zeros(J, F);
zero_ALPS_C_hat = zeros(K, F);

% 1-ALPS(2)
one_ALPS_A_hat = zeros(I, F);
one_ALPS_B_hat = zeros(J, F);
one_ALPS_C_hat = zeros(K, F);

%% If A_tilde, B_tilde, C_tilde are given...

% For each column of A_tilde, solve a Lasso instance using SPGL1 BPDN
opts = spgSetParms('verbosity',0, 'optTol', params.tol);
disp('-----------------------------------------------------');
textprogressbar('SPGL1 sparse decoding: ');
t = clock;
for ii = 1:F
    textprogressbar(100/F *ii);
    spgl_A_hat(:, ii) = spg_bpdn(U, A_tilde(:, ii), 0, opts);
    spgl_A_hat(:, ii) = spgl_A_hat(:, ii)/norm(spgl_A_hat(:, ii));
    spgl_B_hat(:, ii) = spg_bpdn(V, B_tilde(:, ii), 0, opts);
    spgl_B_hat(:, ii) = spgl_B_hat(:, ii)/norm(spgl_B_hat(:, ii));
    spgl_C_hat(:, ii) = spg_bpdn(W, C_tilde(:, ii), 0, opts);
    spgl_C_hat(:, ii) = spgl_C_hat(:, ii)/norm(spgl_C_hat(:, ii));
end;
textprogressbar(' ');
disp(' ');
time_elapsed = etime(clock, t);
str = sprintf('Time elapsed: %f sec', time_elapsed);
disp(str);

spgl_A_hat = perm2match(spgl_A_hat, A);
spgl_B_hat = perm2match(spgl_B_hat, B);
spgl_C_hat = perm2match(spgl_C_hat, C);

disp(' ')
disp('==================== SPGL1 ==========================');
str = sprintf('Error in A component: || A - A_hat ||_F = %.8f', norm(abs(A) - abs(spgl_A_hat), 'fro'));       % Up to signs...
disp(str);
str = sprintf('Error in B component: || B - B_hat ||_F = %.8f', norm(abs(B) - abs(spgl_B_hat), 'fro'));       % Up to signs...
disp(str);
str = sprintf('Error in C component: || C - C_hat ||_F = %.8f', norm(abs(C) - abs(spgl_C_hat), 'fro'));       % Up to signs...
disp(str);
disp('=====================================================');

disp(' ');
% For each column of A_tilde, solve a Lasso instance using 0-ALPS(5)
disp('-----------------------------------------------------');
textprogressbar('0-ALPS(5) sparse decoding: ');
t = clock;
for ii = 1:F
    textprogressbar(100/F *ii);
    zero_ALPS_A_hat(:, ii) = zero_ALPS(A_tilde(:, ii), U, size(U, 2), ka, params);
    zero_ALPS_A_hat(:, ii) = zero_ALPS_A_hat(:, ii)/norm(zero_ALPS_A_hat(:, ii));
    zero_ALPS_B_hat(:, ii) = zero_ALPS(B_tilde(:, ii), V, size(V, 2), kb, params);
    zero_ALPS_B_hat(:, ii) = zero_ALPS_B_hat(:, ii)/norm(zero_ALPS_B_hat(:, ii));
    zero_ALPS_C_hat(:, ii) = zero_ALPS(C_tilde(:, ii), W, size(W, 2), kc, params);
    zero_ALPS_C_hat(:, ii) = zero_ALPS_C_hat(:, ii)/norm(zero_ALPS_C_hat(:, ii));    
end;
textprogressbar(' ');
time_elapsed = etime(clock, t);
str = sprintf('Time elapsed: %f sec', time_elapsed);
disp(str);


zero_ALPS_A_hat = perm2match(zero_ALPS_A_hat, A);
zero_ALPS_B_hat = perm2match(zero_ALPS_B_hat, B);
zero_ALPS_C_hat = perm2match(zero_ALPS_C_hat, C);

disp(' ')
disp('==================== 0-ALPS(5) ======================');
str = sprintf('Error in A component: || A - A_hat ||_F = %.8f', norm(abs(A) - abs(zero_ALPS_A_hat), 'fro'));       % Up to signs...
disp(str);
str = sprintf('Error in B component: || B - B_hat ||_F = %.8f', norm(abs(B) - abs(zero_ALPS_B_hat), 'fro'));       % Up to signs...
disp(str);
str = sprintf('Error in C component: || C - C_hat ||_F = %.8f', norm(abs(C) - abs(zero_ALPS_C_hat), 'fro'));       % Up to signs...
disp(str);
disp('=====================================================');

disp(' ');
% For each column of A_tilde, solve a Lasso instance using 1-ALPS(2)
disp('-----------------------------------------------------');
textprogressbar('1-ALPS(2) sparse decoding: ');
t = clock;
for ii = 1:F
    textprogressbar(100/F *ii);
    one_ALPS_A_hat(:, ii) = one_ALPS(A_tilde(:, ii), U, size(U,1), size(U, 2), ka, params);
    one_ALPS_A_hat(:, ii) = one_ALPS_A_hat(:, ii)/norm(one_ALPS_A_hat(:, ii));
    one_ALPS_B_hat(:, ii) = one_ALPS(B_tilde(:, ii), V, size(V,1), size(V, 2), kb, params);
    one_ALPS_B_hat(:, ii) = one_ALPS_B_hat(:, ii)/norm(one_ALPS_B_hat(:, ii));
    one_ALPS_C_hat(:, ii) = one_ALPS(C_tilde(:, ii), W, size(W,1), size(W, 2), kc, params);
    one_ALPS_C_hat(:, ii) = one_ALPS_C_hat(:, ii)/norm(one_ALPS_C_hat(:, ii));    
end;
textprogressbar(' ');
time_elapsed = etime(clock, t);
str = sprintf('Time elapsed: %f sec', time_elapsed);
disp(str);


one_ALPS_A_hat = perm2match(one_ALPS_A_hat, A);
one_ALPS_B_hat = perm2match(one_ALPS_B_hat, B);
one_ALPS_C_hat = perm2match(one_ALPS_C_hat, C);

disp(' ')
disp('==================== 1-ALPS(2) ======================');
str = sprintf('Error in A component: || A - A_hat ||_F = %.8f', norm(abs(A) - abs(one_ALPS_A_hat), 'fro'));       % Up to signs...
disp(str);
str = sprintf('Error in B component: || B - B_hat ||_F = %.8f', norm(abs(B) - abs(one_ALPS_B_hat), 'fro'));       % Up to signs...
disp(str);
str = sprintf('Error in C component: || C - C_hat ||_F = %.8f', norm(abs(C) - abs(one_ALPS_C_hat), 'fro'));       % Up to signs...
disp(str);
disp('=====================================================');
