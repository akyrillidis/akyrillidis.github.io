function [x_hat, numiter, x_path] = one_ALPS(y, Phi, M, N, K, params)
% =========================================================================
%                  1-ALPS(#) algorithm - Beta Version
% =========================================================================
% Algebraic Pursuit (ALPS) algorithm with 1-memory acceleration. 
% 
% Detailed discussion on the algorithm can be found in 
% [1] "On Accelerated Hard Thresholding Methods for Sparse Approximation", written
% by Volkan Cevher, Technical Report, 2011.
% =========================================================================
% INPUT ARGUMENTS:
% y                         M x 1 undersampled measurement vector.
% Phi                       M x N regression matrix.
% M                         Number of observations
% N                         Ambient signal dimension
% K                         Sparsity of underlying vector x* or desired
%                           sparsity of solution.
% params                    Structure of parameters. These are:
%
%    tol,...                Early stopping tolerance. Default value: tol =
%                           1-e5.
%    ALPSiters,...          Maximum number of algorithm iterations. Default
%                           value: 300. 
% =========================================================================
% OUTPUT ARGUMENTS:
% x_hat                     N x 1 recovered K-sparse vector.
% numiter                   Number of iterations executed.
% x_path                    Keeps a series of computed N x 1 K-sparse vectors 
%                           until the end of the iterative process.
% =========================================================================
% 13/08/2012, by Anastasios Kyrillidis. anastasios.kyrillidis@epfl.ch, EPFL.
% =========================================================================
% cgsolve.m is written by Justin Romberg, Caltech, Oct. 2005.
%                         Email: jrom@acm.caltech.edu
% =========================================================================
% This work was supported in part by the European Commission under Grant 
% MIRG-268398 and DARPA KeCoM program #11-DARPA-1055. VC also would like 
% to acknowledge Rice University for his Faculty Fellowship.
% =========================================================================

%% Initialize to zero vector
x_cur = zeros(N,1);
y_cur = zeros(N,1);
Phi_x_cur = zeros(M,1);
Y_i = [];

x_path = zeros(N, params.ALPSiters);

structPhi = isstruct(Phi);

if (~structPhi)
    Phi_t = Phi';
end;

%% Help variables
complementary_Yi = ones(N,1);

i = 1;
%% 1-ALPS(#)
while (i <= params.ALPSiters)
    x_path(:,i) = x_cur;
    x_prev = x_cur;        
    
    % Compute the residual
    if (i == 1)
        res = y;
    else
        res = y - Phi_x_cur - tau*Phi_diff;
    end;

    % Compute the derivative
    if (structPhi)
        der = A_I_transpose(Phi.At, res, 1:N);
    else
        der = Phi_t*res;
    end;

    Phi_x_prev = Phi_x_cur;               
    
    % Determine S_i set via eq. (11) (change of variable from x_i to y_i)
    complementary_Yi(Y_i) = 0;
    [~, ind_der] = sort(abs(der).*complementary_Yi, 'descend');  
    complementary_Yi(Y_i) = 1;
    S_i = [Y_i; ind_der(1:K)];
    
    % Gradient descent step with adaptive step size selection
    ider = der(S_i);
    if (structPhi)
        Pder = A_I(Phi.A, ider, S_i, N);
    else
        Pder = Phi(:,S_i)*ider;
    end;

    mu_bar = ider'*ider/(Pder'*Pder);            
    b = y_cur(S_i) + (mu_bar)*ider;        

    % Hard-threshold b and compute X_{i+1}
    [~, ind_b] = sort(abs(b), 'descend');
    x_cur = zeros(N,1);
    x_cur(S_i(ind_b(1:K))) = b(ind_b(1:K));
    X_i = S_i(ind_b(1:K));

    if (structPhi)
        Phi_x_cur = A_I(Phi.A, x_cur(X_i), X_i, N);
    else
        Phi_x_cur = Phi(:,X_i)*x_cur(X_i);
    end;
    
    res = y - Phi_x_cur;
        
    if (structPhi)
        der = A_I_transpose(Phi.At, res, 1:N);
    else
        der = Phi_t*res;
    end;
    
    ider = der(X_i);
    
    if (structPhi)
        Pder = A_I(Phi.A, ider, X_i, N);
    else
        Pder = Phi(:,X_i)*ider;
    end;

    mu_bar = ider'*ider/(Pder'*Pder);
    x_cur(X_i) = x_cur(X_i) + mu_bar*ider;
    
    %% Nesterov's acceleration kind of step

    % tau = argmin ||u - Phi*y_{i+1}|| 
    %     = <res, Phi*(x_cur - x_prev)>/||Phi*(x_cur - x_prev)||^2        

    if (structPhi)
        Phi_x_cur = A_I(Phi.A, x_cur(X_i), X_i, N);
    else
        Phi_x_cur = Phi(:,X_i)*x_cur(X_i);
    end;
    
    res = y - Phi_x_cur;
    if (i == 1)
        Phi_diff = Phi_x_cur;
    else
        Phi_diff = Phi_x_cur - Phi_x_prev;
    end;
    tau = res'*Phi_diff/(Phi_diff'*Phi_diff);

    y_cur = x_cur + tau*(x_cur - x_prev);
    Y_i = find(ne(y_cur, 0));
        
    % Test stopping criterion
    if (i > 1) && (norm(x_cur - x_prev) < params.tol*norm(x_cur))
        break;
    end;
    i = i + 1;
end;

x_hat = x_cur;
numiter= i;

if (i > params.ALPSiters)
    x_path = x_path(:,1:numiter-1);
else
    x_path = x_path(:,1:numiter);
end;
