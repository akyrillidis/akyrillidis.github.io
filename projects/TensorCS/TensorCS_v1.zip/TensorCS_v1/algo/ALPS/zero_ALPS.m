function [x_hat, numiter, x_path] = zero_ALPS(y, Phi, N, K, params)
% =========================================================================
%                0-ALPS(#) algorithm - Beta Version
% =========================================================================
% Algebraic Pursuit (ALPS) algorithm with memoryless acceleration. 
% 
% Detailed discussion on the algorithm can be found in 
% [1] "On Accelerated Hard Thresholding Methods for Sparse Approximation", written
% by Volkan Cevher, Technical Report, 2011.
% =========================================================================
% INPUT ARGUMENTS:
% y                         M x 1 undersampled measurement vector.
% Phi                       M x N regression matrix.
% M                         Number of observations
% N                         Ambient signal dimension
% K                         Sparsity of underlying vector x* or desired
%                           sparsity of solution.
% params                    Structure of parameters. These are:
%
%    tol,...                Early stopping tolerance. Default value: tol =
%                           1-e5
%    ALPSiters,...          Maximum number of algorithm iterations. Default
%                           value: 300. 
%    mode, ...              According to [1], possible values are
%                           [0,1,2,4,5,6]. This value comes from the binary 
%                           representation of the parameters:
%                           (solveNewtob, gradientDescentx, solveNewtonx), 
%                           which are explained next. Default value = 0.
% =========================================================================
% OUTPUT ARGUMENTS:
% x_hat                     N x 1 recovered K-sparse vector.
% numiter                   Number of iterations executed.
% x_path                    Keeps a series of computed N x 1 K-sparse vectors 
%                           until the end of the iterative process.
% =========================================================================
% 13/08/2012, by Anastasios Kyrillidis. anastasios.kyrillidis@epfl.ch, EPFL.
% =========================================================================
% cgsolve.m is written by Justin Romberg, Caltech, Oct. 2005.
%                         Email: jrom@acm.caltech.edu
% =========================================================================
% This work was supported in part by the European Commission under Grant 
% MIRG-268398 and DARPA KeCoM program #11-DARPA-1055. VC also would like 
% to acknowledge Rice University for his Faculty Fellowship.
% =========================================================================

%% Initialize to zero vector
x_cur = zeros(N,1);
X_i = [];

x_path = zeros(N, params.ALPSiters);

structPhi = isstruct(Phi);

%% CG params
cg_verbose = 0;
if (~structPhi)
    Phi_t = Phi';    
    cg_A = Phi_t*Phi;
    cg_b = Phi_t*y;
end;

%% Help variables
complementary_Xi = ones(N,1);

i = 1;
%% 0-ALPS(#)
while (i <= params.ALPSiters)
    x_path(:,i) = x_cur;
    x_prev = x_cur;

    % Compute the residual
    if (i == 1)
        res = y;
    else
        if (structPhi)
            Phi_x_cur = A_I(Phi.A, x_cur(X_i), X_i, N);
        else
            Phi_x_cur = Phi(:,X_i)*x_cur(X_i);
        end;
        res = y - Phi_x_cur;
    end;
    
    % Compute the derivative
    if (structPhi)
        der = A_I_transpose(Phi.At, res, 1:N);
    else
        der = Phi_t*res;         
    end;
    
    % Determine S_i set via eq. (11)
    complementary_Xi(X_i) = 0;
    [~, ind_der] = sort(abs(der).*complementary_Xi, 'descend');
    complementary_Xi(X_i) = 1;
    S_i = [X_i; ind_der(1:K)];
           
    if (structPhi)
        % Create matrix operators for cg_solve
        P1 = @(z) A_I(Phi.A, z, S_i, N);
        P2 = @(z) A_I_transpose(Phi.At, z, S_i);
        bb = P2(y);
        P3 = @(z) P2(P1(z));

        % Conjugate gradient
        [b, ~, ~] = cgsolve(P3, bb, 1e-8, 500, cg_verbose);
    else
        [b, ~, ~] = cgsolve(cg_A(S_i, S_i), cg_b(S_i), 1e-8, 500, cg_verbose);
    end;
    
    % Hard-threshold b and compute X_{i+1}
    [~, ind_b] = sort(abs(b), 'descend');
    X_i = S_i(ind_b(1:K));

    if (structPhi)
        % Debias using CG - similar to HTP
        P1 = @(z) A_I(Phi.A, z, X_i, N);
        P2 = @(z) A_I_transpose(Phi.At, z, X_i);
        bb = P2(y);
        P3 = @(z) P2(P1(z));

        [v, ~, ~] = cgsolve(P3, bb, 1e-8, 500, cg_verbose);
    else
        [v, ~, ~] = cgsolve(cg_A(X_i, X_i), cg_b(X_i), 1e-8, 500, cg_verbose);
    end;
        
    x_cur = zeros(N,1);
    x_cur(X_i) = v;
     
    % Test stopping criterion
    if (i > 1) && (norm(x_cur - x_prev) < params.tol*norm(x_cur))
        break;
    end;
    i = i + 1;  
      
end;

x_hat = x_cur;
numiter = i;

if (i > params.ALPSiters)
    x_path = x_path(:,1:numiter-1);
else
    x_path = x_path(:,1:numiter);
end;
