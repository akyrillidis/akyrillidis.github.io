function [x_hat, numiter, time, x_path] = AlgebraicPursuit(y, Phi, M, N, K, varargin)
% =========================================================================
%              Algebraic Pursuit algorithms - Beta Version
% =========================================================================
% Algebraic Pursuit (ALPS) algorithms are accelerated hard thresholding methods 
% on sparse recovery of linear inverse systems. In particular, let
%             Phi : M x N real matrix (M < N)
%             x*  : N x 1 K-sparse data vector
%             n   : N x 1 additive noise vector
% then, y = Phi x* + n is the undersampled M x 1 measurement vector. ALPS 
% solve the following minimization problem 
%          minimize ||y - Phi x||^2    subject to x is K-sparse vector. 
% 
% Detailed discussion on the algorithm can be found in 
% [1] "On Accelerated Hard Thresholding Methods for Sparse Approximation", written
% by Volkan Cevher, Technical Report, 2011.
% =========================================================================
% INPUT ARGUMENTS:
% y                         M x 1 undersampled measurement vector.
% Phi                       M x N regression matrix.
% K                         Sparsity of underlying vector x* or desired
%                           sparsity of solution.
% varargin                  Set of parameters. These are:
%
%    tol,...                Early stopping tolerance. Default value: tol =
%                           1-e5.
%    ALPSiters,...          Maximum number of algorithm iterations. Default
%                           value: 300.  
%    mode, ...              According to [1], possible values are
%                           [0,1,2,4,5,6]. This value comes from the binary 
%                           representation of the parameters:
%                           (solveNewtob, gradientDescentx, solveNewtonx), 
%                           which are explained next. Default value = 0.
%    verbose                verbose = 1 prints out execution infromation.
% =========================================================================
% OUTPUT ARGUMENTS:
% x_hat                     N x 1 recovered K-sparse vector.
% numiter                   Number of iterations executed.
% time                      Execution time in seconds.
% x_path                    Keeps a series of computed N x 1 K-sparse vectors 
%                           until the end of the iterative process.
% =========================================================================
% 13/08/2012, by Anastasios Kyrillidis. anastasios.kyrillidis@epfl.ch, EPFL.
% =========================================================================
% cgsolve.m is written by Justin Romberg, Caltech, Oct. 2005.
%                         Email: jrom@acm.caltech.edu
% =========================================================================
% This work was supported in part by the European Commission under Grant 
% MIRG-268398 and DARPA KeCoM program #11-DARPA-1055. VC also would like 
% to acknowledge Rice University for his Faculty Fellowship.
% =========================================================================

x_hat = 0;
time = 0;
x_path = 0;

params.tol = 1e-5;
params.ALPSiters = 300;
params.mode = 0;
params.verbose = 0;

for in_arg = 1:2:length(varargin)
    if (strcmp(varargin{in_arg}, 'mode'))
        params.mode = varargin{in_arg+1};
    end
    if (strcmp(varargin{in_arg}, 'tolerance'))
        params.tol = varargin{in_arg+1};
    end
    if (strcmp(varargin{in_arg}, 'ALPSiterations'))
        params.ALPSiters = varargin{in_arg+1};
    end
    if (strcmp(varargin{in_arg}, 'verbose'))
        params.verbose = varargin{in_arg+1};
    end;
end;

%% Check input

if (params.tol < 0 || ~isnumeric(params.tol))
    disp('ERROR: tolerance variable must be positive.');
    numiter = -1;
    return;
end;

y = y(:);
M_y = length(y);

if (params.mode == 0)
    if (M < 2*K) 
        disp('WARNING: Newton system may be ill-conditioned... Press any key to continue');
        pause;
    end;
end;

if (M_y ~= M)
    error('Inconsistent sampling matrix...');
end;

switch params.mode
    case 0,        
        tic;
        [x_hat, numiter, x_path] = zero_ALPS(y, Phi, N, K, params);
        time = toc;
        if (params.verbose == 1)
            str = sprintf('0-ALPS(5) time: %s', num2str(time));
            disp(str);
            str = sprintf('Number of iterations: %d', numiter);
            disp(str);
        end;
    case 1,
        tic;
        [x_hat, numiter, x_path] = one_ALPS(y, Phi, M, N, K, params);
        time = toc;
        if (params.verbose == 1)
            str = sprintf('1-ALPS(2) time: %s', num2str(time));
            disp(str);
            str = sprintf('Number of iterations: %d', numiter);
            disp(str);
        end;       
    otherwise
        tic;
        [x_hat, numiter, x_path] = zero_ALPS(y, Phi, M, N, K, params);
        time = toc;
        if (params.verbose == 1)
            str = sprintf('0-ALPS(5) time: %s', num2str(time));
            disp(str);
            str = sprintf('Number of iterations: %d', numiter);
            disp(str);
        end;
end;

