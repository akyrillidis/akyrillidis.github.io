function Aperm = perm2match(A,B)
% permute columns of A to match columns of B
% size(B) must be equal to size(A)
% Nikos Sidiropoulos, UMN, July 15, 2012

[I,F]=size(A);
D=zeros(F,F);
Bin = zeros(F,F);
for f=1:F,
    for g=1:F,
        D(f,g)=norm(abs(A(:,f))-abs(B(:,g)));
        temp = find(B(:, g));
        Bin(f, g) = sign(temp(1));
    end
end
Aperm=zeros(I,F); 
for k=1:F, 
     [f,g]=find(D == min(min(D)));     
     Aperm(:,g)=A(:,f);
     D(f,:)=1/eps;
     D(:,g)=1/eps;
end