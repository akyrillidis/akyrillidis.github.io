/* 
 * Stephen Becker,  11/2/12
 * Based on pauli_forward.c
 *
 * This function computes y = [A^*(b)]*z, where A is created from Pauli matrices
 * and z is a N x r matrix. The output y is the same size as z (unlike pauli_forward)
 * 
 *  A(X) are the Pauli measurements of X,
 * e.g.  [A(X)]_i = trace( E_i X ) = trace( E_i * x * x' ) = trace( x'*E_i*x ) (note: E_i = E_i' )
 *
 *
 * */
#include "pauli.h"

void printUsage() {
    mexPrintf("usage:\t(A'b)*x=pauli_adjoint(x,list,b,[nThreads],[FORCE_REAL]), where n is a power of 2\n");
    mexPrintf("  x should be real, of size n x r\n");
    mexPrintf("  list is a matrix of size log2(n) x m, with entries 0,1,2 or 3\n");
    mexPrintf("  and this specifies the order of the Pauli operations (i.e. A)\n");
    mexPrintf("  The output (A'b)*x is of size n x r\n");
    mexPrintf("  If FORCE_REAL=false (default), allows A'b to take complex values\n");
    mexPrintf(" Compilation: mex -O pauli_adjoint.c pauli_utilities.c -lm -lblas -lm -Dno_pthreads\n");
    mexPrintf("   or, to enable threads, \n");
    mexPrintf("              change -Dno_pthreads to  -Uno_pthreads\n");
    mexPrintf("   N.B. using -lmwblas is not recommended\n");
}


void mainWorker( double * RESTRICT input_real, double * RESTRICT input_imag,
        double * RESTRICT x_real, double * RESTRICT x_imag, long int * RESTRICT list, 
        mwSize r, mwSize N, mwSize logN);

/* for pthreads
 * See ~/from_ACM/TA/ACM114/HW3/monteCarloThreads.c, for example.
 * */
#ifdef use_pthreads
typedef struct info_struct {
    long id;
    pthread_mutex_t *mutex;
    double *y_real, *y_imag, *b, *x_real, *x_imag;
    int m_start, m_end, COMPLEX;
    long  *list;
    mwSize r, N, logN;
}Info_t ;

/* Make a serial version first to make sure we get the right info passed */

void* worker(void* threadID) {
    Info_t *info            = (Info_t *) threadID; // {{{
    pthread_mutex_t *mutex  = info->mutex;
    long int *list          = info->list;
    double *y_real  = info->y_real; // careful: this is a pointer, so side-effects!
    double *y_imag  = info->y_imag; // careful: this is a pointer, so side-effects!
    int r           = info->r;
    int N           = info->N;
    int COMPLEX     = info->COMPLEX;
    ptrdiff_t Nr    = N*r;
    ptrdiff_t one   = 1;
    double alpha    = 1.;
    double *b       = info->b;
    int m_start     = info->m_start;
    int m_end       = info->m_end;
    //int m_diff      = m_end-m_start;
    mwSize logN     = info->logN;
    int mm; // iteration variable
    double *input_real  = (double *)mxCalloc( r*N, sizeof(double) );
    double *input_imag  = (double *)mxCalloc( r*N, sizeof(double) );
    double *y_real_local= (double *)mxCalloc( r*N, sizeof(double) ); // initializes to 0
    double *y_imag_local= (double *)mxCalloc( r*N, sizeof(double) ); // initializes to 0
    assert( input_real != NULL );
    assert( input_imag != NULL );
    assert( y_real_local != NULL );
    assert( y_imag_local != NULL );

    for ( mm = m_start; mm < m_end ; mm++ ) {
        mainWorker(input_real, input_imag, info->x_real, info->x_imag,
                list+logN*mm, r, N, logN );
        daxpy( &Nr, b+mm, input_real, &one, y_real_local, &one );
        if (COMPLEX)
            daxpy( &Nr, b+mm, input_imag, &one, y_imag_local, &one );
    }
    /* for debugging: */
//     printMatrix( y_real_local, y_imag_local, N, 10, r>10 ? 10 : r );
    
    /* Update it: make sure no other thread is updating also */
    pthread_mutex_lock(mutex);
    daxpy( &Nr, &alpha, y_real_local, &one, y_real, &one );
    if (COMPLEX)
        daxpy( &Nr, &alpha, y_imag_local, &one, y_imag, &one );
    pthread_mutex_unlock(mutex);
    
    mxFree( input_real );
    mxFree( input_imag );
    mxFree( y_real_local );
    mxFree( y_imag_local );
    pthread_exit(NULL);
    return NULL;
}
#endif // }}}

/* ----------------------------- */
/* Main function */
/* ----------------------------- */
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] )
{
    /* Declare variables */
    mwSize      N, m, logN, r; /* m is number of measurements; r is rank of x */
    double      *x_real, *x_imag, *y_real, *y_imag, *b;
    long int    *list;
    int         mi;
    int         nThreads = 1;
    int         FORCE_REAL=false, COMPLEX=true;
#ifdef use_pthreads 
    int         m_end, m_avg;
    Info_t              *info; /* an array of structures {{{ */ 
    int                 id;
    pthread_t           *threads;
    pthread_mutex_t     mutex;
    pthread_mutex_init(&mutex, NULL);
#else
    ptrdiff_t   one = 1, Nr;
    double      *input_real, *input_imag;
#endif // }}}

    /* Check for proper number of input and output arguments */    
    if ( nrhs != 3)  {
        if ( nrhs >= 4 ) {
            nThreads = (int) *mxGetPr( prhs[3] );
            if ( nThreads < 1 ){
                printUsage();
                mexErrMsgTxt("pauli_adjoint: nThreads must be >= 1");
            } else if ( nThreads > 10000 ) {
                printUsage();
                mexErrMsgTxt("pauli_adjoint: nThreads must be < 10000");
            }
            if ( nrhs >= 5 ) {
                // mxGetPr fails if not a double
                if (mxIsLogical(prhs[4]))
                    FORCE_REAL = (int) *mxGetLogicals( prhs[4] );
                else
                    FORCE_REAL = (int) *(int *)mxGetData( prhs[4] );
                    // with mxGetData, returns void * pointer, so must cast the pointer
                    //FORCE_REAL = (int) *mxGetPr( prhs[4] );
            }
        } else {
            printUsage();
            mexErrMsgTxt("pauli_adjoint: Needs 3 to 5 input arguments");
        }
    } 
#ifdef use_pthreads
    /* don't allocate memory for info until we know # of threads! */
    info = (Info_t *)mxMalloc( nThreads * sizeof(Info_t) );
    assert( info != NULL );
    debugPrintf("Using %d threads\n", nThreads);
    /* allocate for the thread objects */
    threads = (pthread_t *) mxMalloc( nThreads * sizeof(pthread_t) );
    assert( threads != NULL );
#endif
    N       = mxGetM( prhs[0] );
    r       = mxGetN( prhs[0] );
    x_real  = mxGetPr( prhs[0] );
    
    if ( !mxIsComplex( prhs[0]) ) {
        if ( FORCE_REAL )
            COMPLEX = false;
        x_imag  = (double *)mxCalloc( N*r, sizeof(double) );
        assert( x_imag != NULL );
        for ( mi=0; mi < N*r ; mi++ )
            x_imag[mi] = 0.; 
    }  else {
        x_imag = mxGetPi( prhs[0] );
    }
    debugPrintf("COMPLEX is %d (FORCE_REAL is %d)\n", COMPLEX, FORCE_REAL);

    logN = mxGetM( prhs[1] );
    m    = mxGetN( prhs[1] );
    /* do a safety check: is 2^logN = N ? */
    if ( (int)(pow(2,logN))  != N ) {
        printUsage(); mexPrintf("logN = %d, N = %d\n", logN, N );
        mexErrMsgTxt("this requires 2^size(list,1) == length(x)\n");
    }
    b   = mxGetPr( prhs[2] ); // ignore any complex part
    if (mxGetM(prhs[2]) != m ){
        printUsage(); mexPrintf("b has size %d, should be %d\n", mxGetM(prhs[2]),m );
        mexErrMsgTxt("bad size\n");
    }
    /* collect list data */
    if (mxIsDouble( prhs[1] )) {
        list = NULL; // suppress warnings
        mexErrMsgTxt("Not configured for this case yet: convert to Int64 in Matlab\n");
    } else {
        /* we could have the wrong size integer...  worry about this later */
        if (!mxIsInt64( prhs[1] ) ) {
            mexErrMsgTxt("The 'list' input must be of type Int64\n");
        }
        list = (long int *)mxGetPr( prhs[1] );
        /* really, we only need 2 bits, so we could change this to a smaller
         * integer type to reduce memory... 
         * In that case, change "list" as well  */
    }
    plhs[0] = mxCreateDoubleMatrix( N, r, mxCOMPLEX );
    assert( plhs[0] != NULL );
    y_real = mxGetPr( plhs[0] );
    y_imag = mxGetPi( plhs[0] );
    assert( y_real != NULL );
    assert( y_imag != NULL );
    for ( mi = 0; mi < N*r; mi++ ){
        y_real[mi] = 0.;
        y_imag[mi] = 0.;
    }

    /* ------------------------------------ */
    /* Main algorithm --------------------- */
    /* ------------------------------------ */
    #ifdef use_pthreads
    /* parallel stuff {{{ */
    m_avg = ceil( (double)m/(double)nThreads );
    for (id=0; id<nThreads; id++) {
        /* These are the same for all threads */
        info[id].id             = id;
        info[id].y_real         = y_real;  /* pointer */
        info[id].y_imag         = y_imag;  /* pointer */
        info[id].x_real         = x_real;
        info[id].x_imag         = x_imag;
        info[id].list           = list;
        info[id].r              = r;
        info[id].N              = N;
        info[id].logN           = logN;
        info[id].mutex          = &mutex;
        info[id].COMPLEX        = COMPLEX;
        /* These are different for different threads */
        mi                      = id*m_avg;
        m_end                   = mi + m_avg;
        info[id].m_start        = mi;
        info[id].m_end          = ( m_end <= m ) ? m_end : m;
        info[id].b              = b; // NOT b + mi!!!!
//         debugPrintf("Starting at %d and going until %d (m=%d)\n",mi,info[id].m_end,m);
        
//         worker( (void *) &info[id] );
        pthread_create(&threads[id], NULL, worker, (void*) &info[id] ); 
        
        /* for debugging: */
//         sleep(1); // needs unistd.h. sleep( int n ) -- careful, it rounds!
        
    }
    /* Important: wait for all threads  to finish */
    for (id=0; id<nThreads; id++) {
        pthread_join(threads[id], NULL);
    }
    mxFree(threads); /* Note: free(...) will cause errors if you used mxMalloc or mxCalloc */
    threads = NULL;

#else // }}}
    input_real  = (double *)mxCalloc( r*N, sizeof(double) );
    input_imag  = (double *)mxCalloc( r*N,sizeof(double) );
    assert( input_real != NULL );
    assert( input_imag != NULL );
    Nr          = N*r;
    for ( mi = 0; mi < m ; mi ++ ) {
        /* loop over all measurements (columns of 'list' );
         * this updates the input_real and input_imag variables */
        mainWorker( input_real, input_imag, x_real, x_imag,list+logN*mi, r, N, logN );
        /* Record the output in y */
        daxpy( &Nr, b+mi, input_real, &one, y_real, &one );
        if (COMPLEX)
            daxpy( &Nr, b+mi, input_imag, &one, y_imag, &one );
    }
    mxFree( input_real );
    mxFree( input_imag );
#endif
}

/* --------------------------------------------------- */
/* Auxiliary functions */
/* --------------------------------------------------- */

/* -------------------------------------------------------- */
/* This will update the pointer in y ---------------------- */
void mainWorker( double * RESTRICT input_real, double * RESTRICT input_imag,
        double * RESTRICT x_real, double * RESTRICT x_imag, 
        long int * RESTRICT list, mwSize r, mwSize N, mwSize logN) {
     // {{{
    int ri, ni;
    int dN;
    memcpy( input_real, x_real, r*N*sizeof(double) );
    memcpy( input_imag, x_imag, r*N*sizeof(double) );
    for ( ri = 0; ri < r ; ri ++ ) {
        for ( ni = 0 ; ni < logN ; ni ++ ) {
            /* loop over rows */
            dN = pow(2,ni+1);
            switch ( list[ ni ] ) {
                case 2: // was 1 before, now on Yi-Kai's convention
                    xOperatorComplex(N,dN,input_real+ri*N, input_imag+ri*N );
                    break;
                case 3: // was 1 before, now on Yi-Kai's convention
                    yOperatorComplex(N,dN,input_real+ri*N, input_imag+ri*N );
                    break;
                case 1: // was 3 before, now on Yi-Kai's convention.
                    zOperatorComplex(N,dN,input_real+ri*N, input_imag+ri*N );
                    break;
                case 4: // identity
                case 0: // identity
                default:
                    break;
            }
        }
    }
} // }}}

