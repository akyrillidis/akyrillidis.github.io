% Simple test for TFR (tomography w/ fixed rank)
% Inspired by Yi-Kai Liu's request in 2011.
% Updated, Nov 2011 by Stephen Becker. Incorrect.
% Updated, Nov 2012 by Stephen Becker. Correct, and multi-threaded.
%   now it is correct, but it crashes every so often. some major memory issue
%   Is it due to pthreads? If so, I can run a non-threaded version.
%   I can also do a OpenMP version, which will be less prone to bugs.
%{
     X = sparse([0,1;1,0]);
     Y = sparse([0,-1i;1i,0]);
     Z = sparse([1,0;0,-1]); 

   X            Y           Z
[ 0 1 ]     [ 0 -i ]    [ 1  0 ]
[ 1 0 ]     [ i  0 ]    [ 0 -1 ]


%}
cd /home/srbecker/mySvn/stephen/trunk/QuantumTomo/Matlab/mexCode/

n = 12; % number of qubits
d = 2^n; % Hilbert space dimension
r = 2; % rank of our estimated state rhohat
m = 4*d*r; % number of Pauli observables
fprintf('Initializing: n = %d, d = %d, r = %d, m = %d\n', n, d, r, m);
psi = ( randn(d,r) + 1i*randn(d,r) )/sqrt(d);
psi = psi/sqrt(psi'*psi); % Normalize
x   = psi; % for notation...

LARGESCALE = d >= 2^11;
if LARGESCALE
    PAULI_T = sparse( [], [], [], d^2, m, 0 );
else
    PAULI_T = sparse([],[],[],d^2,m,m*d );
%     PAULI_MAT_T     = sparse( [], [], [],d,m*d,m*d); % new, Nov 14 2012
    PAULI_MAT_T = [];
end
fprintf('Taking measurements...      ');
obs = cell(m,1);
LIST = zeros(m,n);
if ~LARGESCALE
    p = randperm((d^2)-1);
    p = p(1:m);
else
    % randperm is too costly. Since m << d in this case,
    % we can sample with replacement, and then iteratively
    % clean it up until we have no duplicates.
    p   = randi( [1,d^2-1], 1, 2*m); % take extra, i.e. 2*m instead of m
    [~,I,J] = unique( p );
    I = sort(I); I = I(1:m);
    p = p(I);
end
cntr = 0;
TEMP = [];
tic
for i=1:m
    if ~mod(i,20)
        fprintf('\b\b\b\b\b\b%5.1f%%', 100*i/m );
    end
    if ~LARGESCALE
        [obs{i},list] = getpauli(n, p(i));
        PAULI_T(:,i) = vec(obs{i});  % access via column is MUCH faster
%         PAULI_MAT_T( :, (1+ (i-1)*d):i*d ) = obs{i}; % new! but slow
%         PAULI_MAT_T = [PAULI_MAT_T, obs{i}]; % a bit faster...
        % -- this is the fast way: --
        cntr = cntr + 1;
        TEMP    = [TEMP, obs{i} ];
        if ~mod(cntr,20)
            PAULI_MAT_T = [PAULI_MAT_T, TEMP];
            TEMP = [];
        end
    else
        LIST_ONLY = true;
        [obs{i},list] = getpauli(n, p(i), LIST_ONLY);
    end
    LIST(i,:) = list;
end
if ~LARGESCALE
    PAULI_MAT_T = [PAULI_MAT_T, TEMP];
    clear TEMP
end
fprintf('\n');
toc
% Transpose it:
% PAULI = PAULI_T.'; % if we do this, then b2!=b1 below
PAULI = PAULI_T'; % this lets b2==b1 below
PAULI_MAT = PAULI_MAT_T'; % Nov 14. 
    % I think the ' vs .' difference only matters if r > 1
    % This is because we want vec(E_i)'*vec(X)
    % So even if E_i and X are Hermitian, it does NOT
    % mean that vec(E_i)' = vec(E_x).'
%%
%  ---  Now, different ways to compute A(X) = PAULI*vec(x*x'): ---
if ~LARGESCALE
    disp(' ');
    disp('Standard version. time is: ');
    tic; b1  = PAULI*vec(x*x'); toc
    fprintf('Imag part of measurements: %.2e\n', norm(imag(b1)) );
    b1  = real(b1);
    
    % Another way (we will imitiate this in the mex file)
    disp(' ');
    disp(' Mex-like version but with cell aray');
    b2 = zeros(m,1);
    tic
    for i=1:m
        if r > 1
            b2(i) = trace(x'*obs{i}*x); % significantly slower
        else
            b2(i) = x'*obs{i}*x;
        end
    end
    toc
    fprintf('Imag part of measurements: %.2e\n', norm(imag(b2)) );
    b2 = real(b2);
    fprintf('Discrepancy: %.2e\n', norm(b1-b2) );
    
    % And another way that might be faster!
    disp(' ');
    disp(' Mex-like version, faster. But still slower than initial way...');
    tic
    temp = PAULI_MAT*x; % negative!
    b3 = zeros(m,1)';
    for ri = 1:r
        tt  = reshape( temp(:,ri), d, m );
        b3  = b3 + x(:,ri)'*tt;
    end
    b3 = b3.';
    toc
    fprintf('Discrepancy: %.2e\n', norm(b1-b3) );
    
    disp(' ');
    % Dec 27, I have a trick with sparse matrices!
    % But, this will still require me to form x*x', so still
    % limited in size unfortunately.
    % Also, logicals are 1 byte, so only saves ~8x in mem, but I have 4 of them
    P_R1 = real(PAULI) > 0;
    P_R2 = real(PAULI) < 0;
    P_I1 = imag(PAULI) > 0;
    P_I2 = imag(PAULI) < 0;
    tic;
     xx = vec(x*x');
     b5 = P_R1*xx - P_R2*xx + 1i*P_I1*xx - 1i*P_I2*xx;
    toc
    fprintf('Discrepancy: %.2e\n', norm(b1-b5) );
    % Hmm, it is OK, but not faster, and requires x*x' explicitly
    % I was thinking about making a mex function that converts
    % sparse double matrices to more efficient representations (e.g. int8),
    % but that still requries x*x' to be formed  :-(
    % (I was working on that when I saw mxCreateSparseLogicalMatrix
    % and realized we can make logical sparse matrices )
    
    
    %
%     ttt = temp( end-d+1:end,: ); 
%     norm( obs{i}*x - ttt )
else
    b1 = randn(m,1);
end

% -- Do *not* use pauli.c. That is an old file!
%% Dec 27 2012. Imitate the mex file in matlab
%{
 actually, I never implemented pauli_operator. This was for debugging
the AVOIDMEMCPY mode. My bug was the fact that I take a dot product
and didn't have a good copy for that. Easy to fix, and now it works.
%}
if ~LARGESCALE
    bb = zeros(m,1);
    for mi = 1:m
        xx = x; % copy memory.
        for ri = 1:r
            for ni = 1:n % loop over qubits
                dN = 2^ni;
                xx(:,ri) = pauli_operator(d,dN,xx(:,ri), list(ni,mi) );
            end
            bb(mi) = bb(mi) + dot( xx(:,ri), x(:,ri) );
        end
    end
end
%% Nov 8, 2012 for profiling with valgrind (or gprof)
% see http://stackoverflow.com/a/12405131
%{
For some reason, this failed for me, even with SVN to Caltech and full version of Matlab.
The call_mexFile compiles and runs, but can't start the Matlab engine! so skip it

%}
% list = int64( LIST_MY(1:nMeas,:)' );
% nThreads = 1;
% save sampleInputs x list nThreads

% Compile the program
% mex('-f', fullfile(matlabroot,'bin','engopts.sh'),'call_mexFile.c'); % note: matlaboot is 2010a!
% mex -f /opt/matlab-student/bin/engopts.sh call_mexFile.c
% mex -f /opt/matlab/bin/engopts.sh call_mexFile.c
% -f is an options file, to override defaults...

% Top run call_mexFile, need to load shared library for libeng.so
% LD_LIBRARY_PATH=/opt/matlab-student/bin/glnxa64/:/opt/matlab-student/sys/os/glnxa64/
% LD_LIBRARY_PATH=/opt/matlab-2010a/bin/glnxa64/:/opt/matlab-2010a/sys/os/glnxa64/
% LD_LIBRARY_PATH=/opt/matlab/bin/glnxa64/:/opt/matlab/sys/os/glnxa64/

% and run valgrind:
%   valgrind --tool=callgrind ./call_mexFile ./pauli_forward_OMP.mexa64

% mex -f /opt/matlab-student/bin/engopts.sh /opt/matlab-student/extern/examples/eng_mat/engdemo.c
% mex -f /opt/matlab-2010a/bin/engopts.sh /opt/matlab-2010a/extern/examples/eng_mat/engdemo.c

% mex('-f', fullfile(matlabroot,'bin','engopts.sh'),[matlabroot '/extern/examples/eng_mat/engdemo.c'])
%% new mex file that also does gradient (super low memory)
% Dec 27 '12, added -ffast-math, and that improves it a bit...
%  mex -O pauliGradient.c -lm -lmwblas -lm % This is very old
% mex -O pauli_forward.c -lm -lmwblas -lm % supercedes pauliGradient
mex -O pauli_forward.c -lm -lmwblas -lm -Dno_pthreads -UAVOIDMEMCPY  %-DDEBUG 
% mex -O pauli_forward.c -lm -lmwblas -lm -Dno_pthreads -v -UMX_COMPAT_32
% why is DMX_COMPAT_32 turned on???

% mex -O pauli_forward_OMP.c -lm -lmwblas -lm -Dno_use_omp -DDEBUG
% if ispc
%     mex -O pauli_forward_OMP.c -lgomp -lm -lmwblas -lm COMPFLAGS="$COMPFLAGS -fopenmp"
% else
%     mex -O pauli_forward_OMP.c -lgomp -lm -lmwblas -lm CFLAGS="\$CFLAGS -fopenmp" -DDEBUG
% end
% mex -O /home/srbecker/from_ACM/research/parallelMultiply/parallelMultiply.c -lgomp CFLAGS="\$CFLAGS -fopenmp"
% export OMP_NUM_THREADS=3  (use setenv?)
%/usr/lib/gcc/x86_64-linux-gnu/4.3/include/omp.h
%/usr/lib/gcc/x86_64-linux-gnu/4.4/include/omp.h

%% Better compilation!! Jan 2013
%{
Jan 22 2012
I discovered that mwblas is multithreaded and this is slowing me down!
(I just do level-1 stuff so it doesn't have to be fast)
Better not to do it!
%}
% mex -O pauli_forward.c -lm -lblas -lm -Dno_pthreads -UAVOIDMEMCPY -o pauli_forward_betterBLAS
% mex -O pauli_forward.c pauli_utilities.c -lm -lblas -lm -UAVOIDMEMCPY ...
%     -Uno_pthreads -o pauli_forward_betterBLAS CFLAGS="\$CFLAGS -Wall -W -Wconversion" ...
%     -UDEBUG

% To make the final version
mex -O pauli_forward.c pauli_utilities.c -lm -lblas -lm -UAVOIDMEMCPY ...
    -Uno_pthreads -DNDEBUG -UDEBUG
%% 
% setenv('OMP_NUM_THREADS','4');
% for cntr = 1:100
fprintf('comparing...\n')
% note: we want list to be logN x m, not vice-versa, since we will use column access
list = int64( LIST' ); 
% Dec 2012: test just one type of Pauli:
% 1 = Z, 2 = X, 3 = Y, 4 or 0 = I
% list = ones( size(LIST'), 'int64');
% list = int64( 3*ones(size(LIST')) );
% 1: .78  (Z)
% 2: .95  (X, the flip)
% 3: 1.03 (Y, imaginary flip)
% 4: .198 (since identity)
%     X = sparse([0,1;1,0]);
%     Y = sparse([0,-1i;1i,0]);
%     Z = sparse([1,0;0,-1]); 

% list = int64( 0*LIST_MY' ); % all identities! is this faster? Yes, from 24 sec to 5.2 seconds for 13 qubits
tic
nThreads = 1;
weights     = -ones(r,1);
% weights     = -rand(r,1);
b4 = pauli_forward( x, list, nThreads, weights);
% b4 = pauli_forward_OMP( x, list, nThreads);
toc
if ~isempty(weights) && ~LARGESCALE
    b1  = PAULI*vec(x*diag(weights)*x');
    fprintf('Discrepancy: %.2e\n', norm(b1-b4) );
end


% n = 2^13, takes 6.1 seconds with 4 threads, 6.5 seconds with 8 threads
%           10.2 seconds with 2 threads, 15.15 seconds with 1 thread
%           ??? Nov 8, when I re-run this, it takes 23.5 seconds if I don't use pthreads option
% n = 2^13, with OpenMP code (and set CPU to 1.6 GHz)
%           takes 12 seconds with 4 threads, 11.4 seconds with 8 threads
%           18 seconds with 2 threads, 23.4 seconds with 1 thread
%           OpenMP code, with -Dno_use_omp: 23.3 seconds.
%   n = 2^12, OpenMP without defining OMP, takes 5.7 seconds (1.4 if all identities)

% 1 thread. Without dswap for dN=N, {14.2, 13.9, 14.5} seconds
%           with dswap, {14.6, 14.7, 14.27} seconds. Makes little difference.

norm( pauli_forward( x, list, nThreads) ); % now it works... actually, not always (if > 1 thread)
% end
%% Try the adjoint operator
% mex -O pauli_adjoint.c -lm -lmwblas -lm
mex -O pauli_adjoint.c -lm -lmwblas -lm -Dno_pthreads
% mex -O pauli_adjoint.c -lm -lmwblas -lm -Dno_pthreads -DDEBUG
%% Try better BLAS, Jan 2013
% mex -O pauli_adjoint.c pauli_utilities.c -lm -lblas -lm ...
%     -Uno_pthreads -o pauli_adjoint_betterBLAS CFLAGS="\$CFLAGS -Wall -W -Wconversion" ...
%     -UDEBUG

% or, for final version (NDEBUG turns off assert() macros)
mex -O pauli_adjoint.c pauli_utilities.c -lm -lblas -lm ...
    -Uno_pthreads -UDEBUG -DNDEBUG
%%
%{
Description:
    The adjoint At(b) is mat( PAULI'*b )
    This is dense in general, so we enver want to form it.
    Instead, the mex files computes mat( PAULI'*b )*y
    for any matrix y. y is d x r, and r can be large.
    For example, take y = eye(d) to get the full adjoint.

%}
if ~LARGESCALE && d <= 128
    mat     = @(x) reshape(x,d,d);
    grad    = mat( PAULI'*b1 );
    
    nThreads = 1;
    list    = int64( LIST' );
    rhs     = eye(d);
    g       = pauli_adjoint(rhs, list, b1, nThreads );
    
    norm(g-grad)
    dG      = g-grad;
    
%     rhs     = randn(d,3);
%     g       = pauli_adjoint(rhs, list, b1, nThreads );
%     norm( g - grad*rhs )
else
    % just do a speed test
    b1      = ones(m,1);
    rhs     = randn(d,2);
    nThreads = 8;
    tic
    g       = pauli_adjoint(rhs, list, b1, nThreads );
    toc
end
% disp( pauli_adjoint(rhs, list, b1, nThreads ) )
% norm( pauli_adjoint(rhs, list, b1, nThreads ) ) % make sure this won't crash it!
%% Experiment with coarse-grained parallel code in Matlab
%  Each coarse-grained part then calls a fine-grained pthreads version
%  Designed to be used with Matlab's parallel computing toolbox
%% For forward operator
if ~LARGESCALE
    list = int64( LIST' ); 
    
    ind1        = 1:round(m/2);
    ind2        = round(m/2)+1:m;    
    
    nThreads = 1;
    weights     = -ones(r,1);
    b4 = zeros(m,1);
    b4(ind1) = pauli_forward( x, list(:,ind1), nThreads, weights);
    b4(ind2) = pauli_forward( x, list(:,ind2), nThreads, weights);
    
    % and compare to reference
    b1  = PAULI*vec(x*diag(weights)*x');
    fprintf('Discrepancy: %.2e\n', norm(b1-b4) );
end

%%
% For adjoint. Works fine...
if ~LARGESCALE
    mat     = @(x) reshape(x,d,d);

    
    resid   = randn(m,1);
    rhs     = randn(d,5); % this is arbitrary: what we multiply by (extrme case: rhs = eye(d) )
    
    % Make reference answer
    grad    = mat( PAULI'*resid );
    grad    = grad*rhs;
    
    % and parallel:
    ind1        = 1:round(m/2);
    ind2        = round(m/2)+1:m;
    
    % do it with sparse matrices:
%     PAULI_T1    = PAULI_T(:, ind1 );
%     PAULI_T2    = PAULI_T(:, ind2 );
%     grad2       = mat( PAULI_T1*resid(ind1) ) + mat( PAULI_T2*resid(ind2) );
%     grad2       = grad2*rhs;

    nThreads = 1;
    list = int64( LIST' ); 
    g_a        = pauli_adjoint(rhs, list(:,ind1), resid(ind1), nThreads );
    g_b        = pauli_adjoint(rhs, list(:,ind2), resid(ind2), nThreads );
    grad2      = g_a + g_b;

    fprintf('Error is %.2e\n',  norm( grad - grad2 ) )
end