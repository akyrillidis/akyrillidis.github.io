/* 
 * Stephen Becker,  11/2/12. stephen.beckr@gmail.com
 * Based on pauliGradient.c (2011) but improved, and no longer doing the (incorrect) gradient
 * Also fixed bug for y[mi] += (real) + (imag). Before I had an erroneous minus sign.
 *
 * This function computes y = A(x*x'), where A is created from Pauli matrices
 * and x is a N x r matrix, with r << N hopefully.
 * 
 *  A(X) are the Pauli measurements of X,
 * e.g.  [A(X)]_i = trace( E_i X ) = trace( E_i * x * x' ) = trace( x'*E_i*x ) (note: E_i = E_i' )
 *
 * Nov 7, 2012: it was working, but crashing all of Matlab *sometimes* whenever it was multithreaded
 * I think the issue is that I had a mutex lock for *writing* to memory, but not for reading memory.
 * So two threads read the same memory and crashed.
 *
 * Nov 9, adding compatibility for a sign vector.
 *
 * Conventions for Pauli:
 *      {0,4}   Identity
 *      1       Z
 *      2       X
 *      3       Y
 *
 * Dec 27 2012, added AVOIDMEMCPY mode, so I don't copy memory inside the mi loop[
 *  However, this does not seem to be faster, so don't use it.
 *
 * Jan 23, 2013, I thought I had fixed crashing
 * Jan 24, 2013. Still crashes. I tried OUTER_MEMORY, but no help.
 *      This is with 8 qubits, nThreads = 4 (or even 2 sometimes)
 *      For my tests with more qubits yesterday, it never crashed
 *      It seems to crash only very *rarely*!
 *      For 16 qubits on electra, it was fine!!!
 * */

#include "pauli.h"
//#define OUTER_MEMORY

void printUsage() {
    mexPrintf("usage:\tAx=pauli_forward(x,list, [nThreads], [diag]), where n is a power of 2\n");
    mexPrintf("  x should be real, of size n x r\n");
    mexPrintf("  list is a matrix of size log2(n) x m, with entries 0,1,2 or 3\n");
    mexPrintf("  and this specifies the order of the Pauli operations\n");
    mexPrintf("  The output Ax is of size m x 1\n");
}
double mainWorker( double * RESTRICT input_real, double * RESTRICT input_imag,
        double * RESTRICT x_real, double * RESTRICT x_imag, long int * RESTRICT list, 
        mwSize r, mwSize N, 
        mwSize logN, int do_weights, double *weights);
/* for pthreads
 * See ~/from_ACM/TA/ACM114/HW3/monteCarloThreads.c, for example.
 * */
#ifdef use_pthreads
typedef struct info_struct {
    long    id;
//     pthread_mutex_t *mutex;
    double  *y, *x_real, *x_imag, *weights;
    int     m_start, m_end, do_weights;
    long   *list;
    mwSize r, N, logN;
}Info_t ;

void* worker(void* threadID) {
    Info_t *info = (Info_t *) threadID;
    long int *list=info->list;
    double   *y = info->y; // careful: this is a pointer, so side-effects!
    int r       = info->r;
    int N       = info->N;
    int m_start = info->m_start;
    int m_end   = info->m_end;
    int m_diff  = m_end-m_start;
    int do_weights = info->do_weights;
    double *weights = info->weights;
    mwSize logN = info->logN;
    int mm;     // iteration variable
    double *x_real = info->x_real;
    double *x_imag = info->x_imag;
    double *input_real  = (double *)mxCalloc( r*N, sizeof(double) );
    double *input_imag  = (double *)mxCalloc( r*N, sizeof(double) );
    if ( input_real == NULL )  mexErrMsgTxt("Could not allocate memory\n");
    if ( input_imag == NULL )  mexErrMsgTxt("Could not allocate memory\n");

    for ( mm = m_start; mm < m_end ; mm++ ) {
        #ifdef OUTER_MEMORY
        // copy the memory here, not inside the loop
        memcpy( input_real, x_real, r*N*sizeof(double) );
        memcpy( input_imag, x_imag, r*N*sizeof(double) );
        #endif
        y[mm]   = mainWorker(input_real,input_imag,x_real,x_imag,
            list+logN*mm,r,N,logN, do_weights, weights );
    }
    mxFree( input_real );
    mxFree( input_imag );
    pthread_exit(NULL);
    return NULL;
}
#endif

/* ----------------------------- */
/* Main function */
/* ----------------------------- */
/* calling sequence:
 * y = pauli_forward( x, list )
 *      x is N x r, list is logN x m (NOTE: it is NOT m x logN, since we prefer column access)
 *      Computes y_i = trace( x'*E_i*x )
 *      for E_i defined by list(i,:)
 *
 * y = pauli_forward( x, list, nThreads, diag )
 * */
void mexFunction(
         int nlhs,       mxArray *plhs[],
         int nrhs, const mxArray *prhs[]
         )
{
    /* Declare variables */
    mwSize      N, m, logN, r; /* m is number of measurements; r is rank of x */
    double      *x_real, *x_imag, *y;
    double      *weights;
    int         do_weights=0;
    long int    *list;
    int         mi;
    int         nThreads = 1;
#ifdef use_pthreads
    double      **x_real_ptrs, **x_imag_ptrs; // New, Nov 7, 2012. Trying to avoid crashes!
    int         m_end, m_avg;
    Info_t      *info; /* an array of structures */
    int         id;
    pthread_t   *threads;
#else
    double      *input_real, *input_imag;
#endif

    /* Check for proper number of input and output arguments {{{ */    
    if ( nrhs != 2)  {
        if ( nrhs >= 3 ) {
            nThreads = (int) *mxGetPr( prhs[2] );
            if ( nThreads < 1 ){
                printUsage();
                mexErrMsgTxt("pauli_forward: nThreads must be >= 1");
            } else if ( nThreads > 10000 ) {
                printUsage();
                mexErrMsgTxt("pauli_forward: nThreads must be < 10000");
            }
            if ( nrhs == 3 ) {
                /* ok, do nothing */
            } else if ( nrhs == 4 ) {
                /* collect diagonal weights */
                do_weights = 1;
                weights     = mxGetPr( prhs[3] );
            } else {
                printUsage();
                mexErrMsgTxt("pauli_forward: Needs 2 to 4 input arguments");
            }
            
        } else {
            printUsage();
            mexErrMsgTxt("pauli_forward: Needs 2 to 4 input arguments");
        }
    } 
    if ( !do_weights ) {
        weights     = NULL;
    }
    // }}}
#ifdef use_pthreads
    /* don't allocate memory for info until we know # of threads! */
    info    = (Info_t *)mxMalloc( nThreads * sizeof(Info_t) );  
    if ( info == NULL )  mexErrMsgTxt("Could not allocate memory\n");
    debugPrintf("Using %d threads\n", nThreads);
    /* allocate for the thread objects */
    threads = (pthread_t *) mxMalloc( nThreads * sizeof(pthread_t) );
    if ( threads == NULL )  mexErrMsgTxt("Could not allocate memory\n");

    x_real_ptrs = (double **) mxMalloc( nThreads * sizeof( double * ) ); // array of pointers
    x_imag_ptrs = (double **) mxMalloc( nThreads * sizeof( double * ) ); // array of pointers
    // Jan 24 2013
    if ( x_real_ptrs == NULL )  mexErrMsgTxt("Could not allocate memory\n");
    if ( x_imag_ptrs == NULL )  mexErrMsgTxt("Could not allocate memory\n");
#endif
    N       = mxGetM( prhs[0] );
    r       = mxGetN( prhs[0] );
    x_real  = mxGetPr( prhs[0] );
    if ( do_weights ) {
        if ( mxGetM( prhs[3] ) == 1 ) {
            if ( mxGetN( prhs[3] ) != r ) {
                printUsage();
                mexErrMsgTxt("pauli_forward: 4th argument has wrong size");
            }
        } else if ( mxGetN( prhs[3] ) == 1 ) {
            if ( mxGetM( prhs[3] ) != r ) {
                printUsage();
                mexErrMsgTxt("pauli_forward: 4th argument has wrong size");
            }
        } else {
            printUsage();
            mexErrMsgTxt("pauli_forward: 4th argument has wrong size");
        }
    }
    
    if ( !mxIsComplex(prhs[0]) ) {
        x_imag  = (double *)mxCalloc( N*r, sizeof(double) );
        if ( x_imag == NULL )  mexErrMsgTxt("Could not allocate memory\n");
        for ( mi=0; mi < N*r ; mi++ )
            x_imag[mi] = 0.; 
    }  else {
        x_imag = mxGetPi( prhs[0] );
    }
    if ( r > N )
        mexErrMsgTxt("The input 'x' must be N x r, with r < N\n");
    /* I don't know if r > N is really a restriction, but you should
     * never be doing it, so just throw an error since this is probably a mistake */

    logN = mxGetM( prhs[1] );
    m    = mxGetN( prhs[1] );
    /* do a safety check: is 2^logN = N ? */
    if ( (int)(pow(2,logN))  != N ) {
        printUsage();
        mexPrintf("logN = %d, N = %d\n", logN, N );
        mexErrMsgTxt("this requires 2^size(list,1) == length(x)\n");
    }
    /* collect list data */
    if (mxIsDouble( prhs[1] )) {
        list = NULL;
        mexErrMsgTxt("Not configured for this case yet: convert to Int64 in Matlab\n");
    } else {
        /* we could have the wrong size integer...  worry about this later */
        if (!mxIsInt64( prhs[1] ) ) {
            mexErrMsgTxt("The 'list' input must be of type Int64\n");
        }
        list = (long int *)mxGetPr( prhs[1] );
        /* really, we only need 2 bits, so we could change this to a smaller
         * integer type to reduce memory... 
         * In that case, change "list" as well  */
    }
    /*
    if (nlhs > 0) {
        plhs[0] = mxCreateDoubleMatrix( m, 1, mxREAL ); // if unsuccessful, mex file terminates automatically
        y = mxGetPr( plhs[0] );
        for ( mi = 0; mi < m; mi++ )
            y[mi] = 0.;
    } else {
        mexErrMsgTxt("pauli_forward: must have outputs");
    }
     */
    /* the above code requires an explicit output,
     * so we cannot do something like disp( pauli_forward(..) )
     * (and norm( pauli_forward() ) caused Matlab to crash! )
     * Let's change it: */
    plhs[0] = mxCreateDoubleMatrix( m, 1, mxREAL ); // if unsuccessful, mex file terminates automatically
    if ( plhs[0] == NULL )  mexErrMsgTxt("Could not allocate memory\n");
    y = mxGetPr( plhs[0] );
    if ( y == NULL )  mexErrMsgTxt("Could not allocate memory\n");
    for ( mi = 0; mi < m; mi++ )
        y[mi] = 0.;


    /* ------------------------------------ */
    /* Main algorithm */
    /* ------------------------------------ */
#ifdef use_pthreads
    /* parallel stuff  {{{*/
    m_avg = ceil( (double)m/(double)nThreads );
    for (id=0; id<nThreads; id++) {
        x_real_ptrs[id]  = (double *) mxMalloc( N*r*sizeof( double ) );
        x_imag_ptrs[id]  = (double *) mxMalloc( N*r*sizeof( double ) );
        if ( x_real_ptrs[id] == NULL )  mexErrMsgTxt("Could not allocate memory\n");
        if ( x_imag_ptrs[id] == NULL )  mexErrMsgTxt("Could not allocate memory\n");
        memcpy( x_real_ptrs[id] , x_real, r*N*sizeof(double) );
        memcpy( x_imag_ptrs[id] , x_imag, r*N*sizeof(double) );

        info[id].id             = id;
        info[id].y              = y;  /* pointer */
        //info[id].x_real         = x_real;
        //info[id].x_imag         = x_imag;
        info[id].x_real         = x_real_ptrs[id];
        info[id].x_imag         = x_imag_ptrs[id];
        info[id].list           = list;
        info[id].r              = r;
        info[id].N              = N;
        info[id].logN           = logN;
        info[id].do_weights     = do_weights;
        info[id].weights        = weights;
        
        mi      = id*m_avg;
        m_end   = mi + m_avg;
        info[id].m_start        = mi;
        info[id].m_end          = ( m_end <= m ) ? m_end : m;
//         debugPrintf("Starting at %d and going until %d (m=%d)\n",mi,info[id].m_end,m);
//         worker( (void *) &info[id] );
        
        pthread_create(&threads[id], NULL, worker, (void*) &info[id] ); 
        /* for debugging: */
//         sleep(1); // needs unistd.h. sleep( int n ) -- careful, it rounds!
    }
    /* Important: wait for all threads  to finish */
    for (id=0; id<nThreads; id++) {
        pthread_join(threads[id], NULL);
        mxFree( x_real_ptrs[id] );
        mxFree( x_imag_ptrs[id] );
    }
    mxFree(threads); /* Note: free(...) will cause errors if you used mxMalloc or mxCalloc */
    threads = NULL;

#else // }}}
     input_real  = (double *)mxCalloc( r*N, sizeof(double) );
     input_imag  = (double *)mxCalloc( r*N, sizeof(double) );
     if ( input_real  == NULL )  mexErrMsgTxt("Could not allocate memory\n");
     if ( input_imag  == NULL )  mexErrMsgTxt("Could not allocate memory\n");
    #ifdef AVOIDMEMCPY
     /* the idea is that we do this once, rather than inside the loop */
     memcpy( input_real, x_real, r*N*sizeof(double) );
     memcpy( input_imag, x_imag, r*N*sizeof(double) );
    #endif
    for ( mi = 0; mi < m ; mi ++ ) {
        #ifdef OUTER_MEMORY
        memcpy( input_real, x_real, r*N*sizeof(double) );
        memcpy( input_imag, x_imag, r*N*sizeof(double) );
        #endif
        y[mi] = mainWorker( input_real, input_imag, x_real, x_imag,
                list+logN*mi, r, N, logN, do_weights, weights);
    }
    mxFree( input_real );
    mxFree( input_imag );
#endif
if ( !mxIsComplex(prhs[0]) ) {
    mxFree( x_imag );
}
} // end of main function


/* --------------------------------------------------- */
/* Auxiliary functions */
/* --------------------------------------------------- */

/* put this into a function so we could parallelize it if we want */
/* use 'restrict' to tell it that the arrays do not overlap
 *   http://locklessinc.com/articles/vectorize/ uses 'restrict', which won't compile for me
 *   the pdf says __restrict, which does compile.
 *  See p. 106 in http://agner.org/optimize/optimizing_cpp.pdf
 *  The comments here do not seem to work:
 *  http://stackoverflow.com/questions/9608171/how-to-tell-gcc-that-a-pointer-argument-is-always-double-word-aligned
 *
 *  Note: in pauli.h, RESTRICT is defined as restrict (for C) and __RESTRICT__ (for C++)
 */
double mainWorker( double * RESTRICT input_real, double * RESTRICT input_imag,
        double * RESTRICT x_real, double * RESTRICT x_imag, 
        long int * RESTRICT list, mwSize r, mwSize N, mwSize logN, int do_weights, double *weights) {
    double      yi = 0; // {{{
    ptrdiff_t   one = 1;
    int         ri, ni;
    int         dN;
    //double      *input_real, *input_imag;
    // If I want to manually inline the functions:
//     mwIndex i, j;
//     double temp;
//     int dN2;
    
    //x_real  = __builtin_assume_aligned( x_real, 16 ); // #include <pmmintrin.h> // SSE3 required 
    //#ifdef AVOIDMEMCPY /* Dec 27 2012 */
      /* we already copied input_real_ext <-- x_real, ... */
      /* and we don't have to recopy since we promise to return it */
      //input_real = input_real_ext;
      //input_imag = input_imag_ext;
    //#else
    #ifndef AVOIDMEMCPY /* Dec 27 2012 */
      // Jan 24, I think this out-of-order copying causes problems?
      // Maybe it is better to allocate new memory and then copy, 
      // rather than use this previously allocated memory...
      #ifndef OUTER_MEMORY
      memcpy( input_real, x_real, r*N*sizeof(double) );
      memcpy( input_imag, x_imag, r*N*sizeof(double) );
      #endif
    #endif
    for ( ri = 0; ri < r ; ri ++ ) {
        for ( ni = 0 ; ni < logN ; ni ++ ) {
            /* loop over rows */
            dN = pow(2,ni+1);
            switch ( list[ ni ] ) {
                case 2: // was 1 before, now on Yi-Kai's convention
                    xOperatorComplex(N,dN,input_real+ri*N, input_imag+ri*N );
                    break;
                case 3: // was 1 before, now on Yi-Kai's convention
                    yOperatorComplex(N,dN,input_real+ri*N, input_imag+ri*N );
                    break;
                case 1: // was 3 before, now on Yi-Kai's convention.
                    zOperatorComplex(N,dN,input_real+ri*N, input_imag+ri*N );
                    // inline it:
//                     dN2 = dN/2;
//                     for( i=0 ; i < N ; i += dN ) {
//                         for( j=dN2 ; j < dN ; j++ ) {
//                             input_real[i+j] *= -1;
//                             input_imag[i+j] *= -1;
//                         }
//                     }
                    
                    break;
                case 4: // identity
                case 0: // identity
                default:
                    break;
            }
        }
        /* accumulate the trace  */
        if (do_weights) {
            yi += weights[ri]*( ddot( (ptrdiff_t *)&N, input_real+ri*N, &one, x_real+ri*N, &one )
            + ddot( (ptrdiff_t *)&N, input_imag+ri*N, &one, x_imag+ri*N, &one) );
        } else {
            yi += ddot( (ptrdiff_t *)&N, input_real+ri*N, &one, x_real+ri*N, &one )
            + ddot( (ptrdiff_t *)&N, input_imag+ri*N, &one, x_imag+ri*N, &one );
        }
       #ifdef AVOIDMEMCPY
        /* we haven't copied the memory, so we need to undo our stuff */
        /* Each Pauli matrix is self-inverse */
        for ( ni = logN-1 ; ni >= 0 ; ni -- ) { /* do the loop backwards */
           dN = pow(2, ni+1);
           switch ( list[ ni ] ) {
               case 2:
                   xOperatorComplex(N, dN, input_real+ri*N, input_imag+ri*N );
                   break;
               case 3:
                   yOperatorComplex(N, dN, input_real+ri*N, input_imag+ri*N );
                   break;
               case 1:
                   zOperatorComplex(N, dN, input_real+ri*N, input_imag+ri*N );
                   break;
               case 4: // identity
               case 0: // identity
               default:
                   break;
           }
        }
       #endif
    } /* end loop over ri */
    
    return yi; // }}}
}

/* 
 * Stephen Becker,  1/23/13. stephen.beckr@gmail.com
 * Conventions for Pauli:
 *      {0,4}   Identity
 *      1       Z
 *      2       X
 *      3       Y
 *
 * */

#include "pauli.h"
        
/* adding Dec 27 2012, not sure if this is faster */
void swap( double * RESTRICT a, double * RESTRICT b ) {
    *a = *a + *b;
    *b = *a - *b;
    *a = *a - *b;
}
/* neg_swap swaps a and b, and makes both negative */
void neg_swap( double * RESTRICT a, double * RESTRICT b ) {
    *a = -*a - *b;
    *b = *a + *b;
    *a = *a - *b;
}
/* --------------------------------------------------- */
/* Auxiliary functions */
/* --------------------------------------------------- */
void xOperatorComplex( mwSize N, mwSize dN, double * RESTRICT x , double * RESTRICT x_imag) {
    mwIndex     i, j; // {{{
    double      temp;
    mwSize      dN2 = dN/2; // mwSize=size_t is unsigned, ptrdiff_t is signed
    
    #undef USE_DSWAP

    switch (dN) {
        /* unroll the loops for special cases */
        case 2:
            /* we swap every two elements */
            for( i=0 ; i < N ; i += 2 ) {
                temp = x[i];
                x[i] = x[i+1];
                x[i+1] = temp;
                temp = x_imag[i];
                x_imag[i] = x_imag[i+1];
                x_imag[i+1] = temp;
            }
            break;
        case 4:
            /* we swap every four elements */
            for( i=0 ; i < N ; i += 4 ) {
                temp = x[i];
                x[i] = x[i+2];
                x[i+2] = temp;

                temp = x[i+1];
                x[i+1] = x[i+3];
                x[i+3] = temp;

                temp = x_imag[i];
                x_imag[i] = x_imag[i+2];
                x_imag[i+2] = temp;

                temp = x_imag[i+1];
                x_imag[i+1] = x_imag[i+3];
                x_imag[i+3] = temp;
            }
            break;
        case 8:
            /* we swap every eight elements */
            #ifdef USE_DSWAP
            ptrdiff_t   one = 1;
            for( i=0,j=0 ; i < N ; i += 8, j++ ) {
                dswap( &dN2, x + j*dN, &one, x + j*dN + dN2, &one );
                dswap( &dN2, x_imag + j*dN, &one, x_imag + j*dN + dN2, &one );
            }
            #else
            for( i=0 ; i < N ; i += 8 ) {
                temp = x[i];
                x[i] = x[i+4];
                x[i+4] = temp;
                temp = x[i+1];
                x[i+1] = x[i+5];
                x[i+5] = temp;
                temp = x[i+2];
                x[i+2] = x[i+6];
                x[i+6] = temp;
                temp = x[i+3];
                x[i+3] = x[i+7];
                x[i+7] = temp;
                temp = x_imag[i];
                x_imag[i] = x_imag[i+4];
                x_imag[i+4] = temp;
                temp = x_imag[i+1];
                x_imag[i+1] = x_imag[i+5];
                x_imag[i+5] = temp;
                temp = x_imag[i+2];
                x_imag[i+2] = x_imag[i+6];
                x_imag[i+6] = temp;
                temp = x_imag[i+3];
                x_imag[i+3] = x_imag[i+7];
                x_imag[i+7] = temp;
            }
            #endif
            break;
        default:
//             if ( dN == N ) {
            /* New, Nov 1 2011. Call BLAS's "SWAP" function.
             * You can also use the SWAP function if dN < N
             * by modifying the increments, but that's a bit more complicated
             * so just ignoring it for now.
             * Also, I am just using the real version (twice)
             * out of simplicty, but this may have a small performance
             * cost vs using their complex version *
             * 
             * Nov 2012, it doesn't matter much if we do or do not use this.
             * The compiler optimizations are pretty good...
             * */
//              dswap( &dN2, x, &one, x + dN2, &one );
//              dswap( &dN2, x_imag, &one, x_imag + dN2, &one );
//             } else {
              for( i=0 ; i < N ; i += dN ) {
                  for( j=0 ; j < dN2 ; j++ ) {
                      temp = x[i+j];
                      x[i+j] = x[i+dN2+j];
                      x[i+dN2+j] = temp;
                      temp = x_imag[i+j];
                      x_imag[i+j] = x_imag[i+dN2+j];
                      x_imag[i+dN2+j] = temp;
                  }
              }
//             }
            break;
    }
} // }}}

void yOperatorComplex( mwSize N, mwSize dN, double * RESTRICT x , double * RESTRICT x_imag) {
    mwIndex i, j; // {{{
    double temp;
    mwSize dN2 = dN/2;
//     #define USE_SWAP  // seems to be slow!!
    #undef USE_SWAP
    switch (dN) {
        /* unroll the loops for special cases */
        case 2:
            for( i=0 ; i < N ; i += 2 ) {
                #ifdef USE_SWAP
                swap(     &x[i],      &x_imag[i+1] );
                neg_swap( &x_imag[i], &x[i+1] );
                #else
                temp = x[i];
                x[i] = x_imag[i+1];
                x_imag[i+1] = temp;

                temp = -x_imag[i];
                x_imag[i] = -x[i+1];
                x[i+1] = temp;
                #endif
            }
            break;
        case 4:
            for( i=0 ; i < N ; i += 4 ) {
                temp = x[i];
                x[i] = x_imag[i+2];
                x_imag[i+2] = temp;
                temp = x[i+1];
                
                x[i+1] = x_imag[i+3];
                x_imag[i+3] = temp;
                
                /* and now the other part */
                temp = -x_imag[i];
                x_imag[i] = -x[i+2];
                x[i+2] = temp;
                
                temp = -x_imag[i+1];
                x_imag[i+1] = -x[i+3];
                x[i+3] = temp;
            }
            break;
        case 8:
            for( i=0 ; i < N ; i += 8 ) {
                temp = x[i];
                x[i] = x_imag[i+4];
                x_imag[i+4] = temp;

                temp = x[i+1];
                x[i+1] = x_imag[i+5];
                x_imag[i+5] = temp;
                
                temp = x[i+2];
                x[i+2] = x_imag[i+6];
                x_imag[i+6] = temp;
                
                temp = x[i+3];
                x[i+3] = x_imag[i+7];
                x_imag[i+7] = temp;

                temp = -x_imag[i];
                x_imag[i] = -x[i+4];
                x[i+4] = temp;

                temp = -x_imag[i+1];
                x_imag[i+1] = -x[i+5];
                x[i+5] = temp;
                
                temp = -x_imag[i+2];
                x_imag[i+2] = -x[i+6];
                x[i+6] = temp;

                temp = -x_imag[i+3];
                x_imag[i+3] = -x[i+7];
                x[i+7] = temp;
            }
            break;
        default:
            for( i=0 ; i < N ; i += dN ) {
                for( j=0 ; j < dN2 ; j++ ) {
                    temp = x[i+j];
                    x[i+j] = x_imag[i+dN2+j];
                    x_imag[i+dN2+j] = temp;

                    temp = -x_imag[i+j];
                    x_imag[i+j] = -x[i+dN2+j];
                    x[i+dN2+j] = temp;
                }
            }
            break;
    }
} // }}}

void zOperatorComplex( mwSize N, mwSize dN, double * RESTRICT x , double * RESTRICT x_imag) {
    mwIndex i, j; // {{{
    //double temp;
    mwSize dN2 = dN/2;
    /* I can try to unroll the loop vor special cases,
     * but the switch statement might be slowing it down.
     * Actually, the in-lining seems to help */
    switch (dN) {
        case 2:
            for( i=0 ; i < N ; i += 2 ) {
                x[i+1] *= -1;
                x_imag[i+1] *= -1;
            }
            break;
        case 4:
            for( i=0 ; i < N ; i += 4 ) {
                x[i+2] *= -1;
                x[i+3] *= -1;
                x_imag[i+2] *= -1;
                x_imag[i+3] *= -1;
            }
            break;
        case 8:
            for( i=0 ; i < N ; i += 8 ) {
                x[i+4] *= -1;
                x[i+5] *= -1;
                x[i+6] *= -1;
                x[i+7] *= -1;
                x_imag[i+4] *= -1;
                x_imag[i+5] *= -1;
                x_imag[i+6] *= -1;
                x_imag[i+7] *= -1;
            }
            break;
        case 16:
            for( i=0 ; i < N ; i += 16 ) {
                x[i+8] *= -1;
                x[i+9] *= -1;
                x[i+10] *= -1;
                x[i+11] *= -1;
                x[i+12] *= -1;
                x[i+13] *= -1;
                x[i+14] *= -1;
                x[i+15] *= -1;
                x_imag[i+8] *= -1;
                x_imag[i+9] *= -1;
                x_imag[i+10] *= -1;
                x_imag[i+11] *= -1;
                x_imag[i+12] *= -1;
                x_imag[i+13] *= -1;
                x_imag[i+14] *= -1;
                x_imag[i+15] *= -1;
            }
            break;
        default:
            for( i=0 ; i < N ; i += dN ) {
                for( j=dN2 ; j < dN ; j++ ) {
                    x[i+j] *= -1;
                    x_imag[i+j] *= -1;
                }
            }
            break;
    }
} // }}}


void printMatrix( double *X_real, double *X_imag, int totalRows, int rows, int cols ) {
    /* set X_imag to NULL if the matrix is real {{{ */
    int r, c;
    if ( X_imag ) {
        for( r=0; r < rows ; r++ ) {
            mexPrintf("(%d)\t", r+1);
            for (c=0; c < cols; c++) {
                mexPrintf("% .4f + % .4fi\t", X_real[c*totalRows+r], X_imag[c*totalRows+r]);
            }
            mexPrintf("\n");
        }
    } else {
        for( r=0; r < rows ; r++ ) {
            mexPrintf("(%d)\t", r+1);
            for (c=0; c < cols; c++) {
                mexPrintf("% .4f\t", X_real[c*totalRows+r]);
            }
            mexPrintf("\n");
        }
    }
} /* }}} */

int fakePrintf(const char *format, ...){
    return 0;
}
