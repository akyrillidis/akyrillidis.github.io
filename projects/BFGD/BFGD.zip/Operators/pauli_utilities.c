/* 
 * Stephen Becker,  1/23/13. stephen.beckr@gmail.com
 * Conventions for Pauli:
 *      {0,4}   Identity
 *      1       Z
 *      2       X
 *      3       Y
 *
 * */

#include "pauli.h"
        
/* adding Dec 27 2012, not sure if this is faster */
void swap( double * RESTRICT a, double * RESTRICT b ) {
    *a = *a + *b;
    *b = *a - *b;
    *a = *a - *b;
}
/* neg_swap swaps a and b, and makes both negative */
void neg_swap( double * RESTRICT a, double * RESTRICT b ) {
    *a = -*a - *b;
    *b = *a + *b;
    *a = *a - *b;
}
/* --------------------------------------------------- */
/* Auxiliary functions */
/* --------------------------------------------------- */
void xOperatorComplex( mwSize N, mwSize dN, double * RESTRICT x , double * RESTRICT x_imag) {
    mwIndex     i, j; // {{{
    double      temp;
    mwSize      dN2 = dN/2; // mwSize=size_t is unsigned, ptrdiff_t is signed
    
    #undef USE_DSWAP

    switch (dN) {
        /* unroll the loops for special cases */
        case 2:
            /* we swap every two elements */
            for( i=0 ; i < N ; i += 2 ) {
                temp = x[i];
                x[i] = x[i+1];
                x[i+1] = temp;
                temp = x_imag[i];
                x_imag[i] = x_imag[i+1];
                x_imag[i+1] = temp;
            }
            break;
        case 4:
            /* we swap every four elements */
            for( i=0 ; i < N ; i += 4 ) {
                temp = x[i];
                x[i] = x[i+2];
                x[i+2] = temp;

                temp = x[i+1];
                x[i+1] = x[i+3];
                x[i+3] = temp;

                temp = x_imag[i];
                x_imag[i] = x_imag[i+2];
                x_imag[i+2] = temp;

                temp = x_imag[i+1];
                x_imag[i+1] = x_imag[i+3];
                x_imag[i+3] = temp;
            }
            break;
        case 8:
            /* we swap every eight elements */
            #ifdef USE_DSWAP
            ptrdiff_t   one = 1;
            for( i=0,j=0 ; i < N ; i += 8, j++ ) {
                dswap( &dN2, x + j*dN, &one, x + j*dN + dN2, &one );
                dswap( &dN2, x_imag + j*dN, &one, x_imag + j*dN + dN2, &one );
            }
            #else
            for( i=0 ; i < N ; i += 8 ) {
                temp = x[i];
                x[i] = x[i+4];
                x[i+4] = temp;
                temp = x[i+1];
                x[i+1] = x[i+5];
                x[i+5] = temp;
                temp = x[i+2];
                x[i+2] = x[i+6];
                x[i+6] = temp;
                temp = x[i+3];
                x[i+3] = x[i+7];
                x[i+7] = temp;
                temp = x_imag[i];
                x_imag[i] = x_imag[i+4];
                x_imag[i+4] = temp;
                temp = x_imag[i+1];
                x_imag[i+1] = x_imag[i+5];
                x_imag[i+5] = temp;
                temp = x_imag[i+2];
                x_imag[i+2] = x_imag[i+6];
                x_imag[i+6] = temp;
                temp = x_imag[i+3];
                x_imag[i+3] = x_imag[i+7];
                x_imag[i+7] = temp;
            }
            #endif
            break;
        default:
//             if ( dN == N ) {
            /* New, Nov 1 2011. Call BLAS's "SWAP" function.
             * You can also use the SWAP function if dN < N
             * by modifying the increments, but that's a bit more complicated
             * so just ignoring it for now.
             * Also, I am just using the real version (twice)
             * out of simplicty, but this may have a small performance
             * cost vs using their complex version *
             * 
             * Nov 2012, it doesn't matter much if we do or do not use this.
             * The compiler optimizations are pretty good...
             * */
//              dswap( &dN2, x, &one, x + dN2, &one );
//              dswap( &dN2, x_imag, &one, x_imag + dN2, &one );
//             } else {
              for( i=0 ; i < N ; i += dN ) {
                  for( j=0 ; j < dN2 ; j++ ) {
                      temp = x[i+j];
                      x[i+j] = x[i+dN2+j];
                      x[i+dN2+j] = temp;
                      temp = x_imag[i+j];
                      x_imag[i+j] = x_imag[i+dN2+j];
                      x_imag[i+dN2+j] = temp;
                  }
              }
//             }
            break;
    }
} // }}}

void yOperatorComplex( mwSize N, mwSize dN, double * RESTRICT x , double * RESTRICT x_imag) {
    mwIndex i, j; // {{{
    double temp;
    mwSize dN2 = dN/2;
//     #define USE_SWAP  // seems to be slow!!
    #undef USE_SWAP
    switch (dN) {
        /* unroll the loops for special cases */
        case 2:
            for( i=0 ; i < N ; i += 2 ) {
                #ifdef USE_SWAP
                swap(     &x[i],      &x_imag[i+1] );
                neg_swap( &x_imag[i], &x[i+1] );
                #else
                temp = x[i];
                x[i] = x_imag[i+1];
                x_imag[i+1] = temp;

                temp = -x_imag[i];
                x_imag[i] = -x[i+1];
                x[i+1] = temp;
                #endif
            }
            break;
        case 4:
            for( i=0 ; i < N ; i += 4 ) {
                temp = x[i];
                x[i] = x_imag[i+2];
                x_imag[i+2] = temp;
                temp = x[i+1];
                
                x[i+1] = x_imag[i+3];
                x_imag[i+3] = temp;
                
                /* and now the other part */
                temp = -x_imag[i];
                x_imag[i] = -x[i+2];
                x[i+2] = temp;
                
                temp = -x_imag[i+1];
                x_imag[i+1] = -x[i+3];
                x[i+3] = temp;
            }
            break;
        case 8:
            for( i=0 ; i < N ; i += 8 ) {
                temp = x[i];
                x[i] = x_imag[i+4];
                x_imag[i+4] = temp;

                temp = x[i+1];
                x[i+1] = x_imag[i+5];
                x_imag[i+5] = temp;
                
                temp = x[i+2];
                x[i+2] = x_imag[i+6];
                x_imag[i+6] = temp;
                
                temp = x[i+3];
                x[i+3] = x_imag[i+7];
                x_imag[i+7] = temp;

                temp = -x_imag[i];
                x_imag[i] = -x[i+4];
                x[i+4] = temp;

                temp = -x_imag[i+1];
                x_imag[i+1] = -x[i+5];
                x[i+5] = temp;
                
                temp = -x_imag[i+2];
                x_imag[i+2] = -x[i+6];
                x[i+6] = temp;

                temp = -x_imag[i+3];
                x_imag[i+3] = -x[i+7];
                x[i+7] = temp;
            }
            break;
        default:
            for( i=0 ; i < N ; i += dN ) {
                for( j=0 ; j < dN2 ; j++ ) {
                    temp = x[i+j];
                    x[i+j] = x_imag[i+dN2+j];
                    x_imag[i+dN2+j] = temp;

                    temp = -x_imag[i+j];
                    x_imag[i+j] = -x[i+dN2+j];
                    x[i+dN2+j] = temp;
                }
            }
            break;
    }
} // }}}

void zOperatorComplex( mwSize N, mwSize dN, double * RESTRICT x , double * RESTRICT x_imag) {
    mwIndex i, j; // {{{
    //double temp;
    mwSize dN2 = dN/2;
    /* I can try to unroll the loop vor special cases,
     * but the switch statement might be slowing it down.
     * Actually, the in-lining seems to help */
    switch (dN) {
        case 2:
            for( i=0 ; i < N ; i += 2 ) {
                x[i+1] *= -1;
                x_imag[i+1] *= -1;
            }
            break;
        case 4:
            for( i=0 ; i < N ; i += 4 ) {
                x[i+2] *= -1;
                x[i+3] *= -1;
                x_imag[i+2] *= -1;
                x_imag[i+3] *= -1;
            }
            break;
        case 8:
            for( i=0 ; i < N ; i += 8 ) {
                x[i+4] *= -1;
                x[i+5] *= -1;
                x[i+6] *= -1;
                x[i+7] *= -1;
                x_imag[i+4] *= -1;
                x_imag[i+5] *= -1;
                x_imag[i+6] *= -1;
                x_imag[i+7] *= -1;
            }
            break;
        case 16:
            for( i=0 ; i < N ; i += 16 ) {
                x[i+8] *= -1;
                x[i+9] *= -1;
                x[i+10] *= -1;
                x[i+11] *= -1;
                x[i+12] *= -1;
                x[i+13] *= -1;
                x[i+14] *= -1;
                x[i+15] *= -1;
                x_imag[i+8] *= -1;
                x_imag[i+9] *= -1;
                x_imag[i+10] *= -1;
                x_imag[i+11] *= -1;
                x_imag[i+12] *= -1;
                x_imag[i+13] *= -1;
                x_imag[i+14] *= -1;
                x_imag[i+15] *= -1;
            }
            break;
        default:
            for( i=0 ; i < N ; i += dN ) {
                for( j=dN2 ; j < dN ; j++ ) {
                    x[i+j] *= -1;
                    x_imag[i+j] *= -1;
                }
            }
            break;
    }
} // }}}


void printMatrix( double *X_real, double *X_imag, int totalRows, int rows, int cols ) {
    /* set X_imag to NULL if the matrix is real {{{ */
    int r, c;
    if ( X_imag ) {
        for( r=0; r < rows ; r++ ) {
            mexPrintf("(%d)\t", r+1);
            for (c=0; c < cols; c++) {
                mexPrintf("% .4f + % .4fi\t", X_real[c*totalRows+r], X_imag[c*totalRows+r]);
            }
            mexPrintf("\n");
        }
    } else {
        for( r=0; r < rows ; r++ ) {
            mexPrintf("(%d)\t", r+1);
            for (c=0; c < cols; c++) {
                mexPrintf("% .4f\t", X_real[c*totalRows+r]);
            }
            mexPrintf("\n");
        }
    }
} /* }}} */

int fakePrintf(const char *format, ...){
    return 0;
}
