function [T,list] = getpauli(n,k,LIST_ONLY)
% W = getpauli( n, k )
% Construct the Pauli matrix on n qubits specified by 0 <= k < 4^n
%
% [W,list] = ...
%   returns the 'list' of the Pauli operators,
%   that is, the sequence {0,1,2,3}
%
% [W,list] = getpauli(n,k,LIST_ONLY)
%   will save time by NOT constructing "W" if LIST_ONLY==true.
%
% W = getpauli( list )
%   will make the explicit matrix corresponding to list
%
% Yi-Kai Liu, Stephen Becker, 2011 

% New mode, added Jan 19 2012
if nargin == 1
    list = n;
    n    = length(list);
    I = sparse([1,0;0,1]); % type 0
    X = sparse([0,1;1,0]); % type 2
    Y = sparse([0,-1i;1i,0]); % type 3, use 1i for imaginary unit
    Z = sparse([1,0;0,-1]); % type 1
    
    T = sparse(1);
    for i=1:n
        t = list(i);
        switch t
            case 0
                T = kron(I,T);
            case 2
                T = kron(X,T);
            case 3
                T = kron(Y,T);
            case 1
                T = kron(Z,T);
        end
    end
    return;
end


if nargin < 3 || isempty( LIST_ONLY ), LIST_ONLY=false; end

if ~LIST_ONLY
    I = sparse([1,0;0,1]); % type 0
    X = sparse([0,1;1,0]); % type 2
    Y = sparse([0,-1i;1i,0]); % type 3, use 1i for imaginary unit
    Z = sparse([1,0;0,-1]); % type 1
    
    % Build up by taking tensor products
    % Last qubit => least significant bit of k
    % First qubit => most significant bit of k
    T = sparse(1);
else 
    T = [];
end

list = zeros(n,1);
for i=1:n
    t = mod(k,4);
    list(i) = t;
    if ~LIST_ONLY
        switch t
            case 0
                T = kron(I,T);
            case 2
                T = kron(X,T);
            case 3
                T = kron(Y,T);
            case 1
                T = kron(Z,T);
        end
    end
    k = (k-t)/4;
end