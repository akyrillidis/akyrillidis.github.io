function pauli_adjoint( varargin )
% Atbx=pauli_adjoint(x,list,b,[nThreads]), where n is a power of 2
%  x should be real, of size n x r
%  list is a matrix of size log2(n) x m, with entries 0,1,2 or 3
%  and this specifies the order of the Pauli operations
%  The output Atbx = (A'b)*x is of size n x r
% List is a matrix of size log2(n) x m, with entries 0, 1, 2 or 3
%       of type int64, where 
%       0 or 4      = identity
%       1           = pauli Z matrix
%       2           = pauli X matrix
%       3           = pauli Y matrix
%
% This is a mex file, so must be compiled.
% Stephen Becker, 2012-3
% See also pauli_forward.m
error('mex file does not exist! Please compile and/or add to your path');
