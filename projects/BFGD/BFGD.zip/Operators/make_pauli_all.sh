#!/usr/bin/env bash

cat pauli_forward.c pauli_utilities.c > pauli_forward_all.c
echo "just made pauli_forward_all.c"
cat pauli_adjoint.c pauli_utilities.c > pauli_adjoint_all.c
echo "just made pauli_adjoint_all.c"
