function pauli_forward( varargin )
% Ax = pauli_forward( x, list, [nThreads], [diagWeights] )
%   where x is real or complex, of size n x r (and n is a power of 2)
%       the matrix X = x*x' will be implicitly used
%   and list is a matrix of size log2(n) x m, with entries 0, 1, 2 or 3
%       of type int64, where 
%       0 or 4      = identity
%       1           = pauli Z matrix
%       2           = pauli X matrix
%       3           = pauli Y matrix
%   nThreads is the number of threads to use (using pthreads). This is buggy!
%       so, set nThreads = 1 is recommended.
%   diagWeights will use the implicit matrix X = x*diag(diagWeights)*x' instead of x*x'
%   Output Ax is of size m x 1
%
% This is a mex file, so must be compiled.
% Stephen Becker, 2012
% See also pauli_adjoint.m
error('mex file does not exist! Please compile and/or add to your path');
