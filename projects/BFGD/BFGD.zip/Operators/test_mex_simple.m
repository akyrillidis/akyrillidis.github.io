function test_mex_simple(n,nThreads)
% test_mex_simple(n,nThreads)
vec = @(x) x(:);
if nargin < 2
nThreads = 4; % define at very top of file now
end
if nargin < 1
n = 9; % number of qubits
end
d = 2^n; % Hilbert space dimension
r = 2; % rank of our estimated state rhohat
m = 4*d*r; % number of Pauli observables
fprintf('Initializing: n = %d, d = %d, r = %d, m = %d, nThreads = %d\n', n, d, r, m, nThreads);
psi = ( randn(d,r) + 1i*randn(d,r) )/sqrt(d);
psi = psi/sqrt(psi'*psi); % Normalize
x   = psi; % for notation...

LARGESCALE = d >= 2^11;
if LARGESCALE
    PAULI_T = sparse( [], [], [], d^2, m, 0 );
else
    PAULI_T = sparse([],[],[],d^2,m,m*d );
    PAULI_MAT_T = [];
end
fprintf('Taking measurements...      ');
obs = cell(m,1);
LIST = zeros(m,n);
if ~LARGESCALE
    p = randperm((d^2)-1);
    p = p(1:m);
else
    p   = randi( [1,d^2-1], 1, 2*m); % take extra, i.e. 2*m instead of m
    [~,I,J] = unique( p );
    I = sort(I); I = I(1:m);
    p = p(I);
end
cntr = 0;
TEMP = [];
tic
for i=1:m
    if ~mod(i,200)
        fprintf('\b\b\b\b\b\b%5.1f%%', 100*i/m );
    end
    if ~LARGESCALE
        [obs{i},list] = getpauli(n, p(i));
        PAULI_T(:,i) = vec(obs{i});  % access via column is MUCH faster
        cntr = cntr + 1;
        TEMP    = [TEMP, obs{i} ];
        if ~mod(cntr,20)
            PAULI_MAT_T = [PAULI_MAT_T, TEMP];
            TEMP = [];
        end
    else
        LIST_ONLY = true;
        [obs{i},list] = getpauli(n, p(i), LIST_ONLY);
    end
    LIST(i,:) = list;
end
if ~LARGESCALE
    PAULI_MAT_T = [PAULI_MAT_T, TEMP];
    clear TEMP
end
fprintf('\n');
toc
if ~LARGESCALE
PAULI = PAULI_T'; % this lets b2==b1 below
PAULI_MAT = PAULI_MAT_T'; % Nov 14. 
    disp(' ');
    disp('Standard version. time is: ');
    tic; b1  = PAULI*vec(x*x'); toc
    fprintf('Imag part of measurements: %.2e\n', norm(imag(b1)) );
    b1  = real(b1);
    
else
    b1 = randn(m,1);
end
%% 
fprintf('comparing...\n')
list = int64( LIST' ); 
%nThreads = 4; % define at very top of file now
disp('mex file for forward multiply:');
weights     = -ones(r,1);
if ~isempty(nThreads) && nThreads >= 1
tic
b4 = pauli_forward( x, list, nThreads, weights);
toc
else
    % do several threads
    for nThreads_i = [1,2,4,8,12]
    tic
    b4 = pauli_forward( x, list, nThreads_i, weights);
    t=toc;
    fprintf('Forward multiply, %2d threads, took %.2f s\n',nThreads_i,t);

    end
end
if ~LARGESCALE
    disp('sparse multiply:');
    tic
    if ~isempty(weights)
        b1  = PAULI*vec(x*diag(weights)*x');
    else
        b1  = PAULI*vec(x*x');
    end
    toc
    fprintf('Discrepancy: %.2e\n', norm(b1-b4) );
end


% OLD results...
% n = 2^13, takes 6.1 seconds with 4 threads, 6.5 seconds with 8 threads
%           10.2 seconds with 2 threads, 15.15 seconds with 1 thread
%           ??? Nov 8, when I re-run this, it takes 23.5 seconds if I don't use pthreads option
% n = 2^13, with OpenMP code (and set CPU to 1.6 GHz)
%           takes 12 seconds with 4 threads, 11.4 seconds with 8 threads
%           18 seconds with 2 threads, 23.4 seconds with 1 thread
%           OpenMP code, with -Dno_use_omp: 23.3 seconds.
%   n = 2^12, OpenMP without defining OMP, takes 5.7 seconds (1.4 if all identities)

% 1 thread. Without dswap for dN=N, {14.2, 13.9, 14.5} seconds
%           with dswap, {14.6, 14.7, 14.27} seconds. Makes little difference.

%% Test adjoint
if ~LARGESCALE && d <= 128
    mat     = @(x) reshape(x,d,d);
    grad    = mat( PAULI'*b1 );
    
    disp('Calculating adjoint with mex...');
    list    = int64( LIST' );
    rhs     = eye(d);
    g       = pauli_adjoint(rhs, list, b1, nThreads );
    
    fprintf('Error with adjoint: %.2e\n',norm(g-grad))
    %dG      = g-grad;
else
    % just do a speed test
    b1      = ones(m,1);
    rhs     = randn(d,2);
if ~isempty(nThreads) && nThreads >= 1
    disp('Calculating adjoint with mex...');
    tic
    g       = pauli_adjoint(rhs, list, b1, nThreads );
    toc
    else
    % do several threads
    for nThreads_i = [1,2,4,8,12]
        tic
        g = pauli_adjoint( rhs, list,b1, nThreads_i );
        t=toc;
        fprintf('Adjoint multiply, %2d threads, took %.2f s\n',nThreads_i,t);
    end


    end
end
