% mex -O pauli_forward_all.c  -o pauli_forward.mexa64 -lm  -UAVOIDMEMCPY ...
mex -O pauli_forward_all.c  -output pauli_forward -lblas -UAVOIDMEMCPY ...  -lm ...
  -Uno_pthreads -DNDEBUG -UDEBUG -outdir './' ... %/home/yurtseve/MatlabExperiments/UniProx_ProPack/QuantumTomography/mexCode
-L/usr/local/lib -v
  % -L/home/yurtseve/MatlabExperiments/UniProx_ProPack/QuantumTomography/mexCode
%/home/stbecker/lib
  % trying my netlib .a file
  %-L/usr/local/apps/blas/gcc-4.1.2/lib
  % Try combining pauli_forward + pauli_utilities >> pauli_forward_all
%% for adjoint            
% mex -O pauli_adjoint_all.c -o pauli_adjoint.mexa64 -lm ...
mex -O pauli_adjoint.c pauli_utilities.c -lm -lblas -lm -UAVOIDMEMCPY ...
  -Uno_pthreads -UDEBUG -DNDEBUG -outdir './' ... %'/home/yurtseve/MatlabExperiments/UniProx_ProPack/QuantumTomography/mexCode' ...
  -L/usr/local/lib -v
%-L/home/yurtseve/MatlabExperiments/UniProx_ProPack/QuantumTomography/mexCode
  %-L/usr/local/apps/blas/gcc-4.1.2/lib

  % I can use -lblas with /home/stbecker/lib, but then have to set runtime directories
  % let's just use static version, whcih I linkd to libstaticblas.a

%{
    -> gcc -O -pthread -shared -Wl,--version-script,/usr/local/apps/matlab/R2011b/extern/lib/glnxa64/mexFunction.map -Wl,--no-undefined -o  "/scratch/stbecker/pauli_forward.mexa64"  /scratch/stbecker/pauli_forward.o /scratch/stbecker/pauli_utilities.o  -lm -lblas -lm -L/home/stbecker/lib -Wl,-rpath-link,/usr/local/apps/matlab/R2011b/bin/glnxa64 -L/usr/local/apps/matlab/R2011b/bin/glnxa64 -lmx -lmex -lmat -lm -lstdc++

/scratch/stbecker/pauli_utilities.o: In function `__pthread_cleanup_routine':
pauli_utilities.c:(.text+0x0): multiple definition of `__pthread_cleanup_routine'
/scratch/stbecker/pauli_forward.o:pauli_forward.c:(.text+0x0): first defined here
collect2: ld returned 1 exit status
%}
