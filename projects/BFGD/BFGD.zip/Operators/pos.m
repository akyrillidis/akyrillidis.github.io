function P = pos(A)

P = A .* double( A > 0 );