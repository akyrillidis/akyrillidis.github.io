Files:
pauli_adjoint.c         good
pauli_forward.c         good
hide/pauli_forward_new.c     bad (tried avoiding allocating memory and doing stuff on-the-fly, but MUCH slower)
hide/pauli_forward_OMP.c     ? old. I got pauli_forward.c to work with pthreads, so use that
pauli_utilities.c       good -- used by the other code

on electra, mex pauli_forward.c pauli_utilities.c ... didn't work
so, I did 'cat pauli_forward.c pauli_utilities.c > pauli_forwards_all.c ' and compiled that

