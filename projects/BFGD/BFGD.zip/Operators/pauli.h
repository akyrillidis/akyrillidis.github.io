#ifndef __PAULI_H_INCLUDED__
    #define __PAULI_H_INCLUDED__

#include <stdio.h>
#include <stdlib.h> /* for atoi, atof */
#include <string.h> /* for memcpy */
#include "mex.h"
// Note: if you include mex.h, it will redefine printf to be mexPrintf
// mex.h inclues matrix.h, which is all we really need anyhow
#include <math.h>    /* for pow() */
#include <assert.h>

//#include "matrix.h"
#include "blas.h"    /* from mathworks file */


#define myPrintf printf

/* to use "mwSize", need matrix.h, but doesn't work for R2006a */
/* So, use the following definitions instead: */
#ifndef mwSize
    #define mwSize size_t
#endif
#ifndef mwIndex
    #define mwIndex size_t  /* should make it compatible w/ 64-bit systems */
#endif
#ifndef true
 #define true 1
#endif
#ifndef false
 #define false 0
#endif

#ifdef __cplusplus
 #define RESTRICT __restrict__
#else
 #define RESTRICT restrict
#endif


#define use_pthreads
#ifdef no_pthreads
  #undef use_pthreads
#endif
#if defined(_WIN32) || defined(_WIN64)
    #undef use_pthreads
    /* for 32-bit Windows, try http://sourceware.org/pthreads-win32/
     * for 64-bit Windows, it looks complicated...
     * */
#endif
// #define use_omp

#ifdef use_pthreads
  #include <pthread.h>
  #ifdef AVOIDMEMCPY /* Dec 27 2012 */
        /* I don't think this mode is thread-safe, so disable it */
   #undef AVOIDMEMCPY
  #endif
#endif
// #ifdef use_omp
//   #include "omp.h"
//   /* see ~/from_ACM/research/parallelMultiply/parallelMultiply.c */
// #endif

//#include <pmmintrin.h>     // SSE3 required. For __builtin_assume_aligned()






/* ************** in pauli_utilities.cpp ************** */
void printMatrix( double *X_real, double *X_imag, int totalRows, int rows, int cols );
//void printMatrix( double *X_real, double *X_imag, mwSize totalRows, mwSize rows, mwSize cols );
#ifdef DEBUG
  #define debugPrintf myPrintf
#else
  #define debugPrintf fakePrintf
#endif
int fakePrintf(const char *format, ...);

void xOperatorComplex( mwSize N, mwSize dN, double * RESTRICT x , double * RESTRICT x_imag);
void yOperatorComplex( mwSize N, mwSize dN, double * RESTRICT x , double * RESTRICT x_imag);
void zOperatorComplex( mwSize N, mwSize dN, double * RESTRICT x , double * RESTRICT x_imag);
void swap(     double * RESTRICT a, double * RESTRICT b );
void neg_swap( double * RESTRICT a, double * RESTRICT b );

#endif // __PAULI_H_INCLUDED__
