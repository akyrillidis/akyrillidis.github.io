% ========================================================================
%             Demo for MC  - comparison with other algorithms
%                   (Takes approx. 3-4 minutes to run)
%
% This file includes the actual implementation of BFGD algorithm,
% as explained in 
%
% [1] "Finding low-rank solutions to matrix problems, efficiently and provably",
% by Dohyung Park, Anastasios Kyrillidis and, Constantine Caramanis, and 
% Sujay Sanghavi.
% =========================================================================
% 09/01/2016, by Anastasios Kyrillidis. anastasios@utexas.edu, UTA.
% =========================================================================

close all;
clear;
clc;

addpath(genpath('./BFGD/'));            % Contains FGD variants
addpath(genpath('./Operators/'));      % Contains MC operator, noiselet operator, etc..
addpath(genpath('./PROPACK/'));

%% Synthetic matrix sensing problem
% First example - matrix sensing with random Noiselet operators
m = 1024;
n = 2048;

Csample = 4;
r = 100;
sigma = 0;
params.iters = 4000;             % Number of iterations
            
no_alg = 2;
Xtotaltime = zeros(no_alg, 1);
Xtimes = zeros(no_alg, params.iters);
Xcurves = zeros(no_alg, params.iters);
fcurves = zeros(no_alg, params.iters);
Xerrors = zeros(no_alg, 1);

% Number of samples
p = floor(Csample * n * r);  

% Noiselet mapping (slower than matrix completion map)
[ix, iy, p] = randmask(m, n, p);
linearInd = sub2ind([m n], double(ix), double(iy)); 
idx = linearInd(:);
idx2 = randperm(m * n);
            
A_id = @(z) Anoiselet(z,idx, idx2);
At_id = @(z) Atnoiselet(z, idx, idx2, [m n]);    
            
% % Matric completion mapping in case noiselets package is not working at your PC
% [ix, iy, p] = randmask(m, n, p);            % random sampling indices (syy)
% linearInd = sub2ind([m n], ix, iy);         % iy is the row number, ix is the column number (syy)
% idx = linearInd(:);
% 
% A_id = @(z) z(idx);
% At_id = @(z) full(sparse(double(ix), double(iy), z, m, n));

% Generate random Xstar as Xstar = Ustar * Vstar'
Ustar = randn(m, r); 
Vstar = randn(n, r);
Xstar = Ustar * Vstar';
Xstar = Xstar./norm(Xstar, 'fro');

% Error term
e = randn(p, 1);
e = sigma * e/norm(e);

% Set of samples
y = A_id(Xstar) + e;

% use operator library (A_id_test, At_id_test)
% f = @(x) 1/2 * norm(y - A_id(x), 2)^2;
% f_grad = @(x) -At_id(y - A_id(x));

f      = @(u, v) 1/2 * norm(y - A_id(u*v'), 2)^2 + 1/16 * norm(u'*u - v'*v, 'fro')^2;
f_grad = @(x) -At_id(y - A_id(x));

% Set parameters for algorithms
params.tol = 1e-5;              % Convergence tolerance
params.Uinit = randn(m, r);     % In case a random initialization is used
params.Vinit = randn(n, r);
params.UVpath = 1;              % Flag for keeping the history of estimates 
params.n = n;                   % Dimensions
params.m = m;
params.r = r;                   % Rank
params.p = p;                   % Number of samples
params.Xstar = Xstar;           % True solution (I'm not going to use that)                   
params.Ustar = Ustar;           % True factor U (I'm not going to use that)                   
params.Vstar = Vstar;           % True factor V (I'm not going to use that)                   

% Bilinear Factored Gradient Descent function (BFGD) 
params.init = 1;                % Initialization selection ((not always) 0 = random, 1 = ours, 2 = theirs)
params.verbose = 1;

t1 = clock;
disp('=====================================================================');            
[Xhat1, output1] = BFGD(f, f_grad, params);
timeAlg1 = etime(clock, t1);

str = sprintf('BFGD algorithm terminated - Our init. - Error norm: %f ', norm(Xstar - Xhat1, 'fro')/norm(Xstar, 'fro'));
disp(str);
str = sprintf('Number of iterations: %f ', output1.numiter);
disp(str);
str = sprintf('Time consumed: %f', timeAlg1);
disp(str);            

Xtotaltime(1) = timeAlg1;
Xerrors(1) = norm(Xhat1 - Xstar, 'fro')/norm(Xstar, 'fro');
Xtimes(1, 1:output1.numiter) = output1.times;
Xcurves(1, 1:output1.numiter) = output1.Xpath;
fcurves(1, 1:output1.numiter) = output1.fpath; 

% Bilinear Factored Gradient Descent function (BFGD) 
params.init = 0;                % Initialization selection ((not always) 0 = random, 1 = ours, 2 = theirs)

t2 = clock;
disp('=====================================================================');            
[Xhat2, output2] = BFGD(f, f_grad, params);
timeAlg2 = etime(clock, t2);

str = sprintf('BFGD algorithm terminated - Random init. - Error norm: %f ', norm(Xstar - Xhat2, 'fro')/norm(Xstar, 'fro'));
disp(str);
str = sprintf('Number of iterations: %f ', output2.numiter);
disp(str);
str = sprintf('Time consumed: %f', timeAlg2);
disp(str);            

Xtotaltime(2) = timeAlg2;
Xerrors(2) = norm(Xhat2 - Xstar, 'fro')/norm(Xstar, 'fro');
Xtimes(2, 1:output2.numiter) = output2.times;
Xcurves(2, 1:output2.numiter) = output2.Xpath;
fcurves(2, 1:output2.numiter) = output2.fpath; 

COLORS=[210,  80,  80; % a nice red
         21, 114, 172; % nice blue
        ]/255;

linestyles = {'--';'-.'};
markerstyles = {'o';'^'};
fontsize = 24;

labels = {'$\texttt{BFGD}$ - Our Init.', ...
          '$\texttt{BFGD}$ - Random Init.'};           

no_alg = 2;
r = 100;

figure(randi(10000));
set(gca,'ColorOrder', COLORS, 'NextPlot', 'replacechildren');
co = get(gca,'ColorOrder');  
set(gca,'fontsize',fontsize)

h = semilogy(cumsum(output1.times), Xcurves(1, 1:output1.numiter), ...
             cumsum(output2.times), Xcurves(2, 1:output2.numiter));
xlabel('Time (sec)', 'Interpreter', 'latex')
ylabel('$\frac{\|\widehat{X} - X^\star\|_F}{\|X^\star\|_F}$', 'Interpreter', 'latex')
Csample = 4;        
title(sprintf('Rank $r = %d$ -  Samples $p = %d \\cdot n \\cdot r$', r, Csample), 'Interpreter', 'latex');
lh = legend(labels, 'Location', 'NorthEast');
set(lh, 'Interpreter', 'latex');
grid on;

for ii = 1:numel(h)
    set(h(ii), {'LineStyle'}, linestyles(ii));
    set(h(ii), 'linewidth', 3);
end

box on;
set(gca,'units','centimeters')
pos = get(gca,'Position');
ti = get(gca,'TightInset');

set(gcf, 'PaperUnits','centimeters');
a = pos(3)+ti(1)+ti(3);
b = pos(4)+ti(2)+ti(4);
set(gcf, 'PaperSize', [a, b]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition',[0 0 a, b]);