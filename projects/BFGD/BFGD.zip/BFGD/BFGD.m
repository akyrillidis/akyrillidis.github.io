function [Xhat, output] = BFGD(f, f_grad, params)
% =========================================================================
%    The Bilinear Factored Gradient Descent algorithm for matrix completion
% 
% This file includes the actual implementation of BFGD algorithm,
% as explained in 
%
% [1] "Finding low-rank solutions to matrix problems, efficiently and provably",
% by Dohyung Park, Anastasios Kyrillidis and, Constantine Caramanis, and 
% Sujay Sanghavi.
% =========================================================================
% INPUT ARGUMENTS:
% f                         Operator that computes least squares objective
% f_grad                    Operator that computes gradient of LS.
% params                    Structure of parameters. See demo file for
%                           configuration
% =========================================================================
% 
% OUTPUT ARGUMENTS:
% Xhat                     m x n recovered rank-r matrix.
% output                   Structure with various information.
% =========================================================================
% 09/01/2016, by Anastasios Kyrillidis. anastasios@utexas.edu, UTA.
% =========================================================================

tic;
options.tol = 10^-3;

% Initialization
if (params.UVpath == 1)
    output.Xpath = zeros(params.iters, 1);
    output.times = zeros(params.iters, 1);
    output.fpath = zeros(params.iters, 1);
end;

n = params.n;
m = params.m;
r = params.r;

% U,V,X current and previous estimates allocation
if (params.init == 0) % Random
    Ucur = params.Uinit; Ucur = Ucur./norm(Ucur, 'fro');
    Vcur = params.Vinit; Vcur = Vcur./norm(Vcur, 'fro');
    Xcur = Ucur * Vcur';
    Xprev = Xcur;
    
    [~, S1, ~] = lansvd([Ucur; Vcur], 1, 'L');  
    norm_grad = f_grad(Xcur);
    [~, S2, ~] = lansvd(norm_grad, 1, 'L');  
    
    grad0 = f_grad(zeros(m, n));
    grad1 = f_grad(ones(m, n));
    mu_est = 2*norm(grad0 - grad1, 'fro')/(min(m,n));
    
elseif (params.init == 1)   % Our initialization
    % Compute 1/M * gradf(0)
    grad0 = f_grad(zeros(m, n));
    grad1 = f_grad(ones(m, n));
    mu_est = 2*norm(grad0 - grad1, 'fro')/(min(m,n));
    Xcur = -(1/mu_est) * grad0;
    
    % P_r(gradf(0))
    [Ur, Sr, Vr] = lansvd(Xcur, r, 'L', options);
    Ucur = Ur * sqrt(Sr); Ucur = Ucur./norm(Ucur, 'fro');
    Vcur = Vr * sqrt(Sr); Vcur = Vcur./norm(Vcur, 'fro');
    Xcur = Ucur * Vcur';
    Xprev = Xcur;
    
    S1 = Sr;
    norm_grad = f_grad(Xcur);
    [~, S2, ~] = lansvd(norm_grad, 1, 'L');      
end

% Aggressive eta compared to theory for the purpose of this experiment - change 
% constants accordingly for your own purposes.
if (params.init == 0)
    eta = 1/( 0.1 * mu_est * S1(1,1) + S2(1,1));
elseif (params.init == 1)
    eta = 1/( 2 * mu_est * S1(1,1) + S2(1,1));
end;

if (params.verbose)
    str = sprintf('Iter.         Error norm ');
    disp(str);
    str = sprintf('-----------------------------');
    disp(str);
end;
i = 1;
while (i <= params.iters)
    if (params.UVpath == 1)
        output.Xpath(i) = norm(Ucur * Vcur' - params.Xstar,'fro')/norm(params.Xstar, 'fro');
        output.times(i) = toc; tic;
        output.fpath(i) = f(Ucur, Vcur);
    end;        

    f_gradX = f_grad(Ucur * Vcur');
    gradU = f_gradX * Vcur + (1/4) * Ucur*(Ucur'*Ucur - Vcur'*Vcur);
    gradV = f_gradX' * Ucur + (1/4) * Vcur*(Vcur'*Vcur - Ucur'*Ucur);

    Ucur = Ucur - eta * gradU;
    Vcur = Vcur - eta * gradV;
    Xcur = Ucur * Vcur';
    
    % Using Xstar only for plotting
    if (params.verbose)
        str = sprintf('%d            %f ', i, norm(Xcur - params.Xstar,'fro')/norm(params.Xstar, 'fro'));
        disp(str);
    end;
    
    % Test stopping criterion
    if ((i > 1) && (norm(Xcur - Xprev, 'fro') < params.tol * norm(Xcur, 'fro')) || isnan(norm(Xcur - Xprev, 'fro')/norm(Xcur, 'fro')))
        break;
    end
    i = i + 1;  
    Xprev = Xcur;        
end

Xhat = Ucur * Vcur';
numiter = i;

if (params.UVpath == 1)
    if (i > params.iters)
        numiter = numiter - 1;
    end;
    output.numiter = numiter;
    output.Xpath = output.Xpath(1:numiter);
    output.times = output.times(1:numiter);
    output.fpath = output.fpath(1:numiter);
else output = [];
end;