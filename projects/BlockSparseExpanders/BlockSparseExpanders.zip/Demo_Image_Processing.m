clear
close all
clc

% Add paths
addpath Data/;
addpath(genpath('decoptSolver'));
addpath('utilities/');

% Setup algorithm - general parameters
param.MaxIters = 1e4;
param.Verbosity = 2;
param.PrintStep = 25;
param.RelTolX = 1e-6;
param.RelTolFun = 1e-6;
param.RelTolFeas = 1e-6;
param.InnerRelTol = 1e-6;
param.saveHistMode = 4;
param.Algorithm = 3;
param.InnerMaxIters = 5;
param.adaptStepSize = 1;
param.resume = 0; % But it is important to back up before continueing...
param.fsave = 'test3';
save(param.fsave);

% Load data
load ImgMask1;
indices = [5 34 45 54 70 89 107 118 176 204];

% Parameters
n = 128;
gs = [4 8 16];
ms = round((0.25:0.05:0.4).*n^2);

% Pre-allocate structures - 1: expander + l1, 2: gaussian + l1, 3: expander + l2,1, 4: expander + l2,1
error = zeros(4, numel(gs), numel(ms), numel(indices));
time = zeros(4, numel(gs), numel(ms), numel(indices));
x_hat = zeros(4, numel(gs), numel(ms), numel(indices), n^2);
time_A = zeros(2, numel(ms));

for i = 1:numel(gs)
    g = gs(i);
    M = round(n^2/g);
    % Setup group structure
    ind_i = repmat(1:M,[g, 1]);
    ind_i = ind_i(:);
    ind_j = 1:n^2;
    values = ones(n^2,1);
    GG = sparse(ind_i, ind_j, values, M, n^2);
    groups = ind_i;
    
    for j = 1:numel(ms)
        m = ms(j);
        for l = 1:numel(indices)
            [i j l]
            % Load and preprocess image
            Img0 = ImgMask1{indices(l),1};
            mask = ImgMask1{indices(l), 2};
            bin = repmat(mask, [1, 1, 3]);
            Img0 = im2double(Img0);
            x = Img0.*bin;
            X0 = rgb2gray(x);
            x_star = imresize(X0,[n n],'bilinear'); 
            x_star = x_star';
            x_star = x_star(:);         % Image in vector form

            k = ceil(nnz(x_star)/g)+5;
            
            %% Measurement matrices
            % Expander stuff
            d = ceil(20 * log(k * M) / g);          % Degree from theory
            t0 = clock;
            A = bin_mat(d, m, n^2);
            time_A(1, j) = etime(clock, t0);  
            
            % Setup inline commands
            Phi.A = @(x) (1/d) * A * x;
            Phi.At = @(x) (1/d)* A' * x;

            % Measurements and init. point
            yA = Phi.A(x_star);
            x0A = Phi.At(yA);

            % Gaussian stuff
            t0 = clock;
            B = (1/sqrt(m)) * randn(m, n^2);
            time_A(2, j) = etime(clock, t0);  
            
            % Setup inline commands
            Psi.B = @(x) B * x;
            Psi.Bt = @(x) B' * x;

            % Measurements and init. point
            yB = Psi.B(x_star);
            x0B = Psi.Bt(yB);
                        
            %% l1-norm stuff
            proxOpers{1} = @(x, gamma, varargin) proxL1norm(x, gamma);
            proxOpers{2} = @(x, gamma, varargin) projL2norm(x, 1e-12);

            proxOpers{3} = @(x, varargin) norm(x,1);
            proxOpers{4} = @(x, varargin) (0);
            
            % Expander 
            t0 = clock;
            [output_bp] = decoptSolver_optimized('UserDef', Phi.A, yA, param, 'AT', Phi.At,'x0', x0A, 'Prox', proxOpers,'NX', n^2); 
            time(1, i, j, l) = etime(clock, t0);          
            error(1, i, j, l) = norm(output_bp.auxi.xb - x_star);
            x_hat(1, i, j, l, :) = output_bp.auxi.xb;
                        
            % Gaussian
            t0 = clock;
            [output_bp] = decoptSolver_optimized('UserDef', Psi.B, yB, param, 'AT', Psi.Bt,'x0', x0B, 'Prox', proxOpers,'NX', n^2); 
            time(2, i, j, l) = etime(clock, t0);          
            error(2, i, j, l) = norm(output_bp.auxi.xb - x_star);
            x_hat(2, i, j, l, :) = output_bp.auxi.xb;
            
            %% l2,1-norm stuff
            group_prox    = @(x, gamma) shrink_group(x, gamma,0, groups, GG) ;
            group_norm    = @(x) sum(sqrt(GG*(abs(x).^2)));

            proxOpers{1} = @(x, gamma, varargin) group_prox(x, gamma);
            proxOpers{2} = @(x, gamma, varargin) projL2norm(x, 1e-12);

            proxOpers{3} = @(x, varargin) group_norm(x);
            proxOpers{4} = @(x, varargin) (0);
            
            % Expander 
            t0 = clock;
            [output_gbp] = decoptSolver_optimized('UserDef', Phi.A, yA, param, 'AT', Phi.At,'x0', x0A, 'Prox', proxOpers,'NX', n^2); 
            time(3, i, j, l) = etime(clock, t0);          
            error(3, i, j, l) = norm(output_gbp.auxi.xb - x_star);
            x_hat(3, i, j, l, :) = output_gbp.auxi.xb;
            
            % Gaussian
            t0 = clock;
            [output_gbp] = decoptSolver_optimized('UserDef', Psi.B, yB, param, 'AT', Psi.Bt,'x0', x0B, 'Prox', proxOpers,'NX', n^2); 
            time(4, i, j, l) = etime(clock, t0);          
            error(4, i, j, l) = norm(output_gbp.auxi.xb - x_star);
            x_hat(4, i, j, l, :) = output_gbp.auxi.xb;
        end
    end
end

save Image_Processing.mat time error x_hat time_A gs ms n