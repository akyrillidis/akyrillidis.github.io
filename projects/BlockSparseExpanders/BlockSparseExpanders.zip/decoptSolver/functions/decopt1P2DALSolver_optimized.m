% FUNCTION: [xsol, output] = decopt1P2DALSolver(Aopr, ATopr, b, ...
%                            proxOpers, lbx, ubx, x0, normAtA, param, ...
%                            opts, varargin)
%
% PURPOSE: An implementation of the decomposition algorithm for solving the
%          convex problem of the form:
%
%                       minimize_{x, r} f(x) + p(r)
%                       s.t.  A*x - r = b,
%
%          where f and p are two convex functions whose proximal operator
%          can be efficiently computed.
%
% ALGORITHM VARIANT:  One Primal Step and Two Dual Steps (1P2D) using
%                     Augmented Lagrangian smoothing technique.
%
% INFORMATION:
%    By Quoc Tran-Dinh, Laboratory for Informations and Inference Systems
%       (LIONS), EPFL, Lausanne, Switzerland.
%    Joint work with Volkan Cevher.
%    Date: 14.03.2014
%    Last modified: 23.04.2014.
%    Contact: quoc.trandinh@epfl.ch
%   
function output = decopt1P2DALSolver_optimized(Aopr, ATopr, b, proxOpers, ...
                          lbx, ubx, x0, normAtA, W, param, opts, varargin)
    
time_start = tic;
                      
% Initialize the parameters tau, gamma and beta.
output.auxi.tau        = 0.5*(sqrt(5) - 1);
output.auxi.gamma      = min(2*max(0.1/normAtA, opts.lbGamma), 1.0);  % default: 1e-6
if ~isempty(opts.gamma0), output.auxi.gamma = opts.gamma0; end
output.auxi.beta       = output.auxi.tau^2/(output.auxi.gamma*(1 - output.auxi.tau));

% The Lipschitz constant of the dual function.
Lips       = normAtA;
mx         = length(b);
max_nrm_b1 = max(norm(b(:), 2), 1);

% The proximal operators.
fxProxOper = proxOpers{1};
prProxOper = proxOpers{2};
fxProxEval = proxOpers{3};
prProxEval = proxOpers{4};

% Generate the center points.
y_cen      = zeros(mx, 1);
r0         = -b;
output.cntA       = 0;
output.cntAt      = 0;
output.stopCrt    = 0;

% Compute the primal starting point xb.
[output.auxi.xb, output.auxi.rb, outb] = decoptCvxProbSolver_optimized(Aopr, ATopr, b, y_cen, ...
                 output.auxi.gamma, Lips, x0, r0, lbx, ubx, fxProxOper, ...
                 prProxOper, W, param, varargin{:});

clear x0 r0 y_cen 
             
output.auxi.xs         = output.auxi.xb;
output.auxi.rs         = output.auxi.rb;
output.auxi.subiter    = outb.iter;
output.cntA       = output.cntA  + outb.cntA;
output.cntAt      = output.cntAt + outb.cntAt;


% Compute the dual starting point yb.
output.auxi.Axb        = Aopr(output.auxi.xb);
output.cntA       = output.cntA + 1;
output.auxi.Axs        = output.auxi.Axb;
frstFeas   = output.auxi.Axb - output.auxi.rb - b;
output.auxi.yb         = (1/output.auxi.beta)*frstFeas;



beginning=1;                 
if param.resume==1
   load(param.fsave);
   beginning        = output.iter+1; % or +1
end

    
% The main loop.
for iter = beginning:param.MaxIters

    % STEP 1: Update the dual variable yh.
    frstFeas   = output.auxi.Axb - output.auxi.rb - b;
    ys         = (1/output.auxi.beta)*frstFeas;
    yh         = (1 - output.auxi.tau)*output.auxi.yb + output.auxi.tau*ys;

    % STEP 2:  Compute the primal variable xs.
    [xs_next, rs_next, outs] = decoptCvxProbSolver_optimized(Aopr, ATopr, b, ...
                               yh, output.auxi.gamma, Lips, output.auxi.xb, output.auxi.rb, lbx, ubx, ...
                               fxProxOper, prProxOper, W, param, varargin{:});
    output.auxi.subiter    = output.auxi.subiter + outs.iter;  
    output.cntA       = output.cntA    + outs.cntA;
    output.cntAt      = output.cntAt   + outs.cntAt;

    % STEP 4: Update the primal variable xb and the residual rb.
    xb_next    = (1 - output.auxi.tau)*output.auxi.xb + output.auxi.tau*xs_next;
    rb_next    = (1 - output.auxi.tau)*output.auxi.rb + output.auxi.tau*rs_next;

    % STEP 5: Update the dual variable yb.
    Axs_next   = Aopr(xs_next);
    output.cntA= output.cntA + 1;
    sndFeas    = Axs_next - rs_next - b;
    yb_next    = yh + output.auxi.gamma*sndFeas;
    clear yh

    % STEP 6: Computing the primal/dual feasibility and solution change.
    abs_pfeas  = norm(frstFeas(:), 2); clear frstFeas
    abs_dfeas  = norm(Axs_next(:) - output.auxi.Axs(:), 2);
    abs_schg   = norm([xb_next(:) - output.auxi.xb(:); rb_next(:) - output.auxi.rb(:)], 2);
    output.rel_pfeas  = abs_pfeas/max_nrm_b1;
    output.rel_dfeas  = abs_dfeas/max(norm(output.auxi.Axs(:), 2), 1);
    output.rel_schg   = abs_schg/max(1, norm([output.auxi.xb(:); output.auxi.rb(:)], 2));

    % STEP 7: Update the smoothness parameter beta.
    output.auxi.beta       = (1 - output.auxi.tau)*output.auxi.beta;

    % STEP 8: Update the smoothness parameter gamma.
    decoptParamUpdate_optimized();

    % STEP 9: Update the step size parameter tau.
    output.auxi.omeg       = gamma_next/output.auxi.gamma*output.auxi.tau^2;
    output.auxi.tau        = 0.5*(sqrt(output.auxi.omeg^2 + 4*output.auxi.omeg) - output.auxi.omeg);
    output.auxi.gamma      = gamma_next;

     % STEP 3: Evaluate the objective value.
    if param.isFxEval
        output.fx_val = decoptFxEval(xb_next, rb_next, fxProxEval, prProxEval, ...
                 output.auxi.xs, output.auxi.rs, varargin{:});
              % THIS IS TO COMPARE THE RMSE ERROR:
      % x1 corresponds to the vector part whose TV norm is considered in the mixtured model as the image
        if isfield(param,'f')
            output.rmse(iter) = RMSE(reshape(output.auxi.xb(1:numel(param.f)),size(param.f)), param.f);
        end
        output.time_iter(iter) = toc(time_start);
        if numel(proxOpers) == 5
            output.hist.proxOpers_5(iter) = proxOpers{5}(xb_next);
        end
    end
    
    % STEP 10: Print the iterations and save the history.
    decoptPrintIters_optimized();
    decoptSaveHistory_optimized();

   % STEP 12: Assign to the next iteration.
    output.auxi.xb    = xb_next; clear xb_next
    output.auxi.rb    = rb_next; clear rb_next
    output.auxi.yb    = yb_next; clear yb_next
    output.auxi.xs    = xs_next; clear xs_next
    output.auxi.rs    = rs_next; clear rs_next
    output.auxi.Axs   = Axs_next; clear Axs_next
    output.auxi.Axb   = (1.0 - output.auxi.tau)*output.auxi.Axb + output.auxi.tau*output.auxi.Axs;
    
%     if mod(iter,5) == 0
%         output.iter=iter; 
%         save(param.fsave,'output','-append');
%     end

%current_iter=iter
    

    % STEP 11: Check the stopping criterion.
    if output.rel_pfeas <= param.RelTolFeas && output.rel_schg <= param.RelTolX % &&   fx_val-fx_val_previous?? <=  param.RelTolFun % LAST PART IS ADDED but then commented BY BARAN, but it won't change anything.
        output.stopCrt = 1;
        decoptTermination_optimized();
        break;
    end
    
%         if mod(iter,2) == 0
%             break;
%         end
%  
    
end

% Perform the final phase.
output.iter=iter; 
output.stopCrt   = 0;
decoptTermination_optimized();

%% Get the final solution.
%xsol             = xb_next; % No need to store this, just use
%output.auxi.xb as solution. After the change of order of Step-11 and 12,
%xb=xb_next after after stopping criterion is achieved. We can later on
%continue from this solution as well using param.resume=1 option. Without
%the change of order we would be repeating the last iteration...



% Get the final outputs.
%output.stopCrt   = stopCrt;
%output.iter      = iter;
%output.rel_pfeas = rel_pfeas;
%output.rel_dfeas = rel_dfeas;
%output.rel_schg  = rel_schg;
%output.fx_val    = output.auxi.fx_val;
%output.cntA      = cntA;
%output.cntAt     = cntAt;
%output.auxi.rb   = rb_next;
%output.auxi.yb   = yb_next;
%output.auxi.xs   = xs;
%output.auxi.rs   = rs;


% DECOPT v.1.0 by Quoc Tran-Dinh and Volkan Cevher.
% Copyright 2014 Laboratory for Information and Inference Systems (LIONS)
%                EPFL Lausanne, 1015-Lausanne, Switzerland.
% See the file LICENSE for full license information.