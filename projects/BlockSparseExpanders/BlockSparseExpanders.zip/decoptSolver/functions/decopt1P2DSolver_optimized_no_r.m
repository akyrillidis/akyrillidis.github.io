% FUNCTION: [fsol, output] = decopt1P2DSolver(Aopr, ATopr, b, ...
%                            proxOpers, lbx, ubx, x0, normAtA, W, ...
%                            param, opts, varargin)
%   
% PURPOSE: An implementation of the decomposition algorithm for solving the
%          convex problem of the form:
%
%                       minimize_{x} f(x)
%                       s.t.  A*x = b,
%
%          where f and p are two convex functions whose proximal operator
%          can be efficiently computed.
%
% ALGORITHM VARIANT:  One Primal Step and Two Dual Steps (1P2D) using
%                     Bregman distance smoothing technique.
%
% INFORMATION:
%    By Quoc Tran-Dinh, Laboratory for Informations and Inference Systems
%       (LIONS), EPFL, Lausanne, Switzerland.
%    Joint work with Volkan Cevher and Luca Baldassarre.
%    Date: 14.03.2014
%    Last modified: 13.02.2015.
%    Contact: quoc.trandinh@epfl.ch
%   
function [xsol, output] = decopt1P2DSolver_optimized_no_r(Aopr, ATopr, b, ...
                          proxOpers, lbx, ubx, x0, normAtA, ...
                          param, kickPars, varargin)

time_start = tic;
% This is the Lipschitz constant of the dual function g(y).
lipsG      = normAtA;

% Initialize the parameters tau, gamma and beta.
a        = 0.5*(1+sqrt(5));
tau      = 1/a;
gamma    = 2*sqrt(2*lipsG)/(param.MaxIters+1);
beta     = lipsG/gamma;

% Define f and its proximal operator
fxProxOpr  = proxOpers{1};
fxProxEval = proxOpers{3};

% Initialize the outputs.
output   = []; 
cntA     = 0;
cntAt    = 0; 
fx_val   = nan;
norm_b   = norm(b, 2);

% Define the center points.
igam  = 1.0/gamma;
xg    = zeros(size(x0));
xb    = fxProxOpr(xg, igam);
if ~isempty(lbx), xb = max(xb, lbx); end
if ~isempty(ubx), xb = min(xb, ubx); end

Axb      = Aopr(xb);
cntA     = cntA + 1;
frstFeas = Axb - b;
yb       = (1.0/beta)*frstFeas;

% The main loop of the algorithm.
for iter = 1:param.MaxIters
    
   % STEP 1: Evaluate the first dual variable ys.
   ybs      = (1.0/beta)*(Axb - b);

   % STEP 2: Compute the intermediate point yh.
   yh       = (1.0 - tau)*yb + tau*ybs;

   % STEP 3: Update gamma
% 	gamma = gamma;

   % STEP 4: Compute the primal solution xs.
   igam    = 1.0/gamma;
   xg        = - igam*ATopr(yh);
   xs_next   = fxProxOpr(xg, igam);
   if ~isempty(lbx), xs_next = max(xs_next, lbx); end
   if ~isempty(ubx), xs_next = min(xs_next, ubx); end

   % STEP 5: Update xb_next.
   xb_next   = (1 - tau)*xb + tau*xs_next;

   Axs_next  = Aopr(xs_next);
   cntA      = cntA + 1;
   Axb       = (1.0 - tau)*Axb + tau*Axs_next;

   % STEP 6: Update the dual variable.
   step      = gamma/lipsG;
   sndFeas   = Axs_next - b;
   yb_next   = yh + step*sndFeas;

   % STEP 8: Evaluate the primal and dual feasibility.
   abs_schg  = norm(xb_next(:) - xb(:), 2);
   abs_pfeas = norm(Axb(:) - b(:), 2);
   abs_dfeas = 0;
    
   rel_pfeas = abs_pfeas/max(1.0, norm_b);
   rel_dfeas = 0;
   rel_schg  = abs_schg/max(norm(xb, 2), 1.0);

   % STEP 9: Update the smoothness parameter beta.
   beta      = (1 - tau)*beta;

   % STEP 10: Evaluate the objective value.
    if param.isFxEval
        fx_val = fxProxEval(xb_next, x0, varargin{:});
         % THIS IS TO COMPARE THE RMSE ERROR:
         if isfield(param,'f')
           output.rmse(iter) = RMSE(reshape(xb_next(1:numel(param.f)),size(param.f)), param.f);
         end
        output.time_iter(iter) = toc(time_start);
    end
    
    % STEP 10: Print out the iterations and save the history.
    decoptPrintIters();
    decoptSaveHistory();
    
    % STEP 11: Check the stopping criterion.
    if rel_pfeas <= param.RelTolFeas && rel_schg <= param.RelTolX
        stopCrt = 1;
        decoptTermination();
        break;
    end
    
    % STEP 12: Update the parameter tau.
    a     = 0.5*(1+sqrt(4*a^2+1));
    tau   = 1/a;
    
    % STEP 13: Assign to the next iteration.
    yb    = yb_next;
    xb    = xb_next;
end
% End of the main loop.

% Perform the final phase.
stopCrt   = 0;
decoptTermination();

% Get the final solution.
xsol             = xb_next;

% Get the final outputs.
output.stopCrt   = stopCrt;
output.iter      = iter;
output.rel_pfeas = rel_pfeas;
output.rel_dfeas = rel_dfeas;
output.rel_schg  = rel_schg;
output.fx_val    = fx_val;
output.cntA      = cntA;
output.cntAt     = cntAt;
output.auxi.yb   = yb_next;
output.auxi.xb   = xb;

% DECOPT v.1.0 by Quoc Tran-Dinh and Volkan Cevher.
% Copyright 2014 Laboratory for Information and Inference Systems (LIONS)
%                EPFL Lausanne, 1015-Lausanne, Switzerland.
% See the file LICENSE for full license information.