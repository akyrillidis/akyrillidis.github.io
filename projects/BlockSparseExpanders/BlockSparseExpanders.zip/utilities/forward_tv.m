function OUT = forward_tv(x, measurement_forward, No, Nx)

m = sqrt(Nx);
OUT = zeros(No + 2*Nx,1);
OUT(1:No) = measurement_forward(x(1:Nx));
OUT(No+1:end) = GradientIm(x(1:Nx), m) - x(Nx+1:end);