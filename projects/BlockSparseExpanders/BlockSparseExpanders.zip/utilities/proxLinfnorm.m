function out = proxLinfnorm(x, gamma)

%% out = proxLinfnorm(x, gamma)
% Computes the proximity operator of gamma*infinity_norm
% using Moreau's decomposition

out = x - gamma*projL1norm(x/gamma, 1);