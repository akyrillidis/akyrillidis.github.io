function OUT = prox_inf_norm_gradient(x, gamma, m)

x = reshape(x, [m, m, 2]);

OUT = zeros(m,m,2);

for i = 1:m
   for j = 1:m
      OUT(i,j,:) = proxLinfnorm(x(i,j,:), gamma);
   end
end

OUT = OUT(:);