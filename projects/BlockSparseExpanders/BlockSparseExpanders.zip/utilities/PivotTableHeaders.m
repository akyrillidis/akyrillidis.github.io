% Same as PivotTable, but with headers
function [tab] = PivotTableHeaders(db, val, dim1, dim2, ...
  range_dim1, range_dim2, action)

  % Action to summarise value, default=mean
  if (nargin < 7)
    action = @(x) mean(x);
  end

  % Range of second dimension, if not provided
  if (nargin < 6)
    range_dim2 = unique(db(:, dim2));
  end
  
  % Range of first dimension, if not provided
  if (nargin < 5)
    range_dim1 = unique(db(:, dim1));
  end
  
  % Number of different values per dimension
  l_dim1 = length(range_dim1);
  l_dim2 = length(range_dim2);
  
  % Build output
  tab = zeros(l_dim1 + 1, l_dim2 + 1);

  % Headers for the rows
  for (i = 1:l_dim1)
    tab(i+1, 1) = range_dim1(i);
  end
  
  % Headers for the cols
  for (j = 1:l_dim2)
    tab(1, j+1) = range_dim2(j);
  end

  % Complete the table
  tab(2:(l_dim1+1), 2:(l_dim2+1)) = PivotTable(db, val, ...
    dim1, dim2, range_dim1, range_dim2, action);

end
