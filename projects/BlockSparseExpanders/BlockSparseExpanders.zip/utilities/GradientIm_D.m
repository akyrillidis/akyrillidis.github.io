function OUT = GradientIm_D(u, m, D)

u = reshape(u,[m,m]);
OUT = zeros(m,m,2);
OUT(:,:,1) = D*u;
OUT(:,:,2) = u*D';
OUT = OUT(:);