function OUT = backward_tv(x, measurement_backward, No, Nx)

m = sqrt(Nx);
OUT = zeros(3*Nx,1);

OUT(1:Nx) = measurement_backward(x(1:No)) - DivergenceIm(x(No+1:end), m);
OUT(Nx+1:end) = - x(No+1:end);