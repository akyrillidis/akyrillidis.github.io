function OUT = parallel_mixture_regularizers_prox(x, gamma, params)

num_components = params.num_components;
xp   = cell(num_components,1);
prox = cell(num_components,1);
out = cell(num_components,1);

for i = 1:num_components
   xp{i}    = params.x{i}(x);
   prox{i}  = params.prox{i};
end


parfor i = 1:num_components
   out{i} = prox{i}(xp{i}, gamma);
end

OUT = cell2mat(out);

% proxOpers{1} = @(x, gamma, varargin) [prox_tv(x1(x),(alpha*gamma)); proxL1norm(x2(x), mu*gamma); hgl_prox_theirs(x3(x),beta*gamma) ; x4(x)/(1+gamma); x5(x)/(1+lambda*gamma)];