function w = l1_proj(v,z)

%DUCHI's algorithm for the projection on the ball ||v||_1 <= z
%
%"Efficient projections onto the l-1 ball for Learning in High Dimensions"
%Duchi, Shalev-Scwahrtz, Singer, Chandra, ICML 2008
%see pg. 3
if norm(v,1) <= z
    w = v;
else
    mu = sort(abs(v),'descend');

    sumcum = (cumsum(mu(:)) - z)./(1:numel(mu))';

    rho = find((mu(:) - sumcum) > 0,1,'last');
    
    if isempty(rho)
        keyboard
    end

    theta = sumcum(rho);
      
    w = max(abs(v) - theta,0);
    
    w = sign(v).*w;
end