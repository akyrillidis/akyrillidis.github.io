% Action: print to file the LaTeX code for a MATLAB table
% (created with PivotTable(Headers) for instance).
% Use fid=1 for printing to screen
% Parameters:
% tab - the table
% title - string with table's title
% col_labels - labels for the columns (replace 1st row)
% row_labels - labels for the rows (replace 1st col)
function MakeLaTeXTable(fid, tab, title, ...
  col_labels, row_labels)

  % Get tab's sizes
  [nrows ncols] = size(tab);
  
  % Flags for the labels
  flag_col = 0;
  flag_row = 0;
  
  if (nargin > 3) % There's a label for the cols
    flag_col = 1;
  end
  
  if (nargin > 4) % There's a label for the rows
    flag_row = 1;
  end
    
  % Begin the table:
  fprintf(fid, '\\begin{table}[ht]\n');
  fprintf(fid, '  \\centering\n');
  fprintf(fid, '  \\begin{tabular}{');
  
  for (i = 1:(ncols-1))
    fprintf(fid, 'r|');
  end
%   if (flag_row == 1)
%     fprintf(fid, 'r|');
%   end
  fprintf(fid, 'r}\n');
%   fprintf(fid, '\\hline\n');
  
  % Print cols' labels
  if (flag_col == 1)
    % Leave a space for the first col
    if (flag_row == 1)
      fprintf(fid, '   & ');
    end
    for (i = 1:(ncols-2))
      fprintf(fid, '%s & ', col_labels{i});
    end
    fprintf(fid, '%s ', col_labels{ncols-1});
    fprintf(fid, '\\\\\n  \\hline\n');
  end
  
  % Print data:
  for (i = 1:(nrows-flag_row))
    if (flag_row == 1)
      fprintf(fid, '    %s & ', row_labels{i});
    end
    for (j = 1:(ncols-1-flag_row))
      
      % Read number to print
      num = tab(i+flag_col, j+flag_row);
      
      % Number is an integer
      if (num == floor(num))
        
        if (num == 0)
          
          fprintf(fid, '- & ');
          
        else
        
          fprintf(fid, '%d & ', num);
          
        end
        
      else % num is a floating point
        
        fprintf(fid, '%5.5f & ', num);
        
      end
      
    end
%     if (flag_row == 1)
%       fprintf(fid, '%5.5f & ', tab(i+flag_col, ncols-1));
%     end

    % Last number to print
    num = tab(i+flag_col, ncols);
    
    % Number is an integer
    if (num == floor(num))
      
      if (num == 0)
        
        fprintf(fid, '- \\\\\n');
        
      else
      
        fprintf(fid, '%d \\\\\n', num);
        
      end
      
    else % Number is a floating point
      
      fprintf(fid, '%5.5f \\\\\n', num);
      
    end
%     fprintf(fid, '\\hline\n');
  end

  % End of the table:
  fprintf(fid, '  \\end{tabular}\n');
  fprintf(fid, '  \\caption{%s}\n', title);
  fprintf(fid, '\\end{table}\n');

end


% stringm = {'10' '15' '20' '25' '30' '40' '50'}
% strmeth = {'constr', 'GLasso', ' Lasso', 'consGL'}
% MakeLaTeXTable(tab, 'firsttable', stringm, strmeth)