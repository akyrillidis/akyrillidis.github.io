function val = hgl_norm(x, tree, param, permutation_to)

param.lambda = 0;
if nargin < 4
   try
      val = mexTreeNorm(x, tree, param);
   catch
      param.lambda = 0;
      [a, val] = mexProximalTree(x, tree, param);
   end
else
   try
      val = mexTreeNorm(x(permutation_to), tree, param);
   catch
      param.lambda = 0;
      [a, val] = mexProximalTree(x(permutation_to), tree, param);
   end
end

