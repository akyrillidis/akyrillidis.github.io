function [ind]= dfs_ind(depth, D)
% form jump vector
jump=zeros(1,D^depth);

ind=zeros(1,(D^(depth+1)-1)/(D-1));
ind(1)=0; %root
count_nodes=2;
for i=1:depth %go over all the levels
    count=0;
    jump(D^i:D^i:D^depth)= jump(D^i:D^i:D^depth)+1;
    last_ind=i; %First index in level i, is i (we start counting from 0 for the root)
    for j=1:D^(i-1)
        new_ind= last_ind+ (0:(D-1))*(D^(depth-i+1)-1)/(D-1); %indices for children of same parent on level i, increments equal to number of nodes
        %in children tree.
        ind(count_nodes:count_nodes+D-1)=new_ind;
        count_nodes=count_nodes+D;
        count=count+D;
        last_ind=new_ind(D)+ (D^(depth-i+1)-1)/(D-1) + jump(count); %For the next nodes in same level but the next parent i need to jump one index.
    end
end

end

