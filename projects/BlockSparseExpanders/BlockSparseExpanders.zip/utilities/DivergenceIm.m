function divp = DivergenceIm(x, m)

x = reshape(x,[m,m,2]);
p1 = x(:,:,1);
p2 = x(:,:,2);

z = p2(:,2:end-1) - p2(:,1:end-2);
v = [p2(:,1) z -p2(:,end)];

z = p1(2:end-1, :) - p1(1:end-2,:);
u = [p1(1,:); z;  -p1(end,:)];

divp = v + u;

divp = divp(:);