% Summarise the results in a single report

% Title:
exp_title = 'Toy experiment (MNI, rnd perm first pos)';

% Execution's name
ex_name = '100422_Notes';

% Description file
fid = fopen('./Notes/Exp52.tex', 'r');

% Load description
description = fscanf(fid, '%c');
fclose(fid);

% Parameters:
param_summary = sprintf('$\\epsilon = %e$, $d = %d$, max num of iterations $=%d$, runs $=%d$', ...
  epsilon, d, iterations, runs);

fn = sprintf('./Notes/%s.tex', ex_name);
fdvi = sprintf('./Notes/%s.dvi', ex_name);
fps = sprintf('./Notes/%s.ps', ex_name);
fpdf = sprintf('./Notes/%s.pdf', ex_name);

fin = './Notes/_intro.txt';
ftabs = './Notes/tabs.tex';
fout = './Notes/_outro.txt';
fid = fopen(ftabs, 'wt');

% Strings with methods' names
str_meth = {'Lasso', 'Constr', 'Conlin', 'GLlin', 'Constr23', 'Constr48', 'Constr8', 'Conslash'...
  'Lasso (sd)', ...
  'Conset (sd)', 'Conlin (sd)', 'GLlin (sd)', 'Constr23 (sd)', 'Constr48 (sd)', 'Constr8 (sd)', 'Conslash(sd)'};
str_patt = {'S1'};

fprintf(fid, '\\textbf{%s}\n\n', exp_title);
fprintf(fid, '%s', description);
fprintf(fid, '\n\n\\textbf{Parameters}\n\n');
fprintf(fid, '%s', param_summary);

fprintf(fid, '\\clearpage\n');

ru = '';
for (i = 1:runs) ru{i} = num2str(i); end

% Legend
leg = {'Lasso', 'Conset', 'Conlin', 'GLlin', 'Constr23', 'Constr48', 'Constr8', 'Conslash'};

% For each pattern, print a picture
fprintf(fid, '\\begin{center}\n\\textbf{Pattern: %s}\n\\end{center}\n', str_patt{1});
MeanSDPlot(res, c_mse, c_samplesize, c_method, leg, str_patt{1});
f_fn = sprintf('figE52.eps');
exportfig(gcf, sprintf('./Notes/%s', f_fn), 'color', 'cmyk');
fprintf(fid, '\\includegraphics[width=75mm]{%s}\n\n', f_fn);



% for (k = 1:lsp) 
%   if ((k > 1) && (mod(k, 2) == 1))
%     fprintf(fid, '\\clearpage\n');
%   end
%   fprintf(fid, '\\begin{center}\n\\textbf{Pattern: %s}\n\\end{center}\n', str_patt{k});
%   MeanSDPlot(res(find(res(:, c_pattern) == k), :), c_mse, ...
%     c_samplesize, c_method, leg, str_patt{k});
%   f_fn = sprintf('fig%s.eps', str_patt{k});
%   exportfig(gcf, sprintf('./Notes/%s', f_fn), 'color', 'cmyk');
%   fprintf(fid, '\\includegraphics[width=75mm]{%s}\n\n', f_fn);
%   
% end
% 
% % For each sample set size
% for (k = 1:lm)
% 
%   if (k > 1)
%     fprintf(fid, '\\clearpage\n');
%   end
%   fprintf(fid, '\\textbf{Sample size = %d}\n', m(k));
%     
%   % Filter on sample size
%   filter = res(:, 8) == m(k);
%   
%   % Model error
%   title = 'Model error (mean and standard deviation)';
%   % Tab for the mean
%   tab_mean = PivotTableHeaders(res(filter, :), ...
%     c_mse, c_method, c_pattern, 1:l_methods, 1:lsp);
%   % Tab for the sd (with no first line but with row labels)
%   tab_sd = [(1:l_methods)', PivotTable(res(filter, :), ...
%     c_mse, c_method, c_pattern, 1:l_methods, 1:lsp, @(x) var(x)^.5)];
%   MakeLaTeXTable(fid, [tab_mean; tab_sd], title, str_patt, str_meth);
% 
%   % Number of iterations
%   title = 'Number of iterations (mean and sd)';
%   % Tab for the mean
%   tab_mean = PivotTableHeaders(res(filter, :), ...
%     c_iter, c_method, c_pattern, 1:l_methods, 1:lsp);
%   % Tab for the sd (with no first line but with row labels)
%   tab_sd = [(1:l_methods)', PivotTable(res(filter, :), ...
%     c_iter, c_method, c_pattern, 1:l_methods, 1:lsp, @(x) var(x)^.5)];
%   MakeLaTeXTable(fid, [tab_mean; tab_sd], title, str_patt, str_meth);
%   
%   % Number of seconds
%   title = 'Time in seconds (total)';
%   tab = PivotTableHeaders(res(filter, :), ...
%     c_toc, c_method, c_pattern, 1:l_methods, 1:lsp, @(x) sum(x));
%   MakeLaTeXTable(fid, tab, title, str_patt, str_meth);
%   
% %   % Best performer
% %   title = 'Best performer';
% %   filter = best(:, 3) == m(k);
% % %   tab = PivotTableHeaders(best(filter, :), 5, 1, 4, 1:runs, 1:lsp);
% %   tab = PivotTable(best(filter, :), 5, 1, 4);
% %   
% %   alg = zeros(l_methods+1, lsp+1);
% %   for (method = 1:l_methods)
% %     for (sp = 1:lsp)
% % alg(method+1, sp+1) = sum(tab(:, sp) == method);
% %     end
% %   end
% %   
% %   MakeLaTeXTable(fid, alg, title, str_patt, str_meth);
%   
% end

fclose(fid);

% Create the full tex file
cmd = sprintf('cat %s %s %s > %s', fin, ftabs, fout, fn);
system(cmd);

% Compile it
cd('Notes');
cmd = sprintf('latex %s.tex', ex_name);
system(cmd);
cd('..');

cmd = sprintf('dvips %s -o %s', fdvi, fps);
system(cmd);

cmd = sprintf('ps2pdf %s %s', fps, fpdf);
system(cmd);

cmd = sprintf('cp %s ~/Desktop/', fpdf);
system(cmd);