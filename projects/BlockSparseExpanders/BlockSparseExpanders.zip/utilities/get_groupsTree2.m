% Input is the tree a struct that proximal tree takes but with an invalid
% indexing
% n is the number of variables
% The assumption here is that we have the groups are the hierarchical
% groups which corresponds to each node and all its descendants.


function [permutation_to,permutation_from, tree]= get_groupsTree2(treeIn,n)

%the indices in permutations are for matlab (i.e., start at 1)
permutation_to=zeros(1,n); 
permutation_from=zeros(1,n);
tree.N_own_variables = int32(ones(1,n));
tree.own_variables   = int32((1:n)-1);
tree.groups          = treeIn.groups;
treeIn.own_variables=treeIn.own_variables(:);
% Do DFS
myStack=[1]; %push root
count=1;
while ~isempty(myStack)
    current_node=myStack(length(myStack));
    myStack=myStack(1:length(myStack)-1); %pop current_node
    
    permutation_to(count)=current_node;
    permutation_from(current_node)=count;
    
    current_grp=find(treeIn.own_variables==current_node-1);
    myStack=[myStack, treeIn.own_variables(logical(treeIn.groups(:,current_grp)))'+1]; %push children of current_node
    count=count+1;
end


for i=1:n
   tree.own_variables(i)=permutation_from(treeIn.own_variables(i)+1)-1;
end

