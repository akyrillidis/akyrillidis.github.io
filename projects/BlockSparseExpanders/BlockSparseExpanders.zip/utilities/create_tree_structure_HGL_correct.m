function [tree, permutation_to, permutation_from] = create_tree_structure_HGL_correct(m)

N = m^2;
D = 4;
n_subtree = (m^2-1)/3;
depth = log(n_subtree*(D-1)+1)/log(D) - 1;

tree.eta_g = ones(N,1);
tree.N_own_variables = int32(ones(N,1));
tree.w_var = ones(N,1);
[ind_H, ind_V, ind_D] = get_subtrees(m);
%change indexing from (row,col) to linear index
ind_H = sub2ind([m,m],ind_H(:,1), ind_H(:,2)); 
ind_V = sub2ind([m,m],ind_V(:,1), ind_V(:,2));
ind_D = sub2ind([m,m],ind_D(:,1), ind_D(:,2));
tree.own_variables = int32([1; ind_H; ind_V; ind_D])-1;

permutation_to=zeros(1,N); 
permutation_from=zeros(1,N);

permutation_to(1)=1;
permutation_from(1)=1;

i = [2; 2+n_subtree; 2+2*n_subtree];
j = [1; 1; 1];
%%
i_dfs=[2; 2+n_subtree; 2+2*n_subtree];
permutation_to(i_dfs)=tree.own_variables(i)'+1;
permutation_from(tree.own_variables(i)+1)=i_dfs;
%%
i_new=(3:n_subtree+1)';
i = [i; i_new];
jt = 2:(n_subtree+1-4^depth);
jt = repmat(jt,4,1);
jt = jt(:);
j = [j; jt];

i_dfs = 2 + dfs_ind(depth,4);
i_dfs = i_dfs(2:length(i_dfs)); %drop the first index since we already accounted for the root
permutation_to(i_dfs)=tree.own_variables(i_new)'+1;
permutation_from(tree.own_variables(i_new)+1)=i_dfs;

i_new=(n_subtree+3:2*n_subtree+1)';
i = [i; i_new];
jt = n_subtree+2:2*n_subtree+1-4^depth;
jt = repmat(jt,4,1);
jt = jt(:);
j = [j; jt];

i_dfs=  2+n_subtree+ dfs_ind(depth,4);
i_dfs=i_dfs(2:length(i_dfs)); %drop the first index since we already accounted for the root
permutation_to(i_dfs)=tree.own_variables(i_new)'+1;
permutation_from(tree.own_variables(i_new)+1)=i_dfs;

i_new=(2*n_subtree+3:3*n_subtree+1)';
i = [i; i_new];
jt = 2*n_subtree+2:3*n_subtree+1-4^depth;
jt = repmat(jt,4,1);
jt = jt(:);
j = [j; jt];


i_dfs=  2+2*n_subtree+ dfs_ind(depth,4);
i_dfs=i_dfs(2:length(i_dfs)); %drop the first index since we already accounted for the root
permutation_to(i_dfs)=tree.own_variables(i_new)'+1;
permutation_from(tree.own_variables(i_new)+1)=i_dfs;

s = ones(numel(i),1);

tree.groups = sparse(i,j,s,n_subtree*3+1,n_subtree*3+1);

own_variables_new = int32(zeros(N,1));
for i=1:N
   own_variables_new(i)=permutation_from(tree.own_variables(i)+1)-1;
end
tree.own_variables=own_variables_new';