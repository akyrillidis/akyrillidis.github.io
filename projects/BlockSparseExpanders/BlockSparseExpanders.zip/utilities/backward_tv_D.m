function OUT = backward_tv_D(x, measurement_backward, No, Nx,D)

m = sqrt(Nx);
OUT = zeros(3*Nx,1);
OUT(1:Nx) = measurement_backward(x(1:No)) + DivergenceIm_D(x(No+1:end), m, D);
OUT(Nx+1:end) = - x(No+1:end);