function region = get_wavelet_regions(m)

[ind_H, ind_V, ind_D] = get_subtrees(m);
levels = log2(m);
ind_end = 0;
region = cell(levels,1);
for k = 1:levels
   ind_start = ind_end + 1;
   ind_end   = ind_start + 4^(k-1)-1;
   ind       = ind_start:ind_end;
   region{k} = [sub2ind([m,m],ind_H(ind,1),ind_H(ind,2)); sub2ind([m,m],ind_V(ind,1),ind_V(ind,2)); sub2ind([m,m],ind_D(ind,1),ind_D(ind,2))];
end
