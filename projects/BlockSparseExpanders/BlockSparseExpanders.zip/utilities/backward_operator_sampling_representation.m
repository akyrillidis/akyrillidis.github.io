function OUT = backward_operator_sampling_representation(x, representation_operator, KT_opr, No)

OUT = KT_opr(x(1:No)) + representation_operator(x(No+1:end));
OUT = [OUT; -x(No+1:end)];