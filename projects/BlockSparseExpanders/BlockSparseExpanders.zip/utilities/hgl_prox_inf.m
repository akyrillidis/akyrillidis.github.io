function out = hgl_prox_inf(x, t, tree, param, permutation_to, permutation_from)

param.lambda = param.lambda/t;
out = mexProximalTree(x(permutation_to), tree, param);
out = out(permutation_from);