function divp = DivergenceIm_D(x, m, D)

x = reshape(x,[m,m,2]);
divp = D'*x(:,:,1) + x(:,:,2)*D;
divp = divp(:);