function output=error_metric(f,I) % put varying number of arguments for the case 'clipped'

%% inputs
% f: original image
% I: reconstructed image

%% output
% structure that carries the informations indicated with different names

   m=size(f,1);
   N=m^2;

   output.l2_error = norm(I-f,'fro')/norm(f(:));
   output.psnr  = 20*log10(max(f(:))*sqrt(N)/norm(I - f,'fro'));
   
   % clipping
   I(I>255)=255;I(I<0)=0;
   
   output.l2_error_clipped = norm(I-f,'fro')/norm(f(:));
   output.psnr_clipped  = 20*log10(max(f(:))*sqrt(N)/norm(I - f,'fro'));


end
