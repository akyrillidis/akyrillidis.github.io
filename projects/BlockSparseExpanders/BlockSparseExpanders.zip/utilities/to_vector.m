function y = to_vector(x, ind)

y = x(ind);