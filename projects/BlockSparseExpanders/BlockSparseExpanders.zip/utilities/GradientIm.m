function [dux, duy] = GradientIm(u)
% function Du = GradientIm(u)
z = u(2:end, :) - u(1:end-1,:);
dux = [z;  zeros(1,size(z,2))];

z = u(:,2:end) - u(:,1:end-1);
duy = [z zeros(size(z,1),1)];

% Du = [dux(:), duy(:)];s
