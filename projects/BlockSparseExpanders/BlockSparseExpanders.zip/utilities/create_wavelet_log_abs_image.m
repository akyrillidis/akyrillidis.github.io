function I_out = create_wavelet_log_abs_image(I, fname, threshold)

if nargin < 3
   threshold = -70;
end

I_out = log(abs(I));
I_out(I_out < threshold) = threshold;
I_out = I_out - threshold;
I_out = I_out/max(I_out(:))*255;
I_out = uint8(I_out);
imwrite(I_out,fname);