%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%
%%%                ----------------------------------------- 
%%%                POISON IMAGE RECONSTRUCTION v.1.0. (2013)
%%%                ----------------------------------------- 
%%%
%%%    An implementation of the (Path-Following) Proximal Gradient/Newton 
%%%    algorithms for solving Poisson image reconstruction problems.
%%%
%%% INFORMATION:
%%%    By Quoc Tran Dinh, Laboratory for Informations and Inference Systems,
%%%       EPFL, Lausanne, Switzerland.
%%%    Joint work with Volkan Cevher and Anastasios Kyrillidis.
%%%    Date: 22.05.2013.
%%%    Last modified: 22.05.2013.
%%%    Contact: quoc.trandinh@epfl.ch, volkan.cevher@epfl.ch
%%% 
%%% FUNCTION: tv_out = TVnormEval(X, opts)
%%% PURPOSE:  Compute the TV-norm operator.
%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function tv_out = TVnormEval(X, opts)

[m, n] = size(X);
P{1}   = X(1:m-1, :) - X(2:m, :);
P{2}   = X(:, 1:n-1) - X(:, 2:n);

% Compute the TV-norm for two cases: iso and l1.
if strcmpi(opts, 'iso')
    D           = zeros(m, n);
    D(1:m-1, :) = abs(P{1}).^2;
    D(:, 1:n-1) = D(:, 1:n-1) + abs(P{2}).^2;
    tv_out      = sum(sum(sqrt(D)));
else
    tv_out      = sum(sum(abs(P{1}))) + sum(sum(abs(P{2})));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% END OF THE IMPLEMENTATION.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

