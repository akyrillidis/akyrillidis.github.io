
addpath('rwt-master/bin');
%% LOAD IMAGE
m = 2^15;
f = imread('IMAGES/world2.png');
f = double(f);

wav = daubcqf(8);
% Maximum level
level = log2(m);
W = @(x) midwt(x,wav,level); 
WT = @(x) mdwt(x,wav,level);

f_wav = WT(f);
[a, b] = sort(abs(f_wav(:)),'descend');
M = 1105927;
f_wav_thresh = zeros(m,m);
f_wav_thresh(b(1:M)) = f_wav(b(1:M));
f_thresh = W(f_wav_thresh);

x_start = 6600;
x_end   = x_start + 2048;
y_start = 11520;
y_end   = y_start + 2048;
f_thresh_crop_1 = f_thresh(x_start:x_end, y_start:y_end);

x_start = 8700;
x_end   = 9724;
y_start = 1800;
y_end   = 2824;
f_thresh_crop_2 = f_thresh(x_start:x_end, y_start:y_end);

save('world_thresholded.mat','f_thresh','-v7.3');
save('world_thresholded_crops.mat','f_thresh_crop_1','f_thresh_crop_2');

