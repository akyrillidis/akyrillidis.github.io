function approx = bestK_proj(x,K)

[~, idx] = sort(abs(x(:)),'Descend');
approx = zeros(size(x));
approx(idx(1:K)) = x(idx(1:K));
