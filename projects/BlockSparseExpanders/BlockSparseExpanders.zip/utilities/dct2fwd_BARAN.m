function y = dct2fwd_BARAN(x, ind)


temp = dct2(x);
y = zeros(size(x));
y(ind) = temp(ind);
