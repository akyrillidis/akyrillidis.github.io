function I_clipped = clipping(I)

I_clipped = I;
I_clipped(I>255) = 255;
I_clipped(I<0) = 0;
I_clipped = uint8(I_clipped);