function y = dct2adj_BARAN(x, ind, N)


y = zeros([N N]);
y(ind) = x(ind);
y = idct2(y);
