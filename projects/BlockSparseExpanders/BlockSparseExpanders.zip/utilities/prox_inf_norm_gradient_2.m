function OUT = prox_inf_norm_gradient_2(x, gamma, m)

x = reshape(x, [m, m, 2]);

% OUT = zeros(m,m,2);

% First compute the L1 projections
% compute l1 norms
xg = x/gamma;
l1_norms = sum(abs(xg),3);
mask = l1_norms < 1;
mu = sort(abs(xg),3, 'Descend');
sumcum = (cumsum(mu,3) - 1)./repmat(reshape(1:size(mu,3),[1,1,size(mu,3)]),[m,m]);

mask_ind = (mu - sumcum) > 0;
mask_ind_2(:,:,2) = mask_ind(:,:,2);
mask_ind_2(:,:,1) = false;

theta(mask_ind(:,:,2)) = sumcum(mask_ind_2);

mask_ind_2(:,:,1) = logical(max(mask_ind(:,:,1) - mask_ind(:,:,2),0));
mask_ind_2(:,:,2) = false;

theta(mask_ind_2(:,:,1)) = sumcum(mask_ind_2);

w = max(abs(xg) - repmat(reshape(theta,[m,m]),[1,1,2]),0);
w = sign(xg).*w;
w(mask) = xg(mask);
mask2(:,:,2) = mask;
w(mask2) = xg(mask2);

OUT = x - gamma*w;

OUT = OUT(:);