addpath('OPERATORS');
addpath('rwt-master/bin/');
addpath(genpath('decoptSolver'));
addpath('spams-matlab/build/');
addpath('utilities/');

m = 256;
N = m^2;
str_size = '0256';
KENYA = 1;
%% REPRESENTATION
% WAVELET
% define the function handles that compute
% the products by W (inverse DWT) and W' (DWT)
wav      = daubcqf(8);
level    = log2(m); % Maximum level
W        = @(x) midwt(x,wav,level);
WT       = @(x) mdwt(x,wav,level);

representation_operator = @(x) reshape(W(reshape(x,[m,m])),[N,1]);
representation_operator_trans = @(x) reshape(WT(reshape(x,[m,m])),[N,1]);

%% LOAD IMAGES
if ~KENYA
   image{1} = sprintf('berlin_%s.png',str_size);
   image{2} = sprintf('earth_%s.png',str_size);
   image{3} = 'woman.jpg';
   image{4} = 'siddhartha.jpg';
   image{5} = 'epfl_campus.jpg';
   image{6} = 'mountains.jpg';
   image{7} = 'house.png';

   for k = 1:numel(image)
       f = imread(['IMAGES/',image{k}]);
       if numel(size(f)) == 3
           f = rgb2gray(f);
       end
       f = imresize(f,[m, m]);
       f = double(f);
       x(k,:) = representation_operator_trans(f);
   end
end
%%

if KENYA
   a = dir('IMAGES_KENYA/');
   cont = 0;
   for k = 1:numel(a)
      if ~isempty(strfind(a(k).name,'tif'))
         cont = cont + 1;
         I = imread(['IMAGES_KENYA/',a(k).name]);
         I = I(1:m,1:m);
         imwrite(I,['IMAGES_KENYA/',a(k).name]);
         I = double(I);
         I_w = representation_operator_trans(I);
         xs(:,cont) = sort(abs(I_w),'descend');
      end
   end
end

%%
median_coeff = median(xs,2);
max_coeff = max(xs,[],2);
min_coeff = min(xs,[],2);
mean_coeff = mean(xs,2);
figure, loglog([median_coeff, mean_coeff, max_coeff, min_coeff],'linewidth',2)
legend('median','mean','max','min');
%%

xsr = repmat(xs(1,:),N,1)./xs;
figure, loglog(xsr);
ylim[1, 1e8]);
ylabel('$\lambda_i$','interpreter','latex','fontsize',24);
xlabel('sorted index','interpreter','latex','fontsize',24);

%%
[xs, inds] = sort(abs(x),2,'descend');
figure, loglog(xs');

xsr = repmat(xs(:,1),1,N)./xs;
figure, loglog(xsr');
figure, loglog(min(xsr))

weights = min(xsr);
weights = weights(inds);
%%
save(sprintf('tree_weights_%d.mat',m),'weights');