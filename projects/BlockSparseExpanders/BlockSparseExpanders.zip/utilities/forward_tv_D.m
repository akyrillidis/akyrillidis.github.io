function OUT = forward_tv_D(x, measurement_forward, No, Nx, D)

m = sqrt(Nx);
OUT = zeros(No + 2*Nx,1);
OUT(1:No) = measurement_forward(x(1:Nx));
OUT(No+1:end) = GradientIm_D(x(1:Nx), m, D) - x(Nx+1:end);