function tree = create_tree_structure_HGL(m)

% Create 2D wavelet tree structure to be used with mexProximalTree in the
% SPAMS toolbox.
%
% (c) Luca Baldassarre
% luca.baldassarre@epfl.ch
% Last updated: 18.11.2014

D = 4;
N = m^2;
n_subtree = (m^2-1)/3;
depth = log(n_subtree*(D-1)+1)/log(D) - 1;

tree.eta_g = ones(N,1);
tree.N_own_variables = int32(ones(N,1));

[ind_H, ind_V, ind_D] = get_subtrees(m);

ind_H = sub2ind([m,m],ind_H(:,1), ind_H(:,2));
ind_V = sub2ind([m,m],ind_V(:,1), ind_V(:,2));
ind_D = sub2ind([m,m],ind_D(:,1), ind_D(:,2));

tree.own_variables = int32([1; ind_H; ind_V; ind_D])-1;

i = [2; 2+n_subtree; 2+2*n_subtree];
j = [1; 1; 1];

i = [i; (3:n_subtree+1)'];
jt = 2:(n_subtree+1-4^depth);
jt = repmat(jt,4,1);
jt = jt(:);
j = [j; jt];

i = [i; (n_subtree+3:2*n_subtree+1)'];
jt = n_subtree+2:2*n_subtree+1-4^depth;
jt = repmat(jt,4,1);
jt = jt(:);
j = [j; jt];

i = [i; (2*n_subtree+3:3*n_subtree+1)'];
jt = 2*n_subtree+2:3*n_subtree+1-4^depth;
jt = repmat(jt,4,1);
jt = jt(:);
j = [j; jt];

s = ones(numel(i),1);

tree.groups = sparse(i,j,s,n_subtree*3+1,n_subtree*3+1);
tree.w_var = ones(N,1);

end

function [ind_H, ind_V, ind_D] = get_subtrees(m)

% number of levels
L = log2(m^2-1)/2;

n_subtree = (m^2-1)/3;
ind_H = zeros(n_subtree,2);
ind_V = zeros(n_subtree,2);
ind_D = zeros(n_subtree,2);

ind_H(1,:) = [1, 2];
ind_V(1,:) = [2, 1];
ind_D(1,:) = [2, 2];

cont = 1;
for ell = 1:L
   % Number of nodes
   N = 4^(ell-1);
   % Nodes indices
   ind_nodes = (1:N)+(4^(ell-1)-1)/3;
   for n = 1:N      
      temp = coeff_H_children(ind_H(ind_nodes(n),:));
      n_children = size(temp,1);
      ind_H(cont+1:cont+n_children,:) = temp;
      temp = coeff_H_children(ind_V(ind_nodes(n),:));
      ind_V(cont+1:cont+n_children,:) = temp;
      temp = coeff_H_children(ind_D(ind_nodes(n),:));
      ind_D(cont+1:cont+n_children,:) = temp;
      cont = cont + n_children;
   end
end

end

function ind = coeff_H_children(ind)

x = ind(1);
y = ind(2);

ax = 2*x-1;
ay = 2*y-1;
ind(1,:) = [ax, ay];
ind(2,:) = [ax, ay+1];
ind(3,:) = [ax+1, ay];
ind(4,:) = [ax+1, ay+1];

end