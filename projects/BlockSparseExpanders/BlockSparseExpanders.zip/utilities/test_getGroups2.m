m = 4;
N = m^2;
x = randn(m,m);
x = x(:);
lambda=1;
%% solve prox using cvx


G={1:16, [5 9 10 13 14],[2 3 4 7 8],[6 11 12 15 16],9,10,13,14,3,4,7,8,11,12,15,16};
w=[0.0680  0.2548  0.2240  0.6678  0.8444  0.3445  0.7805  0.6753  0.0067  0.6022  0.3868  0.9160  0.0012  0.4624   0.4243  0.4609];
w=w';

   cvx_begin
      cvx_precision best
      variable x_cvx_2(N);
      expression group_norm;
      group_norm = 0;
      for k = 1:N
          group_norm = group_norm + norm( x_cvx_2(G{k}),2);
      end
      minimize 0.5*pow_pos(norm(x -  x_cvx_2,2),2) + lambda*group_norm;
   cvx_end


   cvx_begin
      cvx_precision best
      variable x_cvx_inf(N);
      expression group_norm;
      group_norm = 0;
      for k = 1:N
          group_norm = group_norm + norm(x_cvx_inf(G{k}),Inf);
      end
      minimize 0.5*pow_pos(norm(x - x_cvx_inf,2),2) + lambda*group_norm;
   cvx_end

     cvx_begin
      cvx_precision best
      variable x_cvx_inf_w(N);
      expression group_norm;
      group_norm = 0;
      for k = 1:N
          group_norm = group_norm + norm(x_cvx_inf_w(G{k}).*w(G{k}),Inf);
      end
      minimize 0.5*pow_pos(norm(x - x_cvx_inf_w,2),2) + lambda*group_norm;
   cvx_end


%%

param_hgl_prox.verbose     = true;
param_hgl_prox.pos         = false;
param_hgl_prox.intercept   = false;
param_hgl_prox.num_threads = -1;
param_hgl_prox.lambda      = lambda;




%%  sorting done explicitly 

tree2.eta_g           = ones(1,16);
tree2.w_var           = ones(1,16);
tree2.N_own_variables = int32(ones(16,1));
tree2.own_variables   = int32(0:N-1)';
tree2.groups          = sparse(N,N);
tree2.groups([2, 7, 12], 1)        = 1;
tree2.groups([3, 4, 5, 6], 2)      = 1;
tree2.groups([8, 9, 10, 11], 7)    = 1;
tree2.groups([13, 14, 15, 16], 12) = 1;
tree2.groups(1,1) = 0;


permutation_to2 = [1, 5, 9, 10, 13, 14, 2, 3, 4, 7, 8, 6, 11, 12, 15, 16];
permutation_from2 = [1, 7, 8, 9, 2, 12, 10, 11, 3, 4, 13, 14, 5, 6, 15, 16];

param_hgl_prox.verbose     = true;
param_hgl_prox.pos         = false;
param_hgl_prox.intercept   = false;
param_hgl_prox.num_threads = -1;
param_hgl_prox.lambda      = 1;

param_hgl_prox.regul       = 'tree-linf';
xx_spams_inf = mexProximalTree(x(permutation_to2), tree2, param_hgl_prox);
xx_spams_inf_s= xx_spams_inf(permutation_from2);

param_hgl_prox.regul       = 'tree-l2';
xx_spams_2 = mexProximalTree(x(permutation_to2), tree2, param_hgl_prox);
xx_spams_2_s= xx_spams_2(permutation_from2);

%% Using get_groupsTree to do the sorting

[permutation_to,permutation_from, tree]= get_groupsTree2(tree2,16);

tree.eta_g           = ones(1,16);
tree.w_var           = ones(1,16);

param_hgl_prox.regul       = 'tree-linf';
x_spams_inf = mexProximalTree(x(permutation_to), tree, param_hgl_prox);
x_spams_inf_s= x_spams_inf(permutation_from);

param= param_hgl_prox;
param.lambda=0;
[proxinf,valinf]= mexProximalTree(x(permutation_to), tree, param);
HGLinf=mexTreeNorm(x(permutation_to),tree,param);

param_hgl_prox.regul       = 'tree-l2';
x_spams_2 = mexProximalTree(x(permutation_to), tree, param_hgl_prox);
x_spams_2_s= x_spams_2(permutation_from);
param= param_hgl_prox;
param.lambda=0;
[prox2,val2]= mexProximalTree(x(permutation_to), tree, param);
HGL2=mexTreeNorm(x(permutation_to),tree,param);
