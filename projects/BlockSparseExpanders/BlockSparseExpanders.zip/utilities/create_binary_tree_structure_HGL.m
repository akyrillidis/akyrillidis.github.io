function [tree, permutation_to, permutation_from] = create_binary_tree_structure_HGL(m)

D = 2;

tree.eta_g              = ones(m,1);
tree.N_own_variables    = int32(ones(m,1));
tree.w_var              = ones(m,1);
tree.own_variables      = int32(0:m-1);
tree.groups             = sparse(m,m);
depth                   = log2(m)-1;


permutation_to([1, dfs_ind(depth,D)+2]) = tree.own_variables+1;
permutation_from(tree.own_variables+1) = [1, dfs_ind(depth,D)+2];

for i = 2:m
    tree.groups(i,ceil(i/2)) = 1;
end

tree.groups = tree.groups(permutation_to, permutation_to);