function OUT = forward_operator_sampling_representation(x, representation_operator_trans, K_opr, Nx)

OUT = K_opr(x(1:Nx));
OUT = [OUT; representation_operator_trans(x(1:Nx)) - x(Nx+1:end)];