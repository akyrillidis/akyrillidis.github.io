addpath('OPERATORS');
addpath('rwt-master/bin/');
addpath(genpath('decoptSolver'));
addpath('spams-matlab/build/');
addpath('utilities/');

m = 256;
N = m^2;
str_size = '0256';
KENYA = 1;
% Get wavelet regions
region = get_wavelet_regions(m);
%% REPRESENTATION
% WAVELET
% define the function handles that compute
% the products by W (inverse DWT) and W' (DWT)
wav      = daubcqf(8);
level    = log2(m); % Maximum level
W        = @(x) midwt(x,wav,level);
WT       = @(x) mdwt(x,wav,level);

representation_operator = @(x) reshape(W(reshape(x,[m,m])),[N,1]);
representation_operator_trans = @(x) reshape(WT(reshape(x,[m,m])),[N,1]);

%% LOAD IMAGES
if ~KENYA
   image{1} = sprintf('berlin_%s.png',str_size);
   image{2} = sprintf('earth_%s.png',str_size);
   image{3} = 'woman.jpg';
   image{4} = 'siddhartha.jpg';
   image{5} = 'epfl_campus.jpg';
   image{6} = 'mountains.jpg';
   image{7} = 'house.png';

   for k = 1:numel(image)
       f = imread(['IMAGES/',image{k}]);
       if numel(size(f)) == 3
           f = rgb2gray(f);
       end
       f = imresize(f,[m, m]);
       f = double(f);
       x(k,:) = representation_operator_trans(f);
   end
end
%%
for kregion = 1:numel(region)+1
   coeff_region{kregion} = [];
end

if KENYA
   a = dir('IMAGES_KENYA/');
   cont = 0;
   for k = 1:numel(a)
      if ~isempty(strfind(a(k).name,'tif'))
         cont = cont + 1;
         I = imread(['IMAGES_KENYA/',a(k).name]);
%          I = I(1:m,1:m);
%          imwrite(I,['IMAGES_KENYA/',a(k).name]);
         I = double(I);
         I_w = representation_operator_trans(I);
         coeff_region{1} = [coeff_region{1}; I_w(1)];
         for kregion = 1:numel(region)
            coeff_region{kregion+1} = [coeff_region{kregion+1}; I_w(region{kregion})];
         end
      end
   end
end

%% STATISTCS
for kregion = 1:numel(region)+1
   maxs(kregion)   = max(abs(coeff_region{kregion}));
   means(kregion) = mean(abs(coeff_region{kregion}));
   stds(kregion)  = std(abs(coeff_region{kregion}));
   mins(kregion)   = min(abs(coeff_region{kregion}));
   medians(kregion)   = median(abs(coeff_region{kregion}));
end

%%
% figure, semilogy(means,'o');
figure(222), semilogy([maxs', means', mins', medians'],'-x','linewidth',2,'markersize',10),
set(gca,'fontsize',16,'fontname','garamond');
legend({'maxs','means','mins','medians'},'fontsize',16','interpreter','latex')
xlabel('Wavelet level','interpreter','latex','fontsize',16);
ylabel('Absolute value','interpreter','latex','fontsize',16);
save_figure(222,20,20,'wav_coeffs_regions');
% semilogy(means+stds,'+');
% semilogy(means-stds,'+');

%% COMPUTE RATIOS AMONG MEANS
weights(1) = 1;
start = 1;
for kregion = 1:numel(region)
%    weights(start+1:start+numel(region{kregion})) = means(1)/means(kregion+1);
   weights(start+1:start+numel(region{kregion})) = maxs(1)/maxs(kregion+1);
   start = start+numel(region{kregion});
end
weights = weights';
save(sprintf('tree_weights_%d_region_max.mat',m),'weights');

%% BOX PLOT OF COEFFICIENTS
coeff_aggregated  = [];
labels            = [];
for kregion = 1:numel(region)+1
   coeff_aggregated = [coeff_aggregated; log(abs(coeff_region{kregion}))];
   labels = [labels; kregion*ones(numel(coeff_region{kregion}),1)];
end

%%
figure(111), boxplot(coeff_aggregated, labels);
xlabel('Wavelet level','interpreter','latex','fontsize',16);
ylabel('Logarithm of absolute value','interpreter','latex','fontsize',16);
save_figure(111,15,10, 'boxplot_wav_coeff');

%%
[xs, inds] = sort(abs(x),2,'descend');
figure, loglog(xs');

xsr = repmat(xs(:,1),1,N)./xs;
figure, loglog(xsr');
figure, loglog(min(xsr))

weights = min(xsr);
weights = weights(inds);
%%
save(sprintf('tree_weights_%d.mat',m),'weights');