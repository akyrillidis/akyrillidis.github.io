function OUT = prox_hgl_infinity(x, gamma, weights, C)

N = numel(x);
epsilon = sparse(N,N);
param.mode = 1;
level = log(N)/log(4);
N_leaves = 3*4^(level-1);

for k = 1:N_leaves
%    dummy = x - sum(epsilon(setdiff(1:N,k),:))';
%    epsilon(k,C(k,:)) = projL1norm(dummy(C(k,:)), gamma*weights(k));
   param.thrs = gamma*weights(k);
   epsilon(k,C(k,:)) = mexSparseProject(x(C(k,:)), param);
end

for k = N_leaves:N
   dummy = x - sum(epsilon(setdiff(1:N,k),:))';
%    epsilon(k,C(k,:)) = projL1norm(dummy(C(k,:)), gamma*weights(k));
   param.thrs = gamma*weights(k);
   epsilon(k,C(k,:)) = mexSparseProject(dummy(C(k,:)), param);
end

% for k = 1:N
%    dummy = x(C(k,:)) - sum(epsilon(setdiff(1:N,k),C(k,:)))';
%    epsilon(k,C(k,:)) = projL1norm(dummy, gamma*tree.eta_g(k));
% end

OUT = x - sum(epsilon)';