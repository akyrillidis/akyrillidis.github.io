function x = to_matrix(y, ind, size)

x = zeros(size);
x(ind) = y;