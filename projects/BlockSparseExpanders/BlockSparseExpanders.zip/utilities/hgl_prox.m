function out = hgl_prox(x, t, tree, param)

param.lambda = param.lambda/t;
if param.lambda == 0
   out = x;
else
   out = mexProximalTree(x, tree, param);
end