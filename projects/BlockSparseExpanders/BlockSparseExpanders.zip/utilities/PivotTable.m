% From the database 'db' extract the mean of column 'val'
% for each combination of values of columns 'dim1' and 'dim2'.
% Optional parameters 'range_dim1' and 'range_dim2' limit
% values of the considered columns (otherwise, all values found
% in that cols will be considered). Optional parameter 'action'
% is a function to be performed instead of the mean. For
% instance @sum, @var, @(x) var(x)^.5, @(x) mean(x)*n, and so on.
function [tab] = PivotTable(db, val, dim1, dim2, ...
  range_dim1, range_dim2, action)

  % Action to summarise value, default=mean
  if (nargin < 7)
    action = @(x) mean(x);
  end

  % Range of second dimension, if not provided
  if (nargin < 6)
    range_dim2 = unique(db(:, dim2));
  end
  
  % Range of first dimension, if not provided
  if (nargin < 5)
    range_dim1 = unique(db(:, dim1));
  end
  
  % Number of different values per dimension
  l_dim1 = length(range_dim1);
  l_dim2 = length(range_dim2);
  
  % Build output
  tab = zeros(l_dim1, l_dim2);
  
  for (i = 1:l_dim1)

    % Filter for the first dimension
    f1 = db(:, dim1) == range_dim1(i);
      
    for (j = 1:l_dim2)
      
      % Filter for the second dimension
      f2 = db(:, dim2) == range_dim2(j);
      
      % Extract the value
      v = db(f1 & f2, val);
      
      tab(i, j) = action(v);
      
    end
  end

end
