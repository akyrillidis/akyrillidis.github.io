function sol = RMSE(M,F)

% M = abs(M(:));
% F = abs(F(:));

% M = double(M);
% F = double(F);
% [n, m, d] = size(F);

% D = abs( M - F ).^2;
% D = ( M - F ).^2;

% sol = sqrt(sum(D(:))/(n*m*d));

sol = norm(M(:)-F(:))/norm(F(:));