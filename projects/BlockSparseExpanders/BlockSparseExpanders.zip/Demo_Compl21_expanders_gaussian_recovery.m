clear
close all
clc

% Demo - comparison between l1-norm and l2,1-norm minimization, using
% expander matrices

% Add algorithms in path
addpath(genpath('decoptSolver'));
addpath('utilities/');

% Setup parameters
n = 1000;                               % Ambient dimension
M = 100;                                % Number of non-overlapping groups
k = 8;                                  % Group sparsity
g = floor(n/M);                         % Group size
s = k * g;                              % Plain sparsity
ms = k*g : 10 : 360;                    % Range of values for number of measurements
MC = 10;                                % Monte Carlo iterations

% Setup group structure
ind_i = repmat(1:M,[g, 1]);
ind_i = ind_i(:);
ind_j = 1:n;
values = ones(n,1);
GG = sparse(ind_i, ind_j, values, M, n);
groups = ind_i;

% Setup algorithm - general parameters
param.MaxIters = 1e3;
param.Verbosity = 2;
param.PrintStep = 25;
param.RelTolX = 1e-10;
param.RelTolFun = 1e-10;
param.RelTolFeas = 1e-10;
param.InnerRelTol = 1e-10;
param.saveHistMode = 4;
param.Algorithm = 3;
param.InnerMaxIters = 5;
param.adaptStepSize = 1;
param.resume = 0; % But it is important to back up before continueing...
param.fsave = 'test';
save(param.fsave);

% Pre-allocate error and time structures
error = zeros(2, numel(ms), MC);
time = zeros(2, numel(ms), MC);

% Main loop
for i = 1:numel(ms)
    m = ms(i);
    for j = 1:MC
        % Generate signal
        xstar = sparse(n, 1);
        ind = randperm(M);
        ind = ind(1:k);
        xstar(logical(sum(GG(ind,:)))) = randn(k * g, 1);
        xstar = xstar./norm(xstar);
                        
        group_prox    = @(x, gamma) shrink_group(x, gamma,0, groups, GG) ;
        group_norm    = @(x) sum(sqrt(GG*(abs(x).^2)));

        proxOpers{1} = @(x, gamma, varargin) group_prox(x, gamma);
        proxOpers{2} = @(x, gamma, varargin) projL2norm(x, 1e-12);

        proxOpers{3} = @(x, varargin) group_norm(x);
        proxOpers{4} = @(x, varargin) (0);

        % Generate expander matrix
        d = ceil(15 * log(k * M) / g);          % Degree from theory
        A = bin_mat(d, m, n);
        
        % Setup inline commands
        Phi.A = @(x) (1/d) * A * x;
        Phi.At = @(x) (1/d)* A' * x;
                
        % Measurements and init. point
        y = Phi.A(xstar);
        x0 = Phi.At(y);
        
        % Group basis pursuit with expanders
        t0 = clock;
        [output_gbp] = decoptSolver_optimized('UserDef', Phi.A, y, param, 'AT', Phi.At,'x0', x0, 'Prox', proxOpers,'NX',n); 
        time(1, i, j) = etime(clock, t0);          
        error(1, i, j) = norm(output_gbp.auxi.xb - xstar);
        
        % Generate Gaussian matrix
        A = (1/sqrt(m)) * randn(m, n);
        
        % Setup inline commands
        Phi.A = @(x) A * x;
        Phi.At = @(x) A' * x;
                
        % Measurements and init. point
        y = Phi.A(xstar);
        x0 = Phi.At(y);
        
        % Group basis pursuit with gaussian
        t0 = clock;
        [output_gbp] = decoptSolver_optimized('UserDef', Phi.A, y, param, 'AT', Phi.At,'x0', x0, 'Prox', proxOpers,'NX',n); 
        time(2, i, j) = etime(clock, t0);          
        error(2, i, j) = norm(output_gbp.auxi.xb - xstar);
    end;
end;

save Compl21_expanders_gaussian_recovery.mat
