function [x_hat, numiter] = one_ALPS(y, Phi, K, params)
% =========================================================================
%                  1-ALPS(2) algorithm - Beta Version
% =========================================================================
% Algebraic Pursuit (ALPS) algorithm with 1-memory acceleration. 
% 
% Detailed discussion on the algorithm can be found in 
% [1] "Recipes for Hard Thresholding Methods", written by Anastasios
% Kyrillidis and Volkan Cevher, CAMSAP, 2011.
% =========================================================================
% INPUT ARGUMENTS:
% y                         M x 1 undersampled measurement vector.
% Phi                       M x N regression matrix.
% K                         Sparsity of underlying vector x* or desired
%                           sparsity of solution.
% params                    Structure of parameters. These are:
%
%    tol,...                Early stopping tolerance. Default value: tol =
%                           1-e5.
%    ALPSiters,...          Maximum number of algorithm iterations. Default
%                           value: 300. 
% =========================================================================
% OUTPUT ARGUMENTS:
% x_hat                     N x 1 recovered K-sparse vector.
% numiter                   Number of iterations executed.
% =========================================================================
% 01/04/2011, by Anastasios Kyrillidis. anastasios.kyrillidis@epfl.ch, EPFL.
% =========================================================================
% This work was supported in part by the European Commission under Grant 
% MIRG-268398 and DARPA KeCoM program #11-DARPA-1055. VC also would like 
% to acknowledge Rice University for his Faculty Fellowship.
% =========================================================================

[M,N] = size(Phi);

%% Initialize transpose of measurement matrix

Phi_t = Phi';

%% Initialize to zero vector
x_cur = zeros(N,1);
y_cur = zeros(N,1);
Phi_x_cur = zeros(M,1);
Y_i = [];

%% Help variables
complementary_Yi = ones(N,1);

i = 1;
%% 1-ALPS(#)
while (i <= params.ALPSiters)
    x_prev = x_cur;        
    
    % Compute the residual
    if (i == 1)
        res = y;
        % Compute the derivative
        der = Phi_t*res;
    else
        res = y - Phi_x_cur - params.tau*Phi_diff;
        der = Phi_t*res;
    end;
    
    Phi_x_prev = Phi_x_cur;               
    
    % Determine S_i set via eq. (11) (change of variable from x_i to y_i)
    complementary_Yi(Y_i) = 0;
    [~, ind_der] = sort(abs(der).*complementary_Yi, 'descend');  
    complementary_Yi(Y_i) = 1;
    S_i = [Y_i; ind_der(1:K)];
        
    ider = der(S_i);
    Pder = Phi(:,S_i)*ider;
    mu_bar = ider'*ider/(Pder'*Pder);            
    b = y_cur(S_i) + (mu_bar)*ider;        

    % Hard-threshold b and compute X_{i+1}
    [~, ind_b] = sort(abs(b), 'descend');
    x_cur = zeros(N,1);
    x_cur(S_i(ind_b(1:K))) = b(ind_b(1:K));
    X_i = S_i(ind_b(1:K));

    % Calculate gradient of estimated vector x_cur
    Phi_x_cur = Phi(:,X_i)*x_cur(X_i);
    res = y - Phi_x_cur;
    der = Phi_t*res;
    ider = der(X_i);

    Pder = Phi(:,X_i)*ider;
    mu_bar = ider'*ider/(Pder'*Pder);
    x_cur(X_i) = x_cur(X_i) + mu_bar*ider;

    % tau = argmin ||u - Phi*y_{i+1}|| 
    %     = <res, Phi*(x_cur - x_prev)>/||Phi*(x_cur - x_prev)||^2        

    Phi_x_cur = Phi(:,X_i)*x_cur(X_i);
    res = y - Phi_x_cur;
    if (i == 1)
        Phi_diff = Phi_x_cur;
    else
        Phi_diff = Phi_x_cur - Phi_x_prev;
    end;
    params.tau = res'*Phi_diff/(Phi_diff'*Phi_diff);

    y_cur = x_cur + params.tau*(x_cur - x_prev);
    Y_i = find(ne(y_cur, 0));
    % Test stopping criterion
    if (i > 1) && (norm(x_cur - x_prev) < params.tol*norm(x_cur))
        break;
    end;
    i = i + 1;
end;

x_hat = x_cur;
numiter= i;
