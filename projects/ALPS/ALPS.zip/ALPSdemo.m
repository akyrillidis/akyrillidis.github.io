% =========================================================================
%                   Algebraic Pursuit algorithms - Demo
% =========================================================================
% Algebraic Pursuit (ALPS) algorithms are accelerated hard thresholding methods 
% on sparse recovery of linear inverse systems. In particular, let
%             Phi : M x N real matrix (M < N)
%             x*  : N x 1 K-sparse data vector
%             n   : N x 1 additive noise vector
% then, y = Phi x* + n is the undersampled M x 1 measurement vector. ALPS 
% solve the following minimization problem 
%          minimize ||y - Phi x||^2    subject to x is K-sparse vector. 
% 
% Detailed discussion on the algorithm can be found in 
% [1] "On Accelerated Hard Thresholding Methods for Sparse Approximation", written
% by Volkan Cevher, Technical Report, 2011.
% =========================================================================
% 01/04/2011, by Anastasios Kyrillidis. anastasios.kyrillidis@epfl.ch, EPFL.
% =========================================================================

clear all
close all
clc

load polytope.mat;
% Instructions: 0-ALPS(5) has params.mode = 5 and params.memory = 0 - for this case set params.useCG = 0 or 1, depending your needs.
%               1-ALPS(2) has params.mode = 2 and params.memory = 1.

% Comment:
% 0-ALPS(5) has better phase transition than 1-ALPS(2) but it is slower in
% high dimensions

% Oracle Sparsity: set oraclesparsity = 1 if you know the exact K
%                  set oraclesparsity = 0 to use Phase Transition to
%                  estimate K

oraclesparsity = 0;

addpath ALPS/;

% General parameters
N = 20000;                      % Size of sparse vector x
M = 5000;                       % Number of measurements
K = ceil(M*(0.25));             % Sparsity of  x*
sigma = 10^-4;                  % Additive noise variance
verbose = 1;                    % Print information

% ALPS parameters
params.ALPSiters = 600;         % Maximum number of iterations
params.tol= 1e-6;               % Tolerance for stopping criteria
params.mode = 1;                % Binary representation of (SolveNewtonb, GradientDescentx, SolveNewtox)
                                % mode = 5: Subspace Pursuit version
                                % mode = 2: Gradient descent based with additional de-bias step
params.memory = 1;              % Memory of IHT method - set to 1 for 1-ALPS(#) methods, set to 0 for 0-ALPS(#)
params.useCG = 1;               % Usage of Conjugate gradients method - used only if we do pseudoinversion steps
params.cg_tol = 10^-8;          % CG accuracy
params.cg_maxiter = 500;        % Maximum number of iterations for CG

% Please refer to generate_matrix.m and generate_vector.m files
m_ensemble = 'Gaussian';        % Measurement matrix ensemble type
x_ensemble = 'Gaussian';        % Sparse vector ensemble type

%% Generate data - normalized
x = generate_vector(N, K, x_ensemble);
Phi = generate_matrix(M, N, m_ensemble);
noise = randn(M,1);
noise = sigma*noise/norm(noise);
y = Phi*x + noise;

if (oraclesparsity)
    K_est = K;
else
    r = M/N;
    [~, ind] = min(abs(rhoW_crosspolytope(:, 1) - r));
    K_est = round(rhoW_crosspolytope(ind, 2)*M);
end;
K
K_est

%% ALPS reconstruction
disp('=====================================================================');
t0 = clock;
[x_zeroALPS, numiter_zeroALPS] = zero_ALPS(y, Phi, K_est, params);
toc_time = etime(clock, t0);
str = sprintf('0-ALPS(5) terminated - Error norm: %f ', norm(x-x_zeroALPS)/norm(x));
disp(str);
str = sprintf('Number of iterations: %f ', numiter_zeroALPS);
disp(str);
str = sprintf('Time: %f sec', toc_time);
disp(str);

disp('=====================================================================');
t0 = clock;
[x_oneALPS, numiter_oneALPS] = one_ALPS(y, Phi, K_est, params);
toc_time = etime(clock, t0);
str = sprintf('1-ALPS(2) terminated - Error norm: %f ', norm(x-x_oneALPS)/norm(x));
disp(str);
str = sprintf('Number of iterations: %f ', numiter_oneALPS);
disp(str);
str = sprintf('Time: %f sec', toc_time);
disp(str);